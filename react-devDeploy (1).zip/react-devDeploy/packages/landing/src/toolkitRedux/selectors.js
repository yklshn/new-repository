export const inputSelector = (state) => state.inputReducer
