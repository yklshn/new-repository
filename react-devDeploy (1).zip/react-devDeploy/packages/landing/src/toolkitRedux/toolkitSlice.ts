import { createSlice, PayloadAction } from '@reduxjs/toolkit';

export interface stateType {
    kindLog: 'Логин' | 'Номер телефона';
    noLatinAlphError: boolean;
    minSymbPassError: boolean;
    maxSymbPassError: boolean;
    minOneLetterPassError: boolean;
    minOneNumPassError: boolean;
    openModal: boolean;
    openModalAcceptedRequest: boolean;
    openModalDeclineRequest: boolean;
    showSMSWindow: 'SMS' | 'LogIn';
    code: string;
    countLogIn: number;
    auth: boolean;
    toggler: string;
}

const initialState: stateType = {
    kindLog: 'Логин',
    noLatinAlphError: false,
    minSymbPassError: false,
    maxSymbPassError: false,
    minOneLetterPassError: false,
    minOneNumPassError: false,
    //modal Authorization
    openModal: false,
    // Modal Request
    openModalAcceptedRequest: false,
    openModalDeclineRequest: false,
    showSMSWindow: 'LogIn', //LogIn SMS
    code: '',
    countLogIn: 5,
    // Фейковая авторизация
    auth: false,
    //credits page
    toggler: 'Действия',
};

const toolkitSlice = createSlice({
    name: 'toolkit',
    initialState,
    reducers: {
        // Переключатель
        setKindLog(state, action: PayloadAction<'Логин' | 'Номер телефона'>) {
            state.kindLog = action.payload;
        },

        // Проверка на ошибки password
        setMinSymbPassError(state, action: PayloadAction<boolean>) {
            state.minSymbPassError = action.payload;
        },
        setMaxSymbPassError(state, action: PayloadAction<boolean>) {
            state.maxSymbPassError = action.payload;
        },
        setNoLatinAlphError(state, action: PayloadAction<boolean>) {
            state.noLatinAlphError = action.payload;
        },
        setMinOneLetterPassError(state, action: PayloadAction<boolean>) {
            state.minOneLetterPassError = action.payload;
        },
        setMinOneNumPassError(state, action: PayloadAction<boolean>) {
            state.minOneNumPassError = action.payload;
        },

        //CodeAuthorization
        setCountLogIn(state, action: PayloadAction<number>) {
            state.countLogIn = action.payload;
        },
        setCode(state, action: PayloadAction<string>) {
            state.code = action.payload;
        },
        setShowSMS(state, action: PayloadAction<'LogIn' | 'SMS'>) {
            state.showSMSWindow = action.payload;
        },
        setOpenModal(state, action: PayloadAction<boolean>) {
            state.openModal = action.payload;
        },
        setOpenModalAcceptedRequest(state, action: PayloadAction<boolean>) {
            state.openModalAcceptedRequest = action.payload;
        },
        setOpenModalDeclineRequest(state, action: PayloadAction<boolean>) {
            state.openModalDeclineRequest = action.payload;
        },
        //Фейк авторизация
        setUserAuth(state, action: PayloadAction<boolean>) {
            state.auth = action.payload;
        },
        //credits page toggler
        setToggler(state, action: PayloadAction<string>) {
            state.toggler = action.payload;
        },
    },
});

export default toolkitSlice.reducer;
export const {
    setCountLogIn,
    setMaxSymbPassError,
    setMinOneLetterPassError,
    setMinOneNumPassError,
    setMinSymbPassError,
    setNoLatinAlphError,
    setOpenModal,
    setOpenModalAcceptedRequest,
    setOpenModalDeclineRequest,
    setShowSMS,
    setCode,
    setKindLog,
    //Фейковая авторизация
    setUserAuth,
    setToggler,
} = toolkitSlice.actions;
