import {configureStore,combineReducers} from "@reduxjs/toolkit";
import toolkitSlice from "./toolkitSlice";

// Redux
export {inputSelector} from './selectors'


export {
  setKindLog,
  setMaxSymbPassError,setMinOneLetterPassError,setMinOneNumPassError,
  setMinSymbPassError,setNoLatinAlphError,setOpenModal,setShowSMS,setCode,setCountLogIn} from './toolkitSlice'



// const rootReducer = combineReducers({
//   inputReducer: toolkitSlice,
  // inputReducer: inputReducer,
// })
//
// // Store
// export const store = configureStore({
//   reducer: rootReducer
// })
