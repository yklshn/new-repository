// components
export { SecurityRule } from './app/components/SecurityRule/SecurityRule';
export { Footer } from '../../../libs/ui/src/lib/Footer/Footer';
export { NavBar } from '../../../libs/ui/src/lib/BarNav/BarNav';
export { WindowForLogin } from './app/components/WindowForLogin/WindowForLogin';
export { Switch } from './app/components/Switch/Switch';
export { Accordion } from '../../../libs/ui/src/lib/Accordion/Accordion';
export { MainForm } from '../../../libs/ui/src/lib/MainForm/MainForm';
export { CodeLogIn } from './app/components/CodeLogIn/CodeLogIn';

// pages
export { Registration } from './app/webpages/Registration/Registration';
export { HomePage } from './app/webpages/HomePage/HomePage';
export { NotFoundPage } from './app/webpages/NotFoundPage/NotFoundPage';
export { CardsPage } from './app/webpages/СardsPageFolder/CardsPage';
export { CardPage } from './app/webpages/СardPageFolder/CardPage';
export { DepositsPage } from './app/webpages/DepositsPage/DepositsPage';
export { CreditsPage } from './app/webpages/CreditsPage/CreditsPage';

// Types

export type { FormValues } from './app/components/WindowForLogin/WindowForLogin';
