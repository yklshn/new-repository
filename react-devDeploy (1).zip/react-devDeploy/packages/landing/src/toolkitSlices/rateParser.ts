import {fieldsType, keysType, rateType} from "../types/rateType";

export const RateParser = (data: rateType): rateType => {

  const valutaNames: keysType[] = [];
  const rates: rateType = {usd: [], eur: [], chf: [], gbp: []};
  let valutaName: keysType;

  for (valutaName in data as rateType){
        valutaNames.push(valutaName);
    }

  let i = 0;
  let rateData: fieldsType[] = [];

  for (const dataArray of Object.values(data as rateType)){
      for (const item of dataArray as fieldsType[]){
          rateData.push({
              type: item.type,
              date: item.date,
              value: item.value,
              order: item.order
          })
      }
      const field: keysType = valutaNames[i];
      rates[field] = rateData;
      i += 1;
      rateData = [];
    }
  return rates;
}
