import { AppDispatch } from "./store";
import axios from "axios";
import {cardListSlice} from "./cardListSlice";
import {cardListType} from "../types/cardListType";
import {URL_CARD} from "../../../../libs/ui/src/lib/constants";


export const fetchCardList = () => async (dispatch: AppDispatch) => {
  //Данное окружение можно использовать для таких нужд? Создал папку в lib
const url = `${URL_CARD}/api/v1/card/products/`
  try{
    dispatch(cardListSlice.actions.cardListFetching())

    const response = await axios.get<cardListType>(url,
      {
        method: 'GET',
        headers: {
          'accept': 'application/json',
        }
      })

  if(response.data){
    dispatch(cardListSlice.actions.cardListFetchingSuccess(response.data))
  } else {
    throw new Error("wrong data on server");
  }
  } catch (err) {
    if (err instanceof Error) {
      dispatch(cardListSlice.actions.cardListFetchingError(err.message))
    }
  }
}
