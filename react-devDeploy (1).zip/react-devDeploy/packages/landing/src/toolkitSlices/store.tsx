import { combineReducers, configureStore } from '@reduxjs/toolkit';

import cardsSlice from './cardsSlice';
import toolkitSlice from '../toolkitRedux/toolkitSlice';
import rateReducer from './rateSlice';
import cardListReducer from './cardListSlice';
import graphSlice from './graphSlice';

const rootReducer = combineReducers({
    inputReducer: toolkitSlice,
    card: cardsSlice,
    rateReducer,
    cardListReducer,
    graphSlice,
});

export const setupStore = () => {
    return configureStore({
        reducer: rootReducer,
    });
};

export type RootState = ReturnType<typeof rootReducer>;
export type AppStore = ReturnType<typeof setupStore>;
export type AppDispatch = AppStore['dispatch'];
