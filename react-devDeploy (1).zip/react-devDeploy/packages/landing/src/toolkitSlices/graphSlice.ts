import { createSlice, PayloadAction } from '@reduxjs/toolkit';
import { Graph } from '../types/graphType';

type RateState = {
    firstYear: number;
    lastYear: number;
    graphValue: string;
    isFetching: boolean;
};

const initialState: RateState = {
    firstYear: 2022,
    lastYear: 2027,
    graphValue: 'Основной долг',
    isFetching: false,
};
export const graphSlice = createSlice({
    name: 'graph',
    initialState,
    reducers: {
        graphFetching(state) {
            state.isFetching = true;
        },
        changeValue(state, action: any) {
            state.graphValue = action.payload;
        },
    },
});
export default graphSlice.reducer;
export const { graphFetching, changeValue } = graphSlice.actions;
