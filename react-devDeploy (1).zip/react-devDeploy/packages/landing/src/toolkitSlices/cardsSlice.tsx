import { createSlice } from '@reduxjs/toolkit';

const cardsSlice = createSlice({
    name: 'cardsSlice',
    initialState: {},
    reducers: {
        addCard(state, action) {
            console.log(action.payload);
            return state = action.payload
        }
    }
})
export default cardsSlice.reducer
export const { addCard } = cardsSlice.actions