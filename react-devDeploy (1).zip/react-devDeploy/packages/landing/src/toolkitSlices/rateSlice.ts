import { createSlice, PayloadAction } from "@reduxjs/toolkit";
import { rateType} from "../types/rateType";

type RateState = {
  rates: rateType;
  isLoading: boolean;
  error: string;
}

const initialState: RateState = {
  rates: {
    usd: [{type: "", date: "", value: 0, order: ""}, {type: "", date: "", value: 0, order: ""}],
    eur: [{type: "", date: "", value: 0, order: ""}, {type: "", date: "", value: 0, order: ""}],
    chf: [{type: "", date: "", value: 0, order: ""}, {type: "", date: "", value: 0, order: ""}],
    gbp: [{type: "", date: "", value: 0, order: ""}, {type: "", date: "", value: 0, order: ""}]
  },
  isLoading: false,
  error: ""
}
export const rateSlice = createSlice({
  name: "rate",
  initialState,
  reducers: {
    ratesFetching(state){
      state.isLoading = true;
    },
    ratesFetchingSuccess(state, action: PayloadAction<rateType>){
      state.isLoading = false;
      state.error = ""
      state.rates = action.payload;
    },
    ratesFetchingError(state,  action: PayloadAction<string>){
      state.isLoading = false;
      state.error = action.payload;
    },
  }
})
export default rateSlice.reducer;
