import { AppDispatch } from "./store";
import axios from "axios";
import { rateSlice } from "./rateSlice";
import { isRateType } from "../types/rateType";
import { RateParser } from "./rateParser";

export const fetchRates = () => async (dispatch: AppDispatch) => {

    try {
      dispatch(rateSlice.actions.ratesFetching())
      const response = await axios.get<unknown>('https://alfabank.ru/ext-json/0.2/exchange/cash/?offset=0&limit=2&mode=rest')
        if(isRateType(response.data)){
            dispatch(rateSlice.actions.ratesFetchingSuccess(RateParser(response.data)))
          } else {
            throw new Error("wrong data on server");
          }
    } catch (err) {
      if(err instanceof Error){
        dispatch(rateSlice.actions.ratesFetchingError(err.message))
      }
    }
  }
