import { createSlice, PayloadAction } from "@reduxjs/toolkit";
import { cardListType} from "../types/cardListType";

type CardListState = {
  cardList: cardListType;
  isLoading: boolean;
  error: string;
}

const initialState: CardListState = {
  cardList: [{name: "", type: "", advantages: "", description: ""},
             {name: "", type: "", advantages: "", description: ""},
             {name: "", type: "", advantages: "", description: ""}],
  isLoading: false,
  error: ""
}

export const cardListSlice = createSlice({
  name: "cardLists",
  initialState,
  reducers: {
    cardListFetching(state){
      state.isLoading = true;
    },
    cardListFetchingSuccess(state, action: PayloadAction<cardListType>){
      state.isLoading = false;
      state.error = "";
      state.cardList = action.payload;
    },
    cardListFetchingError(state,  action: PayloadAction<string>){
      state.isLoading = false;
      state.error = action.payload;
    },
  }
})
export default cardListSlice.reducer;
