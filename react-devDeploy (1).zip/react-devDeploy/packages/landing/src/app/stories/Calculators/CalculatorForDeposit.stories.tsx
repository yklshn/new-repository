import { CalculatorForDeposit } from '@./ui';
import { Meta, StoryFn } from '@storybook/react';
import { colors } from 'packages/landing/.storybook/preview';

export default {
  title: 'UI/Calculator/CalculatorForDeposit',
  component: CalculatorForDeposit,
  argTypes: {
    headerColor: {
      description: 'Цвет заголовка',
      table: {
        category: 'Style',
      },
      type: 'string',
      ...colors,
    },
    headerText: {
      description: 'Текст заголовка',
      table: {
        category: 'name',
      },
      type: 'string',
      control: 'text',
    },
    buttonText: {
      description: 'Текст кнопки',
      table: {
        category: 'name',
      },
      type: 'string',
      control: 'text',
    },
    depositsData: {
      description: 'Массив объектов с данными',
      control: {
        disable: true,
      },
    },
  },
} as Meta<typeof CalculatorForDeposit>;

const Template: StoryFn<typeof CalculatorForDeposit> = (args) => (
  <CalculatorForDeposit {...args} />
);

export const Primary = Template.bind({});
Primary.storyName = 'По умолчанию';
Primary.args = {
  buttonText: 'Button Text',
  headerText: 'Header Text',
};
