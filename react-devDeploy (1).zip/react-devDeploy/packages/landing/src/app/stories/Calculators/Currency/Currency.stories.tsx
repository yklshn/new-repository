import { Meta, StoryFn } from '@storybook/react';
import { Currency } from 'libs/ui/src/lib/Calculators/CalculatorForDeposit/Currency/Currency';

export default {
  title: 'UI/Calculator/Currency/Currency',
  component: Currency,
  argTypes: {
    title: {
      description: 'Заголовок блока',
    },
    depositsData: {
      description: 'Массив объектов с данными',
      control: {
        disable: true,
      },
    },
    handleChangeDeposit: {
      description: 'callback для сохранения выбранной суммы',
      control: {
        disable: true,
      },
    },
  },
} as Meta<typeof Currency>;

const Template: StoryFn<typeof Currency> = (args) => <Currency {...args} />;

export const Primary = Template.bind({});
Primary.storyName = 'Валюта';
Primary.args = {
  title: 'Валюта',
  depositsData: [
    {
      currencyName: 'RUB',
      sumMin: 100,
      sumMax: 1000000,
      depositTermList: [6, 12, 18, 24, 36, 72, 120],
    },
    {
      currencyName: 'USD',
      sumMin: 100,
      sumMax: 1000000,
      depositTermList: [6, 12, 18, 24, 36, 72, 120],
    },
    {
      currencyName: 'EUR',
      sumMin: 100,
      sumMax: 1000000,
      depositTermList: [6, 12, 18, 24, 36, 72, 120],
    },
  ],
};
