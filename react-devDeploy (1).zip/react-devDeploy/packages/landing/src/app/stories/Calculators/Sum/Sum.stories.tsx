import { Meta, StoryFn } from '@storybook/react';
import { Sum } from 'libs/ui/src/lib/Calculators/CalculatorForDeposit/Sum/Sum';
import { useState } from 'react';

export default {
  title: 'UI/Calculator/Sum/Sum',
  component: Sum,
  argTypes: {
    title: {
      description: 'Заголовок блока',
    },
    sumValue: {
      description: 'Выбранная сумма',
      control: {
        disable: true,
      },
      default: 100,
    },
    handleSumValue: {
      description: 'callback для сохранения выбранной суммы',
      control: {
        disable: true,
      },
    },
    selectedDeposit: {
      description: 'Объект с данными',
      control: {
        disable: true,
      },
    },
  },
} as Meta<typeof Sum>;

const Template: StoryFn<typeof Sum> = (args) => {
  const [value, setValue] = useState(args.sumValue ?? 100);
  return (
    <>
      <Sum
        {...args}
        handleSumValue={(e: any) => {
          args.handleSumValue;
          setValue(e.target.value);
        }}
        sumValue={value}
      />
    </>
  );
};

export const Primary = Template.bind({});
Primary.storyName = 'Сумма';
Primary.args = {
  title: 'Сумма вклада',
  selectedDeposit: [
    {
      currencyName: 'RUB',
      sumMin: 100,
      sumMax: 10000000,
      depositTermList: [6, 12, 18, 36, 72, 120],
    },
  ],
};
