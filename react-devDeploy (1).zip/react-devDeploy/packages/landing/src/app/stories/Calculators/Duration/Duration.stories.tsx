import { Meta, StoryFn } from '@storybook/react';
import { Duration } from 'libs/ui/src/lib/Calculators/CalculatorForDeposit/Duration/Duration';
import { useState } from 'react';

export default {
  title: 'UI/Calculator/Duration/Duration',
  component: Duration,
  argTypes: {
    title: {
      description: 'Заголовок блока',
    },
    durationValue: {
      description: 'Выбранный срок',
      control: {
        disable: true,
      },
    },
    handleDurationValue: {
      description: 'callback для сохранения выбранного срока',
      control: {
        disable: true,
      },
    },
    selectedDeposit: {
      description: 'Объект с данными',
      control: {
        disable: true,
      },
    },
  },
} as Meta<typeof Duration>;

const Template: StoryFn<typeof Duration> = (args) => {
  const [value, setValue] = useState(args.durationValue ?? '0');
  return (
    <>
      <Duration
        {...args}
        handleDurationValue={(e: any) => {
          const value = +e.target.value;
          let currentValue: string = '0';
          if (value >= 6 && value < 12) {
            currentValue = '6';
          } else if (value >= 12 && value < 18) {
            currentValue = '12';
          } else if (value >= 18 && value < 36) {
            currentValue = '18';
          } else if (value >= 36 && value < 54) {
            currentValue = '36';
          } else if (value >= 54 && value < 96) {
            currentValue = '72';
          } else if (value > 72) {
            currentValue = '120';
          }
          args.handleDurationValue;
          setValue(currentValue);
        }}
        durationValue={value}
      />
    </>
  );
};

export const Primary = Template.bind({});
Primary.storyName = 'Срок вклада';
Primary.args = {
  title: 'Срок вклада',
  selectedDeposit: [
    {
      currencyName: 'RUB',
      sumMin: 100,
      sumMax: 10000000,
      depositTermList: [6, 12, 18, 36, 72, 120],
    },
  ],
};
