import { Meta, StoryFn } from '@storybook/react';
import { Additional } from 'libs/ui/src/lib/Calculators/CalculatorForDeposit/Additional/Additional';
import { useState } from 'react';

export default {
  title: 'UI/Calculator/Additional/Additional',
  component: Additional,
  argTypes: {
    title: {
      description: 'Заголовок блока',
    },
    handleAdditionalValue: {
      description: 'callback для сохранения дополнительных условий',
    },
  },
} as Meta<typeof Additional>;

const Template: StoryFn<typeof Additional> = (args) => <Additional {...args} />;

export const Primary = Template.bind({});
Primary.storyName = 'Доп. условия';
Primary.args = {
  title: 'Дополнительные условия',
};
