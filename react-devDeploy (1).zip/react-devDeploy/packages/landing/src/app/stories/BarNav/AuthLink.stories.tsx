import { Meta, StoryFn } from '@storybook/react';
import { setupStore } from 'packages/landing/src/toolkitSlices/store';
import { Provider } from 'react-redux';

import { AuthLink } from '../../../../../../libs/ui/src/lib/BarNav/AuthLink';

export default {
  title: 'UI/BarNav/AuthLink',
  component: AuthLink,
  argTypes: {
    to: {
      description: 'адрес перенаправления',
      control: 'text',
    },
    isUserAuth: {
      description: 'Авторизован пользователь или нет',
      control: 'boolean',
      options: [false, true],
      defaultValue: false,
    },
    btnTextIndex: {
      description: 'Текст кнопки',
      control: 'inline-radio',
      options: [0, 1],
      defaultValue: 1,
    },
  },
  decorators: [(story) => <Provider store={setupStore()}>{story()}</Provider>],
} as Meta<typeof AuthLink>;

const AuthLinkStory: StoryFn<typeof AuthLink> = (args) => (
  <AuthLink {...args} />
);

export const Primary = AuthLinkStory.bind({});
Primary.storyName = 'AuthLink';
