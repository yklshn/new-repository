import { Meta, StoryFn } from '@storybook/react';
import { BrowserRouter, Route, Routes } from 'react-router-dom';

import { NavBar } from '../../../../../../libs/ui/src/lib/BarNav/BarNav';

export default {
  title: 'UI/BarNav/NavBar',
  component: NavBar,
  argTypes: {
    auth: {
      control: 'boolean',
      defaultValue: true,
      description: 'Авторизован пользователь',
    },
  },
  decorators: [
    (story) => (
      <BrowserRouter>
        <Routes>
          <Route path="*" element={story()} />
        </Routes>
      </BrowserRouter>
    ),
  ],
} as Meta<typeof NavBar>;

const Template: StoryFn<typeof NavBar> = (args) => <NavBar {...args} />;

export const Primary = Template.bind({});
Primary.storyName = 'Nav bar';
