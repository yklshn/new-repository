import { Meta, StoryFn } from '@storybook/react';
import { BrowserRouter, Route, Routes } from 'react-router-dom';

import { Footer } from '../../../../../libs/ui/src/lib/Footer/Footer';

export default {
  title: 'UI/Footer',
  component: Footer,
  decorators: [
    (story) => (
      <BrowserRouter>
        <Routes>
          <Route path="*" element={story()} />
        </Routes>
      </BrowserRouter>
    ),
  ],
} as Meta<typeof Footer>;

const Template: StoryFn = (args) => <Footer {...args} />;

export const Primary = Template.bind({});
Primary.storyName = 'Footer';
