import { Meta, StoryFn } from '@storybook/react';

import { GetCard } from '../../../../../../libs/ui/src/lib/GetCard/GetCard';

export default {
  title: 'UI/GetCard/GetCard',
  components: GetCard,
} as Meta<typeof GetCard>;

const Template: StoryFn = (args) => <GetCard steps={[{}]} {...args} />;

export const Primary = Template.bind({});
Primary.storyName = 'GetCard';
Primary.args = {
  headerText: 'Title goes here',
  steps: [1],
};
