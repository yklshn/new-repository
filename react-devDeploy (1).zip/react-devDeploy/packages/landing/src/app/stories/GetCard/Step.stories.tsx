import { Meta, StoryFn } from '@storybook/react';
import { Step } from 'libs/ui/src/lib/GetCard/Step/Step';

export default {
  title: 'UI/GetCard/Step',
  components: Step,
} as Meta<typeof Step>;

const Template: StoryFn = (args) => <Step {...args} />;

export const Primary = Template.bind({});
Primary.storyName = 'Step';
Primary.args = {};
