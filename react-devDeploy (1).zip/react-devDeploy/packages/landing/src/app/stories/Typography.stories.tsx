import { Meta, StoryFn } from '@storybook/react';
import { colors } from 'packages/landing/.storybook/preview';

import { Typography } from '../../../../../libs/ui/src/lib/Typography/Typography';

export default {
  title: 'UI/Typography',
  component: Typography,
  argTypes: {
    children: {
      description: 'Вариант отображения текста',
      table: {
        category: 'Displayed text',
      },
    },
    fontFamily: {
      control: {
        disable: true,
      },
      table: {
        category: 'font',
      },
    },
    fontWeight: {
      description: 'Толщина',
      control: 'select',
      options: ['weight400', 'weight500', 'weight600', '700'],
      defaultValue: 'weight400',
      table: {
        category: 'font',
      },
    },
    tag: {
      description: 'Тэг',
      table: {
        category: 'text',
      },
    },
    textAlign: {
      description: 'Положение текста',
      table: {
        category: 'text',
      },
    },
    fontSize: {
      description: 'Размер',
      control: 'select',
      options: [
        '12px',
        '14px',
        '16px',
        '18px',
        '20px',
        '22px',
        '24px',
        '32px',
        '44px',
      ],
      defaultValue: '16px',
      table: {
        category: 'font',
      },
    },
    textDecoration: {
      control: {
        disable: true,
      },
      table: {
        category: 'text',
      },
    },
    marginTop: {
      description: 'Отступ сверху',
      control: 'select',
      options: [
        '0px',
        '5px',
        '10px',
        '20px',
        '25px',
        '37px',
        '40px',
        '80px',
        '156px',
      ],
      defaultValue: 'margin',
      table: {
        category: 'margin',
      },
    },
    mb: {
      description: 'Отступ снизу (Нет на проекте)',
      control: {
        disable: true,
      },
      table: {
        category: 'margin',
      },
    },
    letterSpacing: {
      description: 'Расстояние между буквами',
      control: 'select',
      options: ['0', '7'],
      defaultValue: '0',
      table: {
        category: 'spacing',
      },
    },
    lineHeight: {
      description: 'Высота линии',
      control: 'select',
      options: ['19px', '21px', '25px', '120', '140'],
      table: {
        category: 'space',
      },
    },
    width: {
      description: 'Ширина',
      control: 'select',
      options: ['0px', '196px', '526px', '530px'],
      defaultValue: '0px',
      table: {
        category: 'space',
      },
    },
    color: {
      type: 'string',
      description: 'Цвет',
      ...colors,
    },
  },
} as Meta<typeof Typography>;

const Template: StoryFn<typeof Typography> = (args) => <Typography {...args} />;

export const Primary = Template.bind({});
Primary.storyName = 'По умолчанию';
Primary.args = {
  children: 'Default',
};
Primary.argTypes = {
  children: {
    name: 'Default',
  },
};

export const Title = Template.bind({});
Title.storyName = 'Заголовок';
Title.args = {
  children: 'Заголовок',
  fontSize: '44px',
  fontWeight: '700px',
  tag: 'h2',
};
Title.argTypes = {
  children: {
    name: 'Заголовок',
  },
};
