import { Meta, StoryFn } from '@storybook/react';
import React from 'react';

import { SliderWrapper } from '../../../../../../libs/ui/src/lib/SliderWrapper/SliderWrapper';

export default {
  title: 'UI/SliderWrapper',
  component: SliderWrapper,
  parameters: {
    argTypes: {
      loading: {
        description: 'TRUE shows spinner. FALSE hides spinner',
        control: 'boolean',
        table: {
          category: 'displayed',
        },
      },
    },
  },
} as Meta<typeof SliderWrapper>;

const Template: StoryFn<typeof SliderWrapper> = () => <SliderWrapper />;

export const Primary = Template.bind({});
Primary.storyName = 'По умолчанию';
// Primary.decorators = decorators;
