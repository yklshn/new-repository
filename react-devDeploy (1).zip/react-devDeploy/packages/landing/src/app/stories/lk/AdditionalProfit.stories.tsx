import { Meta, StoryFn } from '@storybook/react';

import { AdditionalProfit } from '../../../../../lk/src/app/components/AdditionalProfit/AdditionalProfit';

export default {
  title: 'UI/lk/AdditionalProfit',
  component: AdditionalProfit,
} as Meta<typeof AdditionalProfit>;

const Template: StoryFn = (args) => (
  <AdditionalProfit
    header={'header'}
    imageSrc={''}
    text={'text goes here'}
    {...args}
  />
);

export const Primary = Template.bind({});
Primary.storyName = 'AdditionalProfit';
