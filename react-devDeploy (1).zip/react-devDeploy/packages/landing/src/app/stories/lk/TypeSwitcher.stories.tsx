import { Meta, StoryFn } from '@storybook/react';
import { TypeSwitcher } from 'libs/ui/src/lib/TypeSwitcher/TypeSwitcher';
import { setupStore } from 'packages/landing/src/toolkitSlices/store';
import { Provider } from 'react-redux';

export default {
  title: 'UI/lk/TypeSwitcher',
  component: TypeSwitcher,
  decorators: [(story) => <Provider store={setupStore()}>{story()}</Provider>],
} as Meta<typeof TypeSwitcher>;

const Template: StoryFn = ({ items, headerText }) => (
  <TypeSwitcher items={items} headerText={headerText} />
);

export const Primary = Template.bind({});
Primary.storyName = 'ProfileCard';
Primary.args = {
  items: ['item1', 'item2', 'item3', 'item4'],
  headerText: 'Header',
};
