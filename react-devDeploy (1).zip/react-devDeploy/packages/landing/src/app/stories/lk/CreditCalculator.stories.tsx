import { Meta, StoryFn } from '@storybook/react';
import { ChangeEvent, useState } from 'react';

import { CreditCalculator } from '../../../../../lk/src/app/components/calculators/CreditCalculator/CreditCalculator';

export default {
  title: 'UI/lk/CreditCalculator',
  component: CreditCalculator,
} as Meta<typeof CreditCalculator>;

const Template: StoryFn = (args) => {
  const [sliderValue, setSliderValue] = useState('50000');
  const [value, setValue] = useState('50000');

  return (
    <>
      <CreditCalculator
        {...args}
        sumInputHandler={(e: ChangeEvent<HTMLInputElement>): void => {
          args['sumInputHandler'];
          setSliderValue(e.target.value);
        }}
        currencyInputHandler={(e: ChangeEvent<HTMLInputElement>): void => {
          args['currencyInputHandler'];
          setValue(e.target.value);
        }}
        sumValue={sliderValue}
        currencyValue={value}
      />
    </>
  );
};

export const Primary = Template.bind({});
Primary.storyName = 'CreditCalculator';
