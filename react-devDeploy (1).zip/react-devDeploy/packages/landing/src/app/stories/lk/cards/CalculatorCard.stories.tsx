import { Meta, StoryFn } from '@storybook/react';
import { useEffect, useState } from 'react';

import { CalculatorCard } from '../../../../../../lk/src/app/components/cards/CalculatorCard/CalculatorCard';

export default {
  title: 'UI/lk/cards/CalculatorCard',
  component: CalculatorCard,
  argTypes: {
    title: {
      control: 'text',
    },
    type: {
      control: 'inline-radio',
    },
  },
} as Meta<typeof CalculatorCard>;
const someFunc = (data: any, type: string): any => {
  const [value, setValue] = useState('');
  if (type == 'button') return { children: 'Рассчитать', variant: 'secondary' };
  if (type == 'text') return '9.9%';
  if (type == 'select')
    return {
      optionsArray: [
        '12 месяцев',
        '18 месяцев',
        '24 месяцев',
        '36 месяцев',
        '48 месяцев',
        '60 месяцев',
      ],
      onChange: (e: any) => {
        setValue(e.target.value);
      },
      disabledOption: false,
      name: 'period',
      value: value,
    };
};

const Template: StoryFn = ({ title, type, data }) => {
  const setTitle = (type: string): any => {
    if (type == 'select') return 'Срок кредитования';
    if (type == 'button') return 'Ежемесячный платеж';
    if (type == 'text') return 'Процентная ставка';
  };
  return (
    <CalculatorCard
      title={setTitle(type)}
      type={type}
      data={someFunc(data, type)}
    />
  );
};

export const Primary = Template.bind({});
Primary.storyName = 'CalculatorCard';
