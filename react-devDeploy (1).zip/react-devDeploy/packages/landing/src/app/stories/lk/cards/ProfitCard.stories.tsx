import { Meta, StoryFn } from '@storybook/react';

import { ProfitCard } from '../../../../../../lk/src/app/components/cards/ProfitCard/ProfitCard';

export default {
  title: 'UI/lk/cards/ProfitCard',
  component: ProfitCard,
} as Meta<typeof ProfitCard>;

const Template: StoryFn = (args) => <ProfitCard {...args} />;

export const Primary = Template.bind({});
Primary.storyName = 'ProfitCard';
