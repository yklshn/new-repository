import { Meta, StoryFn } from '@storybook/react';

import { ProfileCard } from '../../../../../../lk/src/app/components/cards/ProfileCard/ProfileCard';

export default {
  title: 'UI/lk/cards/ProfileCard',
  component: ProfileCard,
  argTypes: {
    header: {
      type: 'string',
      description: 'Заголовок',
      control: 'text',
    },
    data: {
      description: 'Массив объектов с тектом',
      control: {
        type: 'object',
      },
    },
    fields: {
      description: 'Объект с инф-ей для Formikа',
      control: {
        type: 'object',
      },
    },
  },
} as Meta<typeof ProfileCard>;

const Template: StoryFn = ({ header, data, fields }) => (
  <ProfileCard header={header} data={data} fields={fields} />
);

export const Primary = Template.bind({});
Primary.storyName = 'ProfileCard';
Primary.args = {
  header: 'Место работы',
  data: [
    {
      title: 'Название организаци',
      id: 'companyName',
      name: 'companyName',
      placeholder: 'Aston корпорейшен',
    },
  ],
  fields: {
    companyName: 'companyName',
    companyAdress: 'companyAdress',
    companyPhone: 'companyPhone',
    position: 'position',
  },
};
