import { Meta, StoryFn } from '@storybook/react';
import { CImage } from 'libs/ui/src/lib/Cards/OfferCard/Image/Image';

import card from '../../../../../../libs/ui/img/card.png';

const storyStyle = {
  height: '100vh',
  display: 'flex',
  'text-align': 'center',
  'justify-content': 'center',
  'align-items': 'center',
};

export default {
  title: 'UI/Cards/CImage',
  component: CImage,
  argTypes: {
    cardImage: {
      control: {
        type: 'none',
      },
      description: 'адрес изображения',
    },
    cardNumber: {
      description: 'Номер карты',
      control: {
        type: 'text',
      },
    },
    cardImageHeight: {
      description: 'Стиль для высоты карты',
      control: {
        type: 'number',
      },
    },
    cardImageWidth: {
      description: 'Стиль для ширины карты',
      control: {
        type: 'number',
      },
    },
    cardTitle: {
      description: 'Заголовки для карты',
    },
    background: {
      description: 'Задний фон вокруг карты',
      control: {
        type: 'color',
      },
    },
  },
  decorators: [(story) => <div style={storyStyle}>{story()}</div>],
} as Meta<typeof CImage>;

const CImageStory: StoryFn<typeof CImage> = (args) => <CImage {...args} />;

export const Primary = CImageStory.bind({});
Primary.storyName = 'Cards CImage';
Primary.args = {
  cardImage: card,
  cardImageHeight: 0,
  cardImageWidth: 0,
  cardTitle: ['Card ', 'title'],
  cardNumber: '123456789',
  background: 'black',
};
