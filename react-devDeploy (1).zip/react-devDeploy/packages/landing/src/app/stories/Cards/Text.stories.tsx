import { Meta, StoryFn } from '@storybook/react';
import { Text } from 'libs/ui/src/lib/Cards/OfferCard/Text/Text';
import { colors, columnDescription } from 'packages/landing/.storybook/preview';
import { setupStore } from 'packages/landing/src/toolkitSlices/store';

export default {
  title: 'UI/Cards/Text',
  component: Text,
  argTypes: {
    ...columnDescription,
    headerColor: {
      table: {
        category: 'Colors',
      },
      description: 'Цвет текста названия столбца',
      ...colors,
    },
    subheaderColor: {
      table: {
        category: 'Colors',
      },
      description: 'Цвет заголовка и подзаголовка столбца',
      ...colors,
    },
  },
} as Meta<typeof Text>;

const CImageStory: StoryFn<typeof Text> = (args) => <Text {...args} />;

export const Primary = CImageStory.bind({});
Primary.storyName = 'Text';
Primary.args = {
  leftColumnHeader: 'Left Header',
  leftColumnTitle: 'Left Title',
  leftColumnSubtitle: 'Left SubTitle',
  middleColumnHeader: 'Middle Header',
  middleColumnTitle: 'Middle Title',
  middleColumnSubtitle: 'Middle SubTitle',
  rightColumnHeader: 'Right Header',
  rightColumnTitle: 'Right Title',
  rightColumnSubtitle: 'Right SubTitle',
  headerColor: 'black',
  subheaderColor: 'black',
};
