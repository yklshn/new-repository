import { Meta, StoryFn } from '@storybook/react';
import { Header } from 'libs/ui/src/lib/Cards/OfferCard/Header/Header';
import { colors } from 'packages/landing/.storybook/preview';

export default {
  title: 'UI/Cards/Header',
  component: Header,
  argTypes: {
    headerText: {
      description: 'Текст заголовка',
      control: 'text',
      defaultValue: 'Zayavka 1',
    },
    color: {
      type: 'string',
      description: 'Цвет',
      ...colors,
    },
  },
} as Meta<typeof Header>;

const HeaderStory: StoryFn<typeof Header> = (args) => <Header {...args} />;

export const Primary = HeaderStory.bind({});
Primary.storyName = 'Cards Header';
Primary.args = {
  headerText: 'Заявка 1',
};
