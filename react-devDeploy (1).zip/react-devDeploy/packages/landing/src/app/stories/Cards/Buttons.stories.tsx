import { Meta, StoryFn } from '@storybook/react';
import { Buttons } from 'libs/ui/src/lib/Cards/OfferCard/Buttons/Buttons';
import {
  columnDescription,
  depositDescription,
} from 'packages/landing/.storybook/preview';
import { setupStore } from 'packages/landing/src/toolkitSlices/store';
import { Provider } from 'react-redux';
import { BrowserRouter, Route, Routes } from 'react-router-dom';

export default {
  title: 'UI/Cards/Buttons',
  component: Buttons,
  argTypes: {
    primaryButtonText: {
      description: 'Текст главной кнопки',
      control: {
        type: 'text',
      },
      table: {
        category: 'Text',
        subcategory: 'button text',
      },
    },
    secondaryButtonText: {
      description: 'Текст второстепенной кнопки',
      control: {
        type: 'text',
      },
      table: {
        category: 'Text',
        subcategory: 'button text',
      },
    },
    needMoreInfo: {
      description: 'Флаг, нужна ли доп. информация',
      control: 'boolean',
      options: [false, true],
      defaultValue: false,
      table: {
        category: 'other',
      },
    },
    headerText: {
      table: {
        category: 'Text',
        subcategory: 'titles',
      },
    },
    cardTitle: {
      table: {
        category: 'Text',
        subcategory: 'titles',
      },
    },
    ...columnDescription,
    ...depositDescription,
    cardNumber: {
      table: {
        category: 'other',
      },
    },
    id: {
      table: {
        category: 'other',
      },
      description: 'id для url',
    },
    background: {
      table: {
        category: 'other',
      },
    },
    typeOf: {
      table: {
        category: 'other',
      },
      description: 'тип для url',
    },
  },
  decorators: [
    (story) => (
      <Provider store={setupStore()}>
        <BrowserRouter>
          <Routes>
            <Route path="*" element={story()} />
          </Routes>
        </BrowserRouter>
      </Provider>
    ),
  ],
} as Meta<typeof Buttons>;

const Template: StoryFn<typeof Buttons> = (args) => <Buttons {...args} />;

export const Primary = Template.bind({});
Primary.storyName = 'Кнопки';
Primary.args = {
  primaryButtonText: 'Primary Button',
  secondaryButtonText: 'Secondary Button',
};
