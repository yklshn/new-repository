import { OfferCard } from '@./ui';
import { Meta, StoryFn } from '@storybook/react';
import {
  columnDescription,
  depositDescription,
} from 'packages/landing/.storybook/preview';

import card from '../../../../../../libs/ui/img/card.png';

export default {
  title: 'UI/Cards/OfferCard',
  component: OfferCard,
  argTypes: {
    ...columnDescription,
    ...depositDescription,
    primaryButtonText: {
      description: 'Текст главной кнопки',
      control: {
        type: 'text',
      },
      table: {
        category: 'Text',
        subcategory: 'button text',
      },
    },
    secondaryButtonText: {
      description: 'Текст второстепенной кнопки',
      control: {
        type: 'text',
      },
      table: {
        category: 'Text',
        subcategory: 'button text',
      },
    },
    cardImageHeight: {
      describe: 'Высота',
      table: {
        category: 'size',
      },
    },
    cardImageWidth: {
      describe: 'Ширина',
      table: {
        category: 'size',
      },
    },
    cardImage: {
      description: 'Ссылка на изображение',
      table: {
        category: 'Cards view',
      },
    },
    cardNumber: {
      description: 'Номер карты',
      table: {
        category: 'Cards view',
      },
    },
    background: {
      description: 'Задний фон карты',
      control: {
        type: 'color',
      },
    },
    needMoreInfo: {
      description: 'Флаг, нужна ли доп. информация',
      control: 'boolean',
      options: [false, true],
      defaultValue: false,
      table: {
        category: 'other',
      },
    },
  },
} as Meta<typeof OfferCard>;

const CImageStory: StoryFn<typeof OfferCard> = (args) => (
  <OfferCard {...args} />
);

export const Primary = CImageStory.bind({});
Primary.storyName = 'OfferCard';
Primary.args = {
  cardImage: card,
  background: 'black',
  primaryButtonText: 'Primary button',
  secondaryButtonText: 'Secondary button',
  leftColumnHeader: 'Left Header',
  leftColumnTitle: 'Left Title',
  leftColumnSubtitle: 'Left SubTitle',
  middleColumnHeader: 'Middle Header',
  middleColumnTitle: 'Middle Title',
  middleColumnSubtitle: 'Middle SubTitle',
  rightColumnHeader: 'Right Header',
  rightColumnTitle: 'Right Title',
  rightColumnSubtitle: 'Right SubTitle',
};
