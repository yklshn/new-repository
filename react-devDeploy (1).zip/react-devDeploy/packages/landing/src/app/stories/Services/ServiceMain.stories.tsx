import { ServicesMain } from '@./ui';
import { Meta, StoryFn } from '@storybook/react';

export default {
  title: 'UI/Services/ServiceMain',
  component: ServicesMain,
} as Meta<typeof ServicesMain>;

const Template: StoryFn = (args) => <ServicesMain {...args} />;

export const Primary = Template.bind({});
Primary.storyName = 'ServiceMain';
