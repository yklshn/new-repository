import { Meta, StoryFn } from '@storybook/react';
import { ServicesItem } from 'libs/ui/src/lib/Services/ServicesItemFolder/ServicesItem';

export default {
  title: 'UI/Services/ServiceItem',
  component: ServicesItem,
  argTypes: {
    title: {
      name: 'Title',
      description: 'Title',
      defaultValue: 'Title goes here',
      table: {
        category: 'text',
      },
    },
    text: {
      name: 'Message Text',
      defaultValue: 'Message text goes here',
      table: {
        category: 'text',
      },
    },
    buttonText: {
      name: 'Button Text',
      defaultValue: 'Button text goes here',
      table: {
        category: 'text',
      },
    },
  },
} as Meta<typeof ServicesItem>;

const Template: StoryFn = (args) => <ServicesItem image={''} {...args} />;

export const Primary = Template.bind({});
Primary.storyName = 'ServiceItem';
Primary.args = {
  title: 'Lorem Ipsum',
  text: 'Lorem ipsum dolor sit amet, consectetur adipiscing elit. Phasellus congue felis at quam tempor posuere.',
  buttonText: 'Click Button',
};
