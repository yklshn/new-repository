import { ExchangeRate } from '@./ui';
import { Meta, StoryFn } from '@storybook/react';
import { setupStore } from 'packages/landing/src/toolkitSlices/store';
import { Provider } from 'react-redux';

export default {
  title: 'UI/ExchangeRate/ExchangeRate',
  component: ExchangeRate,
  decorators: [(story) => <Provider store={setupStore()}>{story()}</Provider>],
} as Meta<typeof ExchangeRate>;

const Template: StoryFn = (args) => <ExchangeRate {...args} />;

export const Primary = Template.bind({});
Primary.storyName = 'ExchangeRate';
