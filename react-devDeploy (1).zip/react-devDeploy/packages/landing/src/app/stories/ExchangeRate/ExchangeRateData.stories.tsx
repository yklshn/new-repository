import { Meta, StoryFn } from '@storybook/react';
import { ExchangeRateData } from 'libs/ui/src/lib/ExchangeRate/ExchangeRateData/ExchangeRateData';
import { setupStore } from 'packages/landing/src/toolkitSlices/store';
import { Provider } from 'react-redux';

const store = setupStore();

export default {
  title: 'UI/ExchangeRate/ExchangeRateData',
  component: ExchangeRateData,
  argTypes: {
    type: {
      control: 'inline-radio',
    },
  },
  decorators: [(story) => <Provider store={store}>{story()}</Provider>],
} as Meta<typeof ExchangeRateData>;

const Template: StoryFn = (args) => <ExchangeRateData type={'USD'} {...args} />;

export const Primary = Template.bind({});
Primary.storyName = 'ExchangeRateData';
