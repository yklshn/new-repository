import { CardDetails } from '@./ui';
import { configureStore, createSlice } from '@reduxjs/toolkit';
import { Meta, StoryFn } from '@storybook/react';
import { Provider } from 'react-redux';

const MockedState = {
  depositCurrency: 'RUB',
  depositSumMin: 100,
  depositSumMax: 10000000,
  depositTerm: '48',
  depositReplenishingBalancePossibility: true,
  depositEarlyClosed: false,
  depositFullDescription: 'Да',
};

const MockStore = ({ state, children }: any) => (
  <Provider
    store={configureStore({
      reducer: {
        card: createSlice({
          name: 'cardDetails',
          initialState: state,
          reducers: {},
        }).reducer,
      },
    })}
  >
    {children}
  </Provider>
);

export default {
  title: 'UI/CardDetails',
  component: CardDetails,
  decorators: [(story) => <MockStore state={MockedState}>{story()}</MockStore>],
} as Meta<typeof CardDetails>;

const Template: StoryFn<typeof CardDetails> = () => <CardDetails />;

export const Primary = Template.bind({});
Primary.storyName = 'Детали карты';
