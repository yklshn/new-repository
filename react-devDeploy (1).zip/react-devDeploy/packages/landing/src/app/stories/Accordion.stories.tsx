import { Accordion } from '@./ui';
import { Meta, StoryFn } from '@storybook/react';

export default {
  title: 'UI/Accordion',
  component: Accordion,
  argTypes: {
    label: {
      name: 'Блок вопросы/ответы',
    },
  },
} as Meta<typeof Accordion>;

const Template: StoryFn<typeof Accordion> = (args) => <Accordion {...args} />;

export const Primary = Template.bind({});
Primary.storyName = 'По умолчанию';
Primary.args = {};
