import { Meta, StoryFn } from '@storybook/react';

import { SliderWrapper } from '../../../../../libs/ui/src/lib/SliderWrapper/SliderWrapper';

export default {
  title: 'UI/SliderWrapper',
  component: SliderWrapper,
  parameters: {
    argTypes: {
      argTypes: {
        variant: {
          options: ['primary', 'secondary'],
          control: { type: 'radio' },
        },
      },
    },
  },
} as Meta<typeof SliderWrapper>;

const Template: StoryFn<typeof SliderWrapper> = () => <SliderWrapper />;

export const Primary = Template.bind({});
Primary.storyName = 'По умолчанию';
