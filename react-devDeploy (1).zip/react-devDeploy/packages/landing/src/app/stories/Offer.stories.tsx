import { Offer } from '@./ui';
import { Meta, StoryFn } from '@storybook/react';
import { colors } from 'packages/landing/.storybook/preview';

export default {
  title: 'UI/Offer',
  component: Offer,
  argTypes: {
    headerText: {
      table: { category: 'text' },
    },
    subheaderText: {
      table: { category: 'text' },
    },
    buttonText: {
      table: { category: 'text' },
    },
    headerColor: {
      table: {
        category: 'color',
      },
      description: 'Pick your color',
      type: 'string',
      ...colors,
    },
    subheaderColor: {
      table: {
        category: 'color',
      },
      description: 'Pick your color',
      type: 'string',
      ...colors,
    },
  },
} as Meta<typeof Offer>;

const Template: StoryFn = (args) => <Offer {...args} />;

export const Primary = Template.bind({});
Primary.storyName = 'Offer';
Primary.args = {
  headerText: 'Header text',
  headerColor: 'black',
  subheaderText: 'Subheader text',
  buttonText: 'Button text',
  subheaderColor: 'grey',
};
