import { Meta, StoryFn } from '@storybook/react';
import { Departments } from 'libs/ui/src/lib/DepartmentsWrapper/Departments/Departments';

export default {
  title: 'UI/DepartmentsWrapper/Departments',
  component: Departments,
} as Meta<typeof Departments>;

const Template: StoryFn = (args) => (
  <Departments
    title={'Наши банкоматы и отделения'}
    placeholderText={'Найти отделение'}
    buttonText={'Найти'}
    image={''}
    {...args}
  />
);

export const Primary = Template.bind({});
Primary.storyName = 'Departments';
