import { DepartmentsWrapper } from '@./ui';
import { Meta, StoryFn } from '@storybook/react';

export default {
  title: 'UI/DepartmentsWrapper/DepartmentsWrapper',
  component: DepartmentsWrapper,
} as Meta<typeof DepartmentsWrapper>;

const Template: StoryFn = (args) => <DepartmentsWrapper {...args} />;

export const Primary = Template.bind({});
Primary.storyName = 'DepartmentsWrapper';
