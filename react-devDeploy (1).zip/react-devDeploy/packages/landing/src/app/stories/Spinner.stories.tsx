import { Meta, StoryFn } from '@storybook/react';

import { Spinner } from '../../../../../libs/ui/src/lib/Spinner/Spinner';

export default {
  title: 'UI/Spinner',
  component: Spinner,
  parameters: {
    argTypes: {
      loading: {
        description: 'TRUE shows spinner. FALSE hides spinner',
        control: 'boolean',
        table: {
          category: 'displayed',
        },
      },
    },
  },
} as Meta<typeof Spinner>;

const Template: StoryFn<typeof Spinner> = (args) => <Spinner {...args} />;

export const Primary = Template.bind({});
Primary.storyName = 'По умолчанию';
Primary.args = {
  loading: false,
  text: 'Your message goes here',
};
Primary.argTypes = {
  loading: {
    name: 'Loading',
    description: 'Loading spinner. Set to true to display the Spinner',
    defaultValue: false,
  },
  text: {
    name: 'Message',
    type: { name: 'string', required: false },
    defaultValue: 'Your message goes here',
    table: {
      type: 'lol',
      defaultValue: { summary: 'Your message goes here' },
      description: 'Display a message next to the Spinner',
    },
  },
};
