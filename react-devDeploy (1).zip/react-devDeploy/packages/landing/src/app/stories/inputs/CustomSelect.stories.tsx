import { CustomSelect } from '@./ui';
import { Meta, StoryFn } from '@storybook/react';

export default {
  title: 'UI/Inputs/CustomSelect',
  component: CustomSelect,
} as Meta<typeof CustomSelect>;

const Template: StoryFn = (args) => (
  <CustomSelect optionsArray={[]} disabledOption={false} {...args} />
);

export const Primary = Template.bind({});
Primary.storyName = 'CustomSelect';
Primary.args = {
  optionsArray: [1, 2, 3, 4],
};
