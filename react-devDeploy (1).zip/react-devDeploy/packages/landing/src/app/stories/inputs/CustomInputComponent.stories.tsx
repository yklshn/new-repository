import { CustomInputComponent } from '@./ui';
import { Meta, StoryFn } from '@storybook/react';

export default {
  title: 'UI/Inputs/CustomInputComponent',
  component: CustomInputComponent,
} as Meta<typeof CustomInputComponent>;

const Template: StoryFn = (args) => (
  <CustomInputComponent
    field={args['field']}
    form={args['form']}
    meta={args['meta']}
    {...args}
  />
);

export const Primary = Template.bind({});
Primary.storyName = 'CustomInputComponent';
Primary.args = {
  field: {
    name: 'input',
  },
  form: { touched: true },
};
