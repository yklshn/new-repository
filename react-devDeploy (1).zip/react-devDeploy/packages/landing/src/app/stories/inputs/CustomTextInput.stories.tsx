import { CustomTextInput } from '@./ui';
import { Meta, StoryFn } from '@storybook/react';

export default {
  title: 'UI/Inputs/CustomTextInput',
  component: CustomTextInput,
} as Meta<typeof CustomTextInput>;

const Template: StoryFn = (args) => <CustomTextInput {...args} />;

export const Primary = Template.bind({});
Primary.storyName = 'CustomTextInput';
Primary.args = {};
