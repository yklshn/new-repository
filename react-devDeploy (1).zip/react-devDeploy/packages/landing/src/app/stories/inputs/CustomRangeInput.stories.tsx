import { CustomRangeInput } from '@./ui';
import { Meta, StoryFn } from '@storybook/react';
import { ChangeEvent, useState } from 'react';

export default {
  title: 'UI/Inputs/CustomRangeInput',
  component: CustomRangeInput,
  argTypes: {
    onChange: {
      description: 'callback для сохранения выбранной суммы',
      control: {
        disable: true,
      },
    },
    value: {
      description: 'Выбранная сумма',
      control: {
        disable: true,
      },
    },
  },
} as Meta<typeof CustomRangeInput>;

const Template: StoryFn<typeof CustomRangeInput> = (args) => {
  const [value, setValue] = useState(0);

  return (
    <>
      <CustomRangeInput
        {...args}
        onChange={(e: any) => {
          args.onChange;
          setValue(e.target.value);
        }}
        value={value}
      />
    </>
  );
};

export const Primary = Template.bind({});
Primary.storyName = 'CustomRangeInput';
Primary.args = {
  minText: '100',
  maxText: '1000000',
  step: 0,
};
