import { Meta, StoryFn } from '@storybook/react';
import { InputPassword } from 'libs/ui/src/lib/Inputs/InputPassword';

export default {
  title: 'UI/Inputs/InputPassword',
  component: InputPassword,
} as Meta<typeof InputPassword>;

const Template: StoryFn = (args) => (
  <InputPassword
    field={args['field']}
    form={args['form']}
    meta={args['meta']}
    {...args}
  />
);

export const Primary = Template.bind({});
Primary.storyName = 'InputPassword';
Primary.args = {
  field: { name: 'password' },
  form: { touched: true },
};
