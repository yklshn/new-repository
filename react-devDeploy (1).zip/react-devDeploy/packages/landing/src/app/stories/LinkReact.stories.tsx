import { Meta, StoryFn } from '@storybook/react';
import { colors } from 'packages/landing/.storybook/preview';
import { BrowserRouter, Route, Router, Routes } from 'react-router-dom';

import { LinkReact } from '../../../../../libs/ui/src/lib/Links/LinkReact';

export default {
  title: 'UI/LinkReact',
  component: LinkReact,
  argTypes: {
    text: {
      name: 'Button text',
      description: 'Add text to button',
      defaultValue: 'Link text',
    },
    color: {
      description: 'color',
      type: 'string',
      ...colors,
    },
  },
  decorators: [
    (story) => (
      <BrowserRouter>
        <Routes>
          <Route path="*" element={story()} />
        </Routes>
      </BrowserRouter>
    ),
  ],
} as Meta<typeof LinkReact>;

const Template: StoryFn = (args) => (
  <LinkReact text={''} color={''} to={''} {...args} />
);

export const Primary = Template.bind({});
Primary.storyName = 'LinkReact';
Primary.args = {
  text: 'Link text',
  color: 'black',
};
