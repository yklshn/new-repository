import { Image } from '@./ui';
import { Meta, StoryFn } from '@storybook/react';
import { colors } from 'packages/landing/.storybook/preview';

import bgImg from '../../../../../libs/ui/img/bg.png';
import cardImg from '../../../../../libs/ui/img/card.png';
import cardBgImg from '../../../../../libs/ui/img/cardBackground.png';
import creditsBgImg from '../../../../../libs/ui/img/creditsBackground.png';
import depositBgImg from '../../../../../libs/ui/img/depositBackground.png';
import calcImg from '../../../../../libs/ui/img/depositCalculator.png';
import img from '../../../../../libs/ui/img/img.png';

export default {
  title: 'UI/Image',
  component: Image,
  argTypes: {
    src: {
      name: 'Image',
      type: 'string',
      control: 'select',
      options: [img, cardImg, calcImg, depositBgImg, cardBgImg, creditsBgImg],
    },
    background: {
      name: 'Background',
      type: 'string',
      ...colors,
    },
  },
} as Meta<typeof Image>;

const Template: StoryFn = (args) => <Image src={img} {...args} />;

export const Primary = Template.bind({});
Primary.storyName = 'Image';
Primary.args = {
  src: img,
  width: '100%',
  height: '100%',
  background: bgImg,
};
