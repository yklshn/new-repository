import { Source } from '@storybook/addon-docs';
import { Meta, StoryFn } from '@storybook/react';

import { Button } from '../../../../../libs/ui/src/lib/Button/Button';
import customDocs from './button.mdx';

export default {
  title: 'UI/Button',
  component: Button,
  parameters: {
    docs: {
      page: customDocs,
    },
  },
  argTypes: {
    onClick: {
      action: 'clicked',
      table: {
        category: 'events',
      },
    },
    variant: {
      description: 'Вариант отображения',
      control: 'radio',
      table: {
        category: 'Style',
      },
    },
    width: {
      description: 'Ширина кнопки',
      control: 'select',
      table: {
        category: 'size',
      },
      options: ['130px', '187px', '343px', '374px', '374px'],
      defaultValue: '187px',
    },
    height: {
      description: 'Высота кнопки',
      control: 'select',
      table: {
        category: 'size',
      },
      options: ['50px'],
      defaultValue: '50px',
    },
    marginTop: {
      description: 'Отступ сверху от кнопки',
      control: 'select',
      table: {
        category: 'Style',
      },
      options: ['0px', '20px', '45px', '57px'],
      defaultValue: '0px',
    },
    disabled: {
      description: 'Заблокирована',
      control: 'boolean',
      table: {
        category: 'Other',
      },
      defaultValue: false,
    },
    style: {
      control: 'none',
      table: {
        category: 'Style',
      },
      description: 'Дополнительные стили',
    },
    children: {
      table: {
        category: 'TEXT',
      },
    },
  },
} as Meta<typeof Button>;

const Template: StoryFn<typeof Button> = (args) => <Button {...args} />;

export const Primary = Template.bind({});
Primary.storyName = 'По умолчанию';
Primary.args = {
  children: 'кнопка',
};
