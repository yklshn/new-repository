import { Meta, StoryFn } from '@storybook/react';
import { Provider } from 'react-redux';

import { TypeSwitcher } from '../../../../../libs/ui/src/lib/TypeSwitcher/TypeSwitcher';
import { setupStore } from '../../toolkitSlices/store';

export default {
  title: 'UI/TypeSwitcher',
  component: TypeSwitcher,
  argTypes: {
    items: {
      name: 'Array of Types',
      description: 'Items user will be switching over',
      table: {
        category: 'items',
      },
      defaultValue: [1, 2],
    },
    headerText: {
      name: 'Header Text',
      table: {
        category: 'title',
      },
      description: 'Title of the TypeSwitcher',
      defaultValue: 'TITLE GOES HERE',
    },
  },
  decorators: [(story) => <Provider store={setupStore()}>{story()}</Provider>],
} as Meta<typeof TypeSwitcher>;

const Template: StoryFn<typeof TypeSwitcher> = (args) => (
  <TypeSwitcher {...args} />
);

export const Primary = Template.bind({});
Primary.storyName = 'По умолчанию';
Primary.args = {
  items: ['Home', 'Emoh', 'Mohe', 'Ehmo', 'Meho'],
  headerText: 'Lorem Ispum',
};
