import { MainForm } from '@./ui';
import { Meta, StoryFn } from '@storybook/react';

export default {
  title: 'UI/MainForm',
  component: MainForm,
} as Meta<typeof MainForm>;

const Temaplate: StoryFn = (args) => <MainForm {...args} />;

export const Primary = Temaplate.bind({});
Primary.storyName = 'MainForm';
