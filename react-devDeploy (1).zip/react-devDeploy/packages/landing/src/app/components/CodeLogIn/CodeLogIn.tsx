import { useEffect } from 'react';
import { useDispatch, useSelector } from 'react-redux';
import { Button, Typography } from '@./ui';
import { setCode, setCountLogIn, setOpenModal } from '@.landing/toolkitRedux';
import { inputSelector } from '@.landing/toolkitRedux';

import { PopupError } from '../PopupError/PopupError';

import styles from './CodeLogIn.module.sass';
import { useTranslation } from 'react-i18next';

export const CodeLogIn = () => {
    const { t } = useTranslation();
    const welcome = t('codeLogIn.0');
    const smsIsSentTo = t('codeLogIn.1');
    const incorrectCode = t('codeLogIn.3');
    const attempts = t('codeLogIn.4');
    const confirmationCode = t('codeLogIn.5');
    const logIn = t('codeLogIn.6');
    const resendCode = t('codeLogIn.7');

    const { openModal, code, countLogIn } = useSelector(inputSelector);
    const dispatch = useDispatch();
    console.log('render');

    // random example
    let number = '79204559531';

    //test
    useEffect(() => {
        let newCurrentTime = new Date();
        let localItemTime = localStorage.getItem('banUntil');
        if (localItemTime! > newCurrentTime.toString()) {
            dispatch(setCountLogIn(0));
            dispatch(setOpenModal(false));
            const id = setInterval(() => {
                if (localItemTime! < new Date().toString()) {
                    dispatch(setCountLogIn(5));
                    dispatch(setOpenModal(false));
                    localStorage.removeItem('banUntil');
                    clearInterval(id);
                }
            }, 1000);
        }
    }, []);
    //test

    useEffect(() => {
        if (countLogIn === 0) {
            dispatch(setOpenModal(true));
        }
    }, [countLogIn]);

    function changeNumber(number: string) {
        let temp = `+${number.slice(0, 3)}********${number.slice(-2)}`;
        return temp;
    }

    function checkCode(code: string) {
        if (code === '1234') {
            dispatch(setCountLogIn(5));
            console.log('Авторизация успешна');
        } else {
            dispatch(setCountLogIn(countLogIn - 1));
        }
    }

    //test
    if (countLogIn === 0 && !localStorage.getItem('banUntil')) {
        let BanTime = new Date();
        // currentTime.setMinutes(currentTime.getMinutes() + 45) // min
        BanTime.setSeconds(BanTime.getSeconds() + 10); // sec
        localStorage.setItem('banUntil', `${BanTime}`);

        let id = setInterval(() => {
            let currentTime = new Date();

            if (currentTime > BanTime) {
                dispatch(setOpenModal(false));
                dispatch(setCountLogIn(5));
                localStorage.removeItem('banUntil');
                clearInterval(id);
            }
        }, 1000);
    }
    //test
    return (
        <>
            <div className={styles['layout']}>
                <div className={styles['authorization']}>
                    <Typography
                        tag={'p'}
                        textAlign={'center'}
                        fontSize={'24px'}
                        fontWeight={'700'}
                        color={'black-v1'}
                    >
                        {welcome}
                    </Typography>
                    <div
                        style={{
                            marginTop: '25px',
                            fontFamily: 'Roboto',
                            fontStyle: 'normal',
                            fontWeight: '400',
                            fontSize: '18px',
                            lineHeight: '25px',
                        }}
                    >
                        {smsIsSentTo} {changeNumber(number)}
                    </div>

                    <span className={styles['wrapper']}>
                        <input
                            placeholder={'Введите код'}
                            className={styles['input-code']}
                            value={code}
                            onChange={(e) =>
                                dispatch(setCode(e.currentTarget.value))
                            }
                        />
                        {countLogIn < 5 ? (
                            <Typography
                                marginTop={'5px'}
                                tag={'p'}
                                fontSize={'12px'}
                                color={'red-error'}
                            >
                                {`${incorrectCode} ${countLogIn} 
                                ${attempts}`}
                            </Typography>
                        ) : null}

                        <div className={styles['input-absolute']}>
                            {confirmationCode}
                        </div>
                    </span>
                    <Button
                        marginTop={'20px'}
                        disabled={!(code && countLogIn !== 0)}
                        width={'343px'}
                        onClick={() => checkCode(code)}
                    >
                        {logIn}
                    </Button>
                    <div
                        style={{
                            color: '#3C55AC',
                            marginTop: '28px',
                            fontSize: '16px',
                            cursor: 'pointer',
                        }}
                    >
                        {resendCode}
                    </div>
                    {openModal && <PopupError dispatch={dispatch} />}
                </div>
            </div>
        </>
    );
};
