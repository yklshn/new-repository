import { Button, Typography } from '@./ui';
import { Image } from '@./ui';
import { Additional } from 'libs/ui/src/lib/Calculators/CalculatorForDeposit/Additional/Additional';
import { Currency } from 'libs/ui/src/lib/Calculators/CalculatorForDeposit/Currency/Currency';
import { Duration } from 'libs/ui/src/lib/Calculators/CalculatorForDeposit/Duration/Duration';
import { Sum } from 'libs/ui/src/lib/Calculators/CalculatorForDeposit/Sum/Sum';
import { Spinner } from 'libs/ui/src/lib/Spinner/Spinner';
import { ChangeEvent, useState } from 'react';

import styles from './CalculatorForDeposit.module.sass';
import depositCalculatorImage from '/libs/ui/img/depositCalculator.png';
import cardBackground from '/libs/ui/img/universalDeposit.png';

export type DepositObject = {
  currencyName: string;
  sumMin: string | number;
  sumMax: string | number;
  depositTermList: number[];
};

type DepositFounded = {
  id: string | number;
  percent: string | number;
  name: string;
  depositTerm: string;
  percentToCard: string;
};

type DepositCalculator = {
  headerText?: string;
  headerColor?: string;
  buttonText?: string;
  depositsData: DepositObject[];
};

export const CalculatorForDeposit = ({
  headerText,
  headerColor,
  buttonText,
  depositsData,
}: DepositCalculator) => {
  const [selectedDeposit, setSelectedDeposit] = useState<DepositObject[]>([
    {
      currencyName: 'RUB',
      sumMin: 100,
      sumMax: 1000000,
      depositTermList: [6, 12, 18, 36, 72, 120],
    },
  ]);

  const [sumValue, setSumValue] = useState(selectedDeposit[0].sumMin);
  const [additionalValue, setAdditionalValue] = useState('0');
  const [durationValue, setDurationValue] = useState('0');
  const [userIsReady, setUserIsReady] = useState<object>({
    currency: false,
    sum: false,
    duration: false,
    additional: false,
  });

  const [foundedDepositsArray, setFoundedDepositsArray] = useState<
    DepositFounded[]
  >([]);
  const [loading, setLoading] = useState(false);

  const handleChangeDeposit = (e: ChangeEvent<HTMLSelectElement>) => {
    const filteredArray = depositsData.filter(
      (item) => item.currencyName === e.target.value
    );

    setSelectedDeposit(filteredArray);
    setUserIsReady((prev) => ({ ...prev, currency: true }));
  };

  const handleSumValue = (e: ChangeEvent<HTMLSelectElement>) => {
    setSumValue(e.target.value);
    setUserIsReady((prev) => ({ ...prev, sum: true }));
  };

  const handleDurationValue = (e: ChangeEvent<HTMLSelectElement>) => {
    const value = +e.target.value;
    let setValue: string = '0';
    if (value >= 6 && value < 12) {
      setValue = '6';
    } else if (value >= 12 && value < 18) {
      setValue = '12';
    } else if (value >= 18 && value < 36) {
      setValue = '18';
    } else if (value >= 36 && value < 54) {
      setValue = '36';
    } else if (value >= 54 && value < 96) {
      setValue = '72';
    } else if (value > 72) {
      setValue = '120';
    }
    setUserIsReady((prev) => ({ ...prev, duration: true }));
    setDurationValue(setValue);
  };

  const handleAdditionalValue = (e: ChangeEvent<HTMLSelectElement>) => {
    setUserIsReady((prev) => ({ ...prev, additional: true }));
    setAdditionalValue(e.target.value);
  };

  // const handleCalculationSubmit = (e: React.MouseEvent<HTMLButtonElement, MouseEvent>) => {
  const handleCalculationSubmit = (e: any) => {
    setLoading(true);
    fetch(
      `http://10.10.15.227/api/v1/deposits/deposit-types/selection?sum=${sumValue}&depositTerm=${durationValue}&currencyName=${selectedDeposit[0].currencyName}`,
      {
        method: 'GET',
        headers: {
          accept: 'application/json',
        },
      }
    )
      .then((response) => response.json())
      .then((data) => {
        setFoundedDepositsArray(data);
        setLoading(false);
      });
  };

  return (
    <>
      <div className={styles['calculator-wrapper']}>
        <Typography
          tag={'h3'}
          fontSize={'size44'}
          fontWeight={'weight700'}
          color={headerColor}
          lineHeight={'120'}
        >
          {headerText}
        </Typography>
        <div className={styles['wrap']}>
          <div className={styles['inputs']}>
            <Currency
              title={'Валюта'}
              depositsData={depositsData}
              handleChangeDeposit={handleChangeDeposit}
            />

            <Sum
              title={'Сумма вклада'}
              selectedDeposit={selectedDeposit}
              sumValue={sumValue}
              handleSumValue={handleSumValue}
            />

            <Duration
              title={'Срок вклада'}
              durationValue={durationValue}
              handleDurationValue={handleDurationValue}
              selectedDeposit={selectedDeposit}
            />

            <Additional
              title={'Дополнительные условия'}
              handleAdditionalValue={handleAdditionalValue}
            />

            {Object.values(userIsReady).every((item) => item) ? (
              <Button variant="primary" onClick={handleCalculationSubmit}>
                {buttonText}
              </Button>
            ) : (
              <Button variant="primary" disabled>
                {buttonText}
              </Button>
            )}
          </div>
          <div className={styles['image']}>
            <Image src={depositCalculatorImage} />
          </div>
        </div>
      </div>

      <Spinner
        loading={loading}
        text={'Загружаем вклады по Вашему запросу...'}
      />

      {foundedDepositsArray.length > 0 && (
        <div className={styles['founded']}>
          <Typography
            tag={'span'}
            fontSize={'size44'}
            fontWeight={'weight700'}
            color={headerColor}
            lineHeight={'120'}
          >
            {'Вам подходит'}
          </Typography>
          {/* {foundedDepositsArray.map((item) => (
                        <OfferCard
                            key={item.id}
                            id={item.id.toString()}
                            leftColumnHeader={'Проценты'}
                            middleColumnHeader={'Срок'}
                            rightColumnHeader={'Выплата процентов'}
                            cardImage={cardBackground}
                            needMoreInfo={false}
                            headerText={`Вклад ${item.name}`}
                            typeOf={'deposits'}
                            leftColumnTitle={`до ${item.percent}% годовых`}
                            primaryButtonText={'Оформить'}
                            secondaryButtonText={'Подробнее о вкладе'}
                            cardImageWidth={353}
                            cardImageHeight={208}
                            middleColumnTitle={`${item.depositTerm} месяцев`}
                            rightColumnTitle={
                                item.percentToCard
                                    ? 'Выплата процентов на карту'
                                    : 'Выплата на карту невозможна'
                            }
                        />
                    ))} */}
        </div>
      )}
    </>
  );
};
