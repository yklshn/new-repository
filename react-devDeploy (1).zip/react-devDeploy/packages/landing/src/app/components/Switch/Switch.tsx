import React from 'react';

import { useDispatch, useSelector } from 'react-redux';
import { inputSelector, setKindLog } from '@.landing/toolkitRedux';
import { useTranslation } from 'react-i18next';

import styles from './Switch.module.sass';

export const Switch: React.FC = (): JSX.Element => {
    const dispatch = useDispatch();
    const { kindLog } = useSelector(inputSelector);
    const { t } = useTranslation();

    const loginText = t('switch.login.0');
    const phoneNumber = t('switch.phoneNumber.0');

    const onCLick = () => {
        dispatch(setKindLog('Логин'));
    };

    return (
        <>
            <div className={styles['kindLogIn']}>
                <div
                    onClick={onCLick}
                    className={
                        styles[
                            `${kindLog === 'Логин' ? 'activeKindLog' : null}`
                        ]
                    }
                >
                    {loginText}
                </div>
                <div
                    onClick={() => dispatch(setKindLog('Номер телефона'))}
                    className={
                        styles[
                            `${
                                kindLog === 'Номер телефона'
                                    ? 'activeKindLog'
                                    : null
                            }`
                        ]
                    }
                >
                    {phoneNumber}
                </div>
            </div>
        </>
    );
};
