import { Typography } from '@./ui';
import { useTranslation } from 'react-i18next';

type FooterTel = {
  tel: string;
  info: string;
};

export const FooterInfo = ({ tel, info }: FooterTel) => {
  const { t } = useTranslation();

  return (
    <>
      <Typography
        tag={'p'}
        fontSize={'20px'}
        lineHeight={'19px'}
        fontWeight={'700'}
        color={'white'}
      >
        {tel}
      </Typography>
      <Typography
        tag={'p'}
        fontSize={'14px'}
        marginTop={'5px'}
        fontWeight={'400'}
        color={'white'}
      >
        {info}
      </Typography>
    </>
  );
};
