import React from 'react';

import backgroundImage from '../../../../../../libs/ui/img/depositBackground.png';

import { Button, Typography, Image } from '@./ui';
// import backgroundImage from '@./ui/img/depositBackground.png';

import styles from './MainOffer.module.sass';

type MainOffer = {
    headerText?: string;
    headerColor?: string;
    subheaderText?: string;
    subheaderColor?: string;
    buttonText?: string;
    backgroundImage: string;
};

export const Offer = ({
    headerText,
    headerColor,
    subheaderText,
    subheaderColor,
    buttonText,
    backgroundImage,
}: MainOffer) => {
    return (
        <div className={styles['wrap']}>
            <div className={styles['text']}>
                <Typography
                    tag={'span'}
                    fontSize={'size60'}
                    fontWeight={'weight700'}
                    color={headerColor}
                    width={'530px'}
                >
                    {headerText}
                </Typography>
                <Typography
                    tag={'span'}
                    fontSize={'size22'}
                    color={subheaderColor}
                    width={'526px'}
                >
                    {subheaderText}
                </Typography>
                <Button variant="primary">{buttonText}</Button>
            </div>
            <Image
                src={backgroundImage}
                width={953}
                height={505}
                className={styles['background']}
            />
        </div>
    );
};
