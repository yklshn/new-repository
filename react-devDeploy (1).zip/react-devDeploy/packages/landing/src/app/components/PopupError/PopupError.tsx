import { useEffect, useRef } from 'react';
import * as ReactDOM from 'react-dom';
import { useTranslation } from 'react-i18next';

import close from '/libs/img/close.svg';
import errorPopupImg from '/libs/img/errorPopup.png';

import { Button, Image, Typography } from '@./ui';
import { setOpenModal } from '@.landing/toolkitRedux';
import { setupStore } from 'packages/landing/src/toolkitSlices/store';

import styles from './PopupError.module.sass';

const store = setupStore();

type PopupProps = {
    dispatch: typeof store.dispatch;
};

const modalRoot: HTMLElement | null = document.querySelector('#root');

export const PopupError = ({ dispatch }: PopupProps) => {
    const rootElementRef = useRef(document.createElement('div'));
    const { t } = useTranslation()

    const errorInformation = t('popupError.0')
    const errorHint = t('popupError.1')
    const errorConfirm = t('popupError.2')

    useEffect(() => {
        const current = rootElementRef.current;
        modalRoot?.appendChild(current);
        document.body.style.overflow = 'hidden';

        return () => {
            modalRoot?.removeChild(current);
            document.body.style.overflow = 'auto';
        };
    }, []);

    return ReactDOM.createPortal(
        <div className={styles['mainModal']}>
            <div className={styles['content']}>
                <img
                    className={styles['close']}
                    onClick={() => dispatch(setOpenModal(false))}
                    src={close}
                    alt="close"
                />
                <Image width={327} height={233} src={errorPopupImg} alt="" />
                <Typography fontWeight={700} marginTop={'40px'}>
                    {errorInformation}
                </Typography>
                <div
                    style={{
                        width: '300px',
                        textAlign: 'center',
                        lineHeight: '25px',
                        fontSize: '18px',
                        marginTop: '40px',
                    }}
                >
                    {errorHint}
                </div>
                <Button
                    onClick={() => dispatch(setOpenModal(false))}
                    width={'374px'}
                    marginTop={'45px'}
                >
                    {errorConfirm}
                </Button>
            </div>
        </div>,
        rootElementRef.current
    );
};
