import React from 'react';

import { Typography } from '@./ui';
import { NavLink } from 'react-router-dom';

import styles from './MainNavigation.module.sass';

export type MainNavigation = {
    items: Array<string>;
    linkTo: string;
    headerText?: string;
};

export const TypeSwitcher = ({ items, headerText, linkTo }: MainNavigation) => {
    return (
        <div className={styles['wrapper']}>
            {headerText ? (
                <div className="">
                    <Typography
                        tag={'span'}
                        fontSize={'size44'}
                        fontWeight={'weight700'}
                    >
                        {headerText}
                    </Typography>
                </div>
            ) : (
                <></>
            )}
            <div className={styles['wrapper-options']}>
                {items.map((item) => {
                    return (
                        <NavLink
                            className={styles['item']}
                            to={linkTo}
                            key={item}
                        >
                            <Typography tag={'span'}>{item}</Typography>
                        </NavLink>
                    );
                })}
            </div>
        </div>
    );
};
