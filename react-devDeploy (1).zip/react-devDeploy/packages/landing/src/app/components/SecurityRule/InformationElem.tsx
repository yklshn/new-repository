import { Typography } from '@./ui';

import styles from './SecurityRule.module.sass';

interface InformationElemProps {
    title: string;
    description: string;
}

export const InformationElem = (props: InformationElemProps) => {
    return (
        <div className={styles['informationElement']}>
            <Typography
                tag={'p'}
                fontSize={'20px'}
                lineHeight={'19px'}
                fontWeight={'700'}
                color={'black'}
            >
                {props.title}
            </Typography>
            <Typography
                tag={'p'}
                fontSize={'14px'}
                marginTop={'10px'}
                lineHeight={'19px'}
                color={'black'}
            >
                {props.description}
            </Typography>
        </div>
    );
};
