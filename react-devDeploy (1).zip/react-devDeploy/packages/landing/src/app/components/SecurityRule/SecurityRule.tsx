import { useTranslation } from 'react-i18next';

import { InformationElem } from './InformationElem';
import { Typography } from '@./ui';

import styles from './SecurityRule.module.sass';

export const SecurityRule = () => {

    const { t } = useTranslation()

    const securityRule = t('securityRule.data.0')
    const securityRuleHint = t('securityRule.data.1')
    const passwordRule = t('securityRule.data.2')
    const passwordRuleHint = t('securityRule.data.3')
    const systemRule = t('securityRule.data.4')
    const systemRuleHint = t('systemRuleHint.data.5')
    const scammerRule = t('securityRule.data.6')
    const scammerRuleHint = t('securityRule.data.7')
    const safetyRule = t('securityRule.securityRule.0')

    const data = [
        [
            securityRule,
            securityRuleHint,
        ],
        [
            passwordRule,
            passwordRuleHint,
        ],
        [
            systemRule,
            systemRuleHint,
        ],
        [
            scammerRule,
            scammerRuleHint,
        ],
    ];

    return (
        <div className={styles['container']}>
            <Typography
                tag={'h2'}
                fontSize={'44px'}
                fontWeight={'700'}
                marginTop={'80px'}
                color={'black'}
            >
                {safetyRule}
            </Typography>

            <div className={styles['flexElements']}>
                {data.map((el, i) => {
                    return (
                        <InformationElem
                            key={i}
                            title={el[0]}
                            description={el[1]}
                        />
                    );
                })}
            </div>
        </div>
    );
};
