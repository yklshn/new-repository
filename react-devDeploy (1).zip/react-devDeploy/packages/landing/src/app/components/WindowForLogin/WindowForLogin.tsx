import { useDispatch, useSelector } from 'react-redux';

import { Typography, LinkReact, Button, CustomInputComponent } from '@./ui';
import { FormikProps, useFormik } from 'formik';
import { Switch } from '@./landing';
import { inputSelector, setShowSMS } from '@.landing/toolkitRedux';
import { InputPassword } from '../../../../../../libs/ui/src/lib/Inputs/InputPassword';
import * as Yup from 'yup';
import { t } from 'i18next';

import styles from './WindowForLogin.module.sass';


export type FormValues = {
    loginValue: string;
    passwordValue: string;
};

const initialValues: FormValues = {
    loginValue: '',
    passwordValue: '',
};

const onSubmit = (values: FormValues) => {
    // console.log('All our data ', values)
};

    const loginValueMin = t('windowForLogin.login.0')
    const loginValueMax = t('windowForLogin.login.1')
    const loginValueMatch = t('windowForLogin.login.2')
    const loginValueRequired = t('windowForLogin.login.3')

    const passwordMin = t('windowForLogin.passwordValue.0')
    const passwordMax = t('windowForLogin.passwordValue.1')
    const passwordOnlyLatin = t('windowForLogin.passwordValue.2')
    const passwordMinOneLatin = t('windowForLogin.passwordValue.3')
    const passwordMinOneNumber = t('windowForLogin.passwordValue.4')
    const passwordRequired = t('windowForLogin.passwordValue.5')

    const greeting = t('windowForLogin.greeting.0')
    
    const placeholderLogin = t('windowForLogin.placeholderLoginText.0')
    const placeholderLoginText = t('windowForLogin.placeholderLoginText.1')
    const placeholderPassword = t('windowForLogin.placeholderPasswordText.0')
    const placeholderPasswordText = t('windowForLogin.placeholderPasswordText.1')
    const placeholderText = t('windowForLogin.placeholderText.0')

// test code
const onlyNumbersRegex = /^\d+$/;
const minOneNumber = /[0-9]+/;
const onlyLatinRegex = /^[a-z0-9]+$/i;
const minOneLatinRegex = /[A-z]+/;

const SignupSchema = Yup.object().shape({
    loginValue: Yup.string()
        .min(7, loginValueMin)
        .max(20, loginValueMax)
        .matches(onlyNumbersRegex, loginValueMatch)
        .required(loginValueRequired),

    passwordValue: Yup.string()
        .min(7, passwordMin)
        .max(20, passwordMax)
        .matches(
            onlyLatinRegex,
            passwordOnlyLatin
        )
        .matches(
            minOneLatinRegex,
            passwordMinOneLatin
        )
        .matches(minOneNumber, passwordMinOneNumber)
        .required(passwordRequired),
});
// test code

export const WindowForLogin = () => {
    const dispatch = useDispatch();
    const { kindLog } = useSelector(inputSelector);

    const formik: FormikProps<FormValues> = useFormik<FormValues>({
        initialValues,
        onSubmit,
        validationSchema: SignupSchema,
    });

    let logIn =
        formik.values.passwordValue &&
        formik.values.loginValue &&
        !formik.errors.passwordValue &&
        !formik.errors.loginValue;
    // console.log(formik.touched.loginValue)
    // console.log(formik.touched.loginValue)
    return (
        <>
            <div className={styles['layout']}>
                <div className={styles['authorization']}>
                    <Typography
                        tag={'p'}
                        textAlign={'center'}
                        fontSize={'24px'}
                        fontWeight={'700'}
                        color={'black-v1'}
                    >
                        {greeting}
                    </Typography>
                    <Switch />

                    {kindLog === 'Логин' ? (
                        <>
                            <CustomInputComponent
                                type={'text'}
                                label={placeholderLogin}
                                form={formik}
                                field={{
                                    name: 'loginValue',
                                    value: formik.values.loginValue,
                                    onBlur: formik.handleBlur,
                                    onChange: formik.handleChange,
                                }}
                                meta={{
                                    value: formik,
                                    error: formik.errors.loginValue,
                                    initialError: '',
                                    initialTouched: false,
                                    touched: false,
                                    initialValue: formik.values,
                                }}
                                placeholder={placeholderLoginText}
                            />
                            <InputPassword
                                label={placeholderPassword}
                                form={formik}
                                field={{
                                    name: 'passwordValue',
                                    value: formik.values.passwordValue,
                                    onBlur: formik.handleBlur,
                                    onChange: formik.handleChange,
                                }}
                                meta={{
                                    value: formik,
                                    error: formik.errors.passwordValue,
                                    initialError: '',
                                    initialTouched: false,
                                    touched: false,
                                    initialValue: formik.values,
                                }}
                                placeholder={placeholderPasswordText}
                            />
                            {/*<InputPassword type={'text'}*/}
                            {/*               label={'Пароль'}*/}
                            {/*               form={formik}*/}
                            {/*               field={{name: 'passwordValue', value: formik.values.passwordValue, onBlur: formik.handleBlur, onChange: formik.handleChange}}*/}
                            {/*               meta={{value: formik,error: formik.errors.passwordValue ,initialError:'',initialTouched:false,touched: false,initialValue: formik.values}}*/}
                            {/*               placeholder={'Введите пароль'}*/}
                            {/*/>*/}
                        </>
                    ) : (
                        <>
                            <CustomInputComponent
                                type={'text'}
                                label={placeholderPassword}
                                form={formik}
                                field={{
                                    name: 'passwordValue',
                                    value: formik.values.passwordValue,
                                    onBlur: formik.handleBlur,
                                    onChange: formik.handleChange,
                                }}
                                meta={{
                                    value: formik,
                                    error: formik.errors.passwordValue,
                                    initialError: '',
                                    initialTouched: false,
                                    touched: false,
                                    initialValue: formik.values,
                                }}
                                placeholder={placeholderPassword}
                            />
                        </>
                    )}

                    <Button
                        onClick={() => dispatch(setShowSMS('SMS'))}
                        marginTop={'20px'}
                        disabled={!logIn}
                        width={'343px'}
                    >
                        Войти
                    </Button>

                    <LinkReact
                        color={'blue'}
                        to={'#'}
                        text={placeholderText}
                    />
                </div>
            </div>
        </>
    );
};
