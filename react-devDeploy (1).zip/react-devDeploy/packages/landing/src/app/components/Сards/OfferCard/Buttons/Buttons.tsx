import { Link } from 'react-router-dom';

import { Button } from '@./ui';

import styles from './Buttons.module.sass';

type CardButtonsProps = {
    id?: string;
    needMoreInfo: boolean;
    primaryButtonText?: string;
    secondaryButtonText?: string;
    typeOf?: string;
};

export const Buttons = ({
    id,
    needMoreInfo,
    primaryButtonText,
    secondaryButtonText,
    typeOf,
}: CardButtonsProps) => {
    return (
        <div className={styles['card-buttons']}>
            {primaryButtonText && (
                <Link to={`/authorization`}>
                    <Button>{primaryButtonText}</Button>
                </Link>
            )}

            {needMoreInfo ? (
                <Link to={`/${typeOf}/${id}`}>
                    <Button variant="secondary">{secondaryButtonText}</Button>
                </Link>
            ) : (
                <></>
            )}
        </div>
    );
};
