import { Link } from 'react-router-dom';

import { Button } from '@./ui';

import styles from './Buttons.module.sass';

type CardButtonsProps = {
  id?: string;
  needMoreInfo: boolean;
  primaryButtonText?: string;
  secondaryButtonText?: string;
  typeOf?: string;
};

export const Buttons = ({
                          id,
                          needMoreInfo,
                          primaryButtonText,
                          secondaryButtonText,
                          typeOf,
                        }: CardButtonsProps) => {
  const onCardOpen = () => {
    console.log('card send in progress(dispatch)');
  };

    return (
        <div className={styles['card-buttons']}>
            <Link to={`/${typeOf}/${id}`}>
              <Button width={'374px'}>
                {primaryButtonText}
              </Button>
            </Link>

            {needMoreInfo && (
                <Link to={`/credits`}>
                    <Button variant="secondary" onClick={onCardOpen}>
                        {secondaryButtonText}
                    </Button>
                </Link>
            )}
        </div>
    );
};
