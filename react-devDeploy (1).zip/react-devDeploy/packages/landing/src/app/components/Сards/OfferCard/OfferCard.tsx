import { Buttons } from './Buttons/Buttons';
import { Header } from './Header/Header';
import { CImage } from './Image/Image';
import { Text } from './Text/Text';

import styles from './OfferCard.module.sass';

type CardProps = {
    id: string;
    cardImageWidth?: string | number;
    cardImageHeight?: string | number;
    cardImage: string;
    leftColumnHeader: string;
    leftColumnTitle?: string;
    leftColumnSubtitle?: string;
    middleColumnHeader: string;
    middleColumnTitle?: string;
    middleColumnSubtitle?: string;
    rightColumnHeader: string;
    rightColumnTitle?: string;
    rightColumnSubtitle?: string;
    primaryButtonText?: string;
    secondaryButtonText?: string;
    headerText?: string;
    cardNumber?: string;
    needMoreInfo: boolean;
    background?: string;
    typeOf?: string;
    depositCurrency?: string;
    depositSumMin?: string;
    depositSumMax?: string;
    depositTerm?: string;
    depositEarlyClosed?: boolean;
    depositReplenishingBalancePossibility?: boolean;
    depositFullDescription?: string;
};

export const OfferCard = ({
    id,
    headerText,
    cardImageHeight,
    cardImageWidth,
    cardImage,
    leftColumnHeader,
    leftColumnTitle,
    leftColumnSubtitle,
    middleColumnHeader,
    middleColumnTitle,
    middleColumnSubtitle,
    rightColumnHeader,
    rightColumnTitle,
    rightColumnSubtitle,
    cardNumber,
    needMoreInfo,
    background,
    primaryButtonText,
    secondaryButtonText,
    typeOf,
    depositCurrency,
    depositSumMin,
    depositSumMax,
    depositTerm,
    depositEarlyClosed,
    depositReplenishingBalancePossibility,
    depositFullDescription,
}: CardProps) => {
    const cardTitle = headerText?.split(' ').slice(2);

    return (
        <div className={styles['wrap']}>
            <CImage
                cardNumber={cardNumber}
                cardTitle={cardTitle}
                background={background}
                cardImageWidth={Number(cardImageWidth)}
                cardImageHeight={Number(cardImageHeight)}
                cardImage={cardImage}
            />
            <div className={styles['card-contains']}>
                <Header headerText={headerText} color="black" />
                <Text
                    leftColumnHeader={leftColumnHeader}
                    leftColumnTitle={leftColumnTitle}
                    leftColumnSubtitle={leftColumnSubtitle}
                    middleColumnHeader={middleColumnHeader}
                    middleColumnTitle={middleColumnTitle}
                    middleColumnSubtitle={middleColumnSubtitle}
                    rightColumnHeader={rightColumnHeader}
                    rightColumnTitle={rightColumnTitle}
                    rightColumnSubtitle={rightColumnSubtitle}
                    headerColor="black"
                    subheaderColor="grey"
                />
                {/* <Buttons
                    id={id}
                    needMoreInfo={needMoreInfo}
                    headerText={headerText}
                    leftColumnHeader={leftColumnHeader}
                    leftColumnTitle={leftColumnTitle}
                    leftColumnSubtitle={leftColumnSubtitle}
                    middleColumnHeader={middleColumnHeader}
                    middleColumnTitle={middleColumnTitle}
                    middleColumnSubtitle={middleColumnSubtitle}
                    rightColumnHeader={rightColumnHeader}
                    rightColumnTitle={rightColumnTitle}
                    rightColumnSubtitle={rightColumnSubtitle}
                    primaryButtonText={primaryButtonText}
                    secondaryButtonText={secondaryButtonText}
                    cardNumber={cardNumber}
                    cardTitle={cardTitle}
                    background={background}
                    typeOf={typeOf}
                    depositCurrency={depositCurrency}
                    depositSumMin={depositSumMin}
                    depositSumMax={depositSumMax}
                    depositTerm={depositTerm}
                    depositEarlyClosed={depositEarlyClosed}
                    depositReplenishingBalancePossibility={
                        depositReplenishingBalancePossibility
                    }
                    depositFullDescription={depositFullDescription}
                /> */}
            </div>
        </div>
    );
};
