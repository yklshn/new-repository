import { Typography } from '@./ui';

import styles from './Text.module.sass';

type CardTextProps = {
    leftColumnHeader: string;
    leftColumnHeader1?: string;
    leftColumnTitle?: string;
    leftColumnTitle1?: string;
    leftColumnSubtitle?: string;
    middleColumnHeader: string;
    middleColumnTitle?: string;
    middleColumnSubtitle?: string;
    rightColumnHeader: string;
    rightColumnTitle?: string;
    rightColumnSubtitle?: string;
    headerColor?: string;
    subheaderColor?: string;
};

export const Text = ({
    leftColumnHeader,
    leftColumnHeader1,
    leftColumnTitle,
    leftColumnTitle1,
    leftColumnSubtitle,
    middleColumnHeader,
    middleColumnTitle,
    middleColumnSubtitle,
    rightColumnHeader,
    rightColumnTitle,
    rightColumnSubtitle,
    headerColor,
    subheaderColor,
}: CardTextProps) => {
    return (
        <>
            <div className={styles['cards']}>
                <div className={styles['cards-text']}>
                    <Typography
                        tag={'h3'}
                        fontSize={'20px'}
                        fontWeight={'weight700'}
                        color={headerColor}
                    >
                        {leftColumnHeader1}
                    </Typography>
                    <Typography
                        tag={'h3'}
                        fontSize={'20px'}
                        fontWeight={'weight700'}
                        color={headerColor}
                        lineHeight={'140'}
                    >
                        {leftColumnTitle1}
                    </Typography>
                    {leftColumnSubtitle && (
                        <Typography
                            tag={'span'}
                            fontSize={'14px'}
                            color={subheaderColor}
                            lineHeight={'140'}
                        >
                            {leftColumnSubtitle}
                        </Typography>
                    )}
                </div>
              <div className={styles['cards-text']}>
                    <Typography
                        tag={'h3'}
                        fontSize={'20px'}
                        fontWeight={'weight400'}
                        color={headerColor}
                        marginTop={'20px'}
                    >
                        {leftColumnHeader}
                    </Typography>
                    <Typography
                        tag={'span'}
                        fontSize={'20px'}
                        color={subheaderColor}
                        lineHeight={'140'}
                        marginTop={'20px'}
                    >
                        {leftColumnTitle}
                    </Typography>
                    {leftColumnSubtitle && (
                        <Typography
                            tag={'span'}
                            fontSize={'20px'}
                            color={subheaderColor}
                            lineHeight={'140'}
                        >
                            {leftColumnSubtitle}
                        </Typography>
                    )}
                </div>
                <div className={styles['cards-text']}>
                    <Typography
                        tag={'h3'}
                        fontSize={'20px'}
                        fontWeight={'weight400'}
                        mb="100px"
                        color={headerColor}
                    >
                        {middleColumnHeader}
                    </Typography>
                    <Typography
                        tag={'span'}
                        fontSize={'20px'}
                        color={subheaderColor}
                        lineHeight={'140'}
                    >
                        {middleColumnTitle}
                    </Typography>
                    {middleColumnSubtitle && (
                        <Typography
                            tag={'span'}
                            fontSize={'20px'}
                            color={subheaderColor}
                            lineHeight={'140'}
                        >
                            {middleColumnSubtitle}
                        </Typography>
                    )}
                </div>
                <div className={styles['cards-text']}>
                    <Typography
                        tag={'h3'}
                        fontSize={'20px'}
                        fontWeight={'weight400'}
                        color={headerColor}
                    >
                        {rightColumnHeader}
                    </Typography>
                    <Typography
                        tag={'span'}
                        fontSize={'20px'}
                        color={subheaderColor}
                        lineHeight={'140'}
                    >
                        {rightColumnTitle}
                    </Typography>
                    {rightColumnSubtitle && (
                        <Typography
                            tag={'span'}
                            fontSize={'20px'}
                            color={subheaderColor}
                            lineHeight={'140'}
                        >
                            {rightColumnSubtitle}
                        </Typography>
                    )}
                </div>
            </div>
        </>
    );
};
