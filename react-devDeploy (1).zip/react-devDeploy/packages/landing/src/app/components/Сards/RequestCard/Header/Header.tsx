import { Typography } from '@./ui';

import styles from './Header.module.sass';

type CardHeaderProps = {
    headerText?: string;
    color?: string;
};

export const Header = ({ headerText = 'Заявка 1', color = 'black' }: CardHeaderProps) => {
    return (
        <div className={styles['card-header']}>
            <Typography
                tag={'span'}
                fontSize={'size32'}
                fontWeight={'weight700'}
                color={color}
            >
                {headerText}
            </Typography>
        </div>
    );
};
