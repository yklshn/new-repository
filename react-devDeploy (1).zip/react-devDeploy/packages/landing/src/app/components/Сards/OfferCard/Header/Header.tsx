import { Typography } from '@./ui';

import styles from './Header.module.sass';

type CardHeaderProps = {
    headerText?: string;
    color?: string;
};

export const Header = ({ headerText, color }: CardHeaderProps) => {
    return (
        <div className={styles['card-header']}>
            <Typography
                tag={'span'}
                fontSize={'32px'}
                fontWeight={'weight700'}
                color={color}
            >
                {headerText}
            </Typography>
        </div>
    );
};
