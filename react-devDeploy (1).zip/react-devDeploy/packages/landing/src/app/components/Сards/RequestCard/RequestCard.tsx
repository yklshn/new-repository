import {Buttons} from './Buttons/Buttons';
import {CImage} from './Image/Image';
import {Text} from './Text/Text';
import {Image, Typography} from "@./ui";
import styles from './RequestCard.module.sass';

type RequestCardType = {
  image: JSX.Element;
  header: JSX.Element;
  text: JSX.Element;
  btn: JSX.Element;
  cardStatusIcon: string | undefined;
  typeOf?: string;
}
export const RequestCard = ({image, header, text, btn, cardStatusIcon}: RequestCardType) => {
  return (
    <>
      <Typography tag={'h1'}>
        <div className={styles['header-section']}>
          <h1>{header}</h1>
          <div className={styles['status-icon']}>
            <Image src={cardStatusIcon} width={25} height={25}/>
          </div>
        </div>
      </Typography>
      <div className={styles['wrap']}>
        {image}
        <div className={styles['card-contains']}>
          {text}
          {btn}
        </div>
      </div>
    </>
  );
};
