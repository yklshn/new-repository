import styles from './OfferCard.module.sass';

type OfferCardType = {
    image: JSX.Element;
    header: JSX.Element;
    text: JSX.Element;
    btn: JSX.Element;
};

export const OfferCard = ({ image, header, text, btn }: OfferCardType) => {
    return (
        <div className={styles['wrap']}>
            {image}
            <div className={styles['card-contains']}>
                {header}
                {text}
                {btn}
            </div>
        </div>
    );
};
