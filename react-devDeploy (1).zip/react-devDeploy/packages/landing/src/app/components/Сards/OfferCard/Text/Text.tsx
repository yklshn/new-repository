import { Typography } from '@./ui';

import styles from './Text.module.sass';

type CardTextProps = {
    leftColumnHeader: string;
    leftColumnTitle?: string;
    leftColumnSubtitle?: string;
    middleColumnHeader: string;
    middleColumnTitle?: string;
    middleColumnSubtitle?: string;
    rightColumnHeader?: string;
    rightColumnTitle?: string;
    rightColumnSubtitle?: string;
    headerColor?: string;
    subheaderColor?: string;
};

export const Text = ({
    leftColumnHeader,
    leftColumnTitle,
    leftColumnSubtitle,
    middleColumnHeader,
    middleColumnTitle,
    middleColumnSubtitle,
    rightColumnHeader,
    rightColumnTitle,
    rightColumnSubtitle,
    headerColor,
    subheaderColor,
}: CardTextProps) => {
    return (
        <div className={styles['cards']}>
            <div className={styles['cards-text']}>
                <Typography
                    tag={'h3'}
                    fontSize={'20px'}
                    fontWeight={'weight700'}
                    color={headerColor}
                >
                    {leftColumnHeader}
                </Typography>
                <Typography
                    tag={'span'}
                    fontSize={'14px'}
                    color={subheaderColor}
                    lineHeight={'140'}
                >
                    {leftColumnTitle}
                </Typography>
                {leftColumnSubtitle && (
                    <Typography
                        tag={'span'}
                        fontSize={'14px'}
                        color={subheaderColor}
                        lineHeight={'140'}
                    >
                        {leftColumnSubtitle}
                    </Typography>
                )}
            </div>
            <div className={styles['cards-text']}>
                <Typography
                    tag={'h3'}
                    fontSize={'20px'}
                    fontWeight={'weight700'}
                    mb="100px"
                    color={headerColor}
                >
                    {middleColumnHeader}
                </Typography>
                <Typography
                    tag={'span'}
                    fontSize={'14px'}
                    color={subheaderColor}
                    lineHeight={'140'}
                >
                    {middleColumnTitle}
                </Typography>
                {middleColumnSubtitle && (
                    <Typography
                        tag={'span'}
                        fontSize={'14px'}
                        color={subheaderColor}
                        lineHeight={'140'}
                    >
                        {middleColumnSubtitle}
                    </Typography>
                )}
            </div>
            <div className={styles['cards-text']}>
                <Typography
                    tag={'h3'}
                    fontSize={'20px'}
                    fontWeight={'weight700'}
                    color={headerColor}
                >
                    {rightColumnHeader}
                </Typography>
                <Typography
                    tag={'span'}
                    fontSize={'14px'}
                    color={subheaderColor}
                    lineHeight={'140'}
                >
                    {rightColumnTitle}
                </Typography>
                {rightColumnSubtitle && (
                    <Typography
                        tag={'span'}
                        fontSize={'14px'}
                        color={subheaderColor}
                        lineHeight={'140'}
                    >
                        {rightColumnSubtitle}
                    </Typography>
                )}
            </div>
        </div>
    );
};
