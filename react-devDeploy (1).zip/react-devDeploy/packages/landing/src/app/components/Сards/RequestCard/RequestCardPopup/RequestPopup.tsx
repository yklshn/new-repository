import React, {useEffect, useRef} from 'react';
import close from '/libs/img/close.svg'
import s from './RequestPopup.module.sass'
import * as ReactDOM from "react-dom";
import {Button, Typography} from "@./ui";
import {setOpenModalAcceptedRequest, setOpenModalDeclineRequest} from "../../../../../toolkitRedux/toolkitSlice";
// @ts-ignore
import {store} from 'packages/landing/src/toolkitSlices/store';
import {Link} from "react-router-dom";


type PopupProps = {
  dispatch: typeof store.dispatch;
  title: string;
  subTitle: string;
  firstBtnText: string;
  secondBtnText: string;
  thirdButtonText: string;
}

const modalRoot: HTMLElement | null = document.querySelector('#root')

export const RequestPopup = ({dispatch, title, subTitle, firstBtnText, secondBtnText, thirdButtonText}: PopupProps) => {
  const rootElementRef = useRef(document.createElement('div'))

  useEffect(() => {
    const current = rootElementRef.current
    modalRoot?.appendChild(current)
    document.body.style.overflow = 'hidden'

    return () => {
      modalRoot?.removeChild(current)
      document.body.style.overflow = 'auto'
    }
  }, [])
  const handleModalClose = () => {
    dispatch(setOpenModalAcceptedRequest(false))
    dispatch(setOpenModalDeclineRequest(false))
  }
  return ReactDOM.createPortal(
    <div className={s['mainModal']}>
      <div className={s['content']}>
        <img className={s['close']} onClick={handleModalClose}
             src={close} alt="close"/>

        <Typography fontWeight={700} marginTop={'40px'}>{title}</Typography>
        <Typography fontWeight={700} marginTop={'40px'} textAlign={"center"}>{subTitle}</Typography>

        <div className="buttons-group">
          <Button onClick={handleModalClose}
                  style={{marginRight: '20px', padding: '0 20px'}} width={'100px'}
                  marginTop={'45px'}>{firstBtnText}</Button>
          <Link to={'/credits'}>
            <Button onClick={handleModalClose}
                    style={{marginRight: '20px'}} variant={"secondary"} width={'100px'} marginTop={'45px'}>
              {secondBtnText}
            </Button>
          </Link>
          <Button onClick={handleModalClose}
                  style={{marginRight: '20px'}} variant={"secondary"} width={'100px'}
                  marginTop={'45px'}>{thirdButtonText}</Button>
        </div>
      </div>
    </div>,
    rootElementRef.current
  );
};
