import 'bootstrap/dist/css/bootstrap.min.css';
import Button from 'react-bootstrap/Button';
import Container from 'react-bootstrap/Container';
import Form from 'react-bootstrap/Form';
import Navbar from 'react-bootstrap/Navbar';
import Offcanvas from 'react-bootstrap/Offcanvas';

import { NavLink } from 'react-router-dom';

import styles from './NavbarBootstrap.module.sass';

const element = document.getElementById('modal-root') as HTMLElement;

export function OffcanvasExample() {
    const consoleLog = () => {
        element.click();
    };

    return (
        <Navbar key={'expand'} bg="light" expand={'expand'}>
            <Container fluid>
                <Navbar.Brand href="#">Бетта-Банк</Navbar.Brand>
                <Navbar.Toggle
                    aria-controls={`offcanvasNavbar-expand-${'expand'}`}
                />
                <Navbar.Offcanvas
                    id={`offcanvasNavbar-expand-${'expand'}`}
                    aria-labelledby={`offcanvasNavbarLabel-expand-${'expand'}`}
                    placement="end"
                >
                    <Offcanvas.Header closeButton>
                        <Offcanvas.Title
                            id={`offcanvasNavbarLabel-expand-${'expand'}`}
                        >
                            Бетта-Банк
                        </Offcanvas.Title>
                    </Offcanvas.Header>
                    <Offcanvas.Body>
                        <div className={styles['navLinks']}>
                            <NavLink
                                onClick={() => consoleLog()}
                                className={styles['navLink']}
                                to="/"
                            >
                                Главная
                            </NavLink>
                            <NavLink
                                onClick={() => consoleLog()}
                                className={styles['navLink']}
                                to="/cards"
                            >
                                Карты
                            </NavLink>
                            <NavLink
                                onClick={() => consoleLog()}
                                className={styles['navLink']}
                                to="/deposits"
                            >
                                Вклады
                            </NavLink>
                            <NavLink
                                onClick={() => consoleLog()}
                                className={styles['navLink']}
                                to="/credits"
                            >
                                Кредиты
                            </NavLink>
                            <NavLink
                                onClick={() => consoleLog()}
                                className={styles['navLink']}
                                to="/about"
                            >
                                О банке
                            </NavLink>
                            <NavLink
                                onClick={() => consoleLog()}
                                className={styles['navLinkSpecial']}
                                to="/authorization"
                            >
                                Войти
                            </NavLink>
                        </div>
                        <Form className="d-flex">
                            <Form.Control
                                type="search"
                                placeholder="Search"
                                className="me-2"
                                aria-label="Search"
                            />
                            <Button variant="outline-secondary">Search</Button>
                        </Form>
                    </Offcanvas.Body>
                </Navbar.Offcanvas>
            </Container>
        </Navbar>
    );
}
