import { CardDetails, MainForm, Typography } from '@./ui';
import { useEffect } from 'react';
import { useTranslation } from 'react-i18next';
import { useSelector } from 'react-redux';

import { useAppDispatch, useAppSelector } from '../../../hooks/redux';
import { fetchCardList } from '../../../toolkitSlices/actionCreatorsCard';
import { TypeSwitcher } from '../../components/TypeSwitcher/TypeSwitcher';
import { Buttons } from '../../components/Сards/OfferCard/Buttons/Buttons';
import { Header } from '../../components/Сards/OfferCard/Header/Header';
import { CImage } from '../../components/Сards/OfferCard/Image/Image';
import { Text } from '../../components/Сards/OfferCard/Text/Text';
import styles from './CardPage.module.sass';
import cardBackground from '/libs/ui/img/cardBackground.png';

export type cardProp = {
  card: {
    id?: string;
    cardImageWidth?: string | number;
    cardImageHeight?: string | number;
    cardImage?: string;
    leftColumnHeader?: string;
    leftColumnTitle?: string;
    leftColumnSubtitle?: string;
    middleColumnHeader?: string;
    middleColumnTitle?: string;
    middleColumnSubtitle?: string;
    rightColumnHeader?: string;
    rightColumnTitle?: string;
    rightColumnSubtitle?: string;
    primaryButtonText?: string;
    secondaryButtonText?: string;
    headerText?: string;
    cardNumber?: string;
    cardTitle: string[];
    background?: string;
  };
};

type CardPageProps = {
  needMoreInfo: boolean;
};

export const CardPage = ({ needMoreInfo }: CardPageProps) => {
  const cardData = useSelector((state: cardProp) => state.card);
  const { cardList } = useAppSelector((state) => state.cardListReducer);
  const dispatch = useAppDispatch();
  const { t } = useTranslation();

  const cardAdvantge = t('cardPage.cardAdvantage.0');
  const itemAdvantages = t('cardPage.switcher.items.0');
  const itemCondition = t('cardPage.switcher.items.1');
  const itemPaymentCalculating = t('cardPage.switcher.items.2');
  const itemDocuments = t('cardPage.switcher.items.3');
  const textAbout = t('cardPge.switcher.headerText.0');

  useEffect(() => {
    dispatch(fetchCardList());
  }, [dispatch]);

  const cardDescription = cardList[Number(cardData.id)].description + '<br>';
  const cardDescriptArrTag = cardDescription.match(/<p>.+?<\/p><br>/g);
  let cardDescriptArr: string[] = [];

  if (Array.isArray(cardDescriptArrTag)) {
    cardDescriptArr = cardDescriptArrTag.map((itemArr) =>
      itemArr.replace(/<\/p><p>/g, '. ').replace(/[<p></p><br>]/g, '')
    );
  }

  return (
    <>
      <div className={styles['wrap']}>
        <div className={styles['card-contains']}>
          <Header headerText={cardData.headerText} color="white" />
          <div className={styles['card-contains-additional']}>
            <Typography
              tag={'span'}
              fontSize={'size22'}
              fontWeight={'weight400'}
              color={'white'}
              lineHeight={'140'}
            >
              {cardAdvantge}
            </Typography>
          </div>
          {cardData.leftColumnHeader &&
            cardData.middleColumnHeader &&
            cardData.rightColumnHeader && (
              <Text
                leftColumnHeader={cardData.leftColumnHeader}
                middleColumnHeader={cardData.middleColumnHeader}
                rightColumnHeader={cardData.rightColumnHeader}
                leftColumnTitle={cardData.leftColumnTitle}
                middleColumnTitle={cardData.middleColumnTitle}
                rightColumnTitle={cardData.rightColumnTitle}
                leftColumnSubtitle={cardData.leftColumnSubtitle}
                middleColumnSubtitle={cardData.middleColumnSubtitle}
                rightColumnSubtitle={cardData.rightColumnSubtitle}
                headerColor="white"
                subheaderColor="light-grey"
              />
            )}
          <Buttons needMoreInfo={needMoreInfo} />
        </div>
        <div className={styles['card-image']}>
          {cardData.background && (
            <CImage
              cardImage={cardBackground}
              cardNumber={cardData.cardNumber}
              cardTitle={cardData.cardTitle}
              background={cardData.background}
              cardImageWidth={353}
              cardImageHeight={208}
            />
          )}
        </div>
      </div>
      <TypeSwitcher
        items={[
          itemAdvantages,
          itemCondition,
          itemPaymentCalculating,
          itemDocuments,
        ]}
        headerText={textAbout}
      />
      <CardDetails />
      <MainForm />
    </>
  );
};
