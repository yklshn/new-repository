import { Accordion, GetCard, MainForm, Offer } from '@./ui';
import { Button } from '@./ui';
import { inputSelector } from '@.landing/toolkitRedux';
import { useTranslation } from 'react-i18next';
import { useSelector } from 'react-redux';

import { TypeSwitcher } from '../../components/TypeSwitcher/TypeSwitcher';
import { Buttons } from '../../components/Сards/OfferCard/Buttons/Buttons';
import { Header } from '../../components/Сards/OfferCard/Header/Header';
import { CImage } from '../../components/Сards/OfferCard/Image/Image';
import { OfferCard } from '../../components/Сards/OfferCard/OfferCardFolder/OfferCard';
import { Text } from '../../components/Сards/OfferCard/Text/Text';
import styles from './CreditsPage.module.sass';
import backgroundImage from '/libs/ui/img/creditsBackground.png';
import universalDepositBackgroundImage from '/libs/ui/img/universalDeposit.png';

interface DepositProps {
  id: string;
  cardImageWidth?: string | number;
  cardImageHeight?: string | number;
  cardImage: string;
  headerText?: string;
  leftColumnHeader: string;
  leftColumnTitle?: string;
  leftColumnSubtitle?: string;
  middleColumnHeader: string;
  middleColumnTitle?: string;
  rightColumnHeader?: string;
  rightColumnTitle?: string;
  primaryButtonText?: string;
  secondaryButtonText?: string;
  needMoreInfo: boolean;
}

export const CreditsPage = () => {
  const { t } = useTranslation();
  const { toggler } = useSelector(inputSelector);

  const headerText = t('credits.header.0');
  const subHeaderText = t('credits.header.1');
  const headerButtonText = t('credits.header.2');
  const showMoreCredits = t('credits.showMoreCredits.0');
  const itemAction = t('credits.items.0');
  const itemCondition = t('credits.items.1');
  const itemSchedule = t('credits.items.2');
  const itemHistory = t('credits.items.3');
  const itemAgreement = t('credits.items.4');

  const firstCreditProps: DepositProps = {
    id: 'universal',
    cardImageWidth: +t('creditsPage.cardImageWidth.0'),
    cardImageHeight: +t('creditsPage.cardImageHeight.0'),
    cardImage: universalDepositBackgroundImage,
    headerText: t('creditsPage.title.0'),
    leftColumnHeader: t('creditsPage.leftColumnHeader.0'),
    leftColumnTitle: t('creditsPage.leftColumnTitle.0'),
    middleColumnHeader: t('creditsPage.middleColumnHeader.0'),
    middleColumnTitle: t('creditsPage.middleColumnTitle.0'),

    needMoreInfo: Boolean(t('creditsPage.needMoreInfo.0')),
    primaryButtonText: t('creditsPage.primaryButtonText.0'),
    secondaryButtonText: t('creditsPage.secondaryButtonText.0'),
  };

  const creditsPropsArray = [firstCreditProps];

  return (
    <div>
      <div className={styles['container']}>
        <Offer
          headerText="Кредиты"
          subheaderText="Лучшие предложения от Бетта-Банка
                    SMART от Бетта-Банка"
          buttonText="Подобрать кредит"
          backgroundImage={backgroundImage}
        />
        {creditsPropsArray.map((item) => (
          <OfferCard
            header={<Header headerText={item.headerText} color="black" />}
            text={
              <Text
                leftColumnHeader={item.leftColumnHeader}
                leftColumnTitle={item.leftColumnTitle}
                leftColumnSubtitle={item.leftColumnSubtitle}
                middleColumnHeader={item.middleColumnHeader}
                middleColumnTitle={item.middleColumnTitle}
                headerColor="black"
                subheaderColor="grey"
              />
            }
            btn={
              <Buttons
                id={item.id}
                needMoreInfo={item.needMoreInfo}
                primaryButtonText={item.primaryButtonText}
                secondaryButtonText={item.secondaryButtonText}
                typeOf={'credits'}
              />
            }
            image={
              <CImage
                cardImageWidth={Number(item.cardImageWidth)}
                cardImageHeight={Number(item.cardImageHeight)}
                cardImage={item.cardImage}
              />
            }
          />
        ))}
      </div>
    </div>
  );
};
