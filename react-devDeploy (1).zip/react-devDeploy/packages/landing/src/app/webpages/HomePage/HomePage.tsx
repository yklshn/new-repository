import {
  DepartmentsWrapper,
  ExchangeRate,
  ServicesMain,
  SliderWrapper,
} from '@./ui';

export const HomePage = () => {
  return (
    <div>
      <SliderWrapper />
      <ServicesMain />
      <ExchangeRate />
      <DepartmentsWrapper />
    </div>
  );
};
