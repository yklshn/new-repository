import {
  Accordion,
  Button,
  CalculatorForDeposit,
  GetCard,
  MainForm,
  Offer,
} from '@./ui';
import { useState } from 'react';
import { useTranslation } from 'react-i18next';

import { Buttons } from '../../components/Сards/OfferCard/Buttons/Buttons';
import { Header } from '../../components/Сards/OfferCard/Header/Header';
import { CImage } from '../../components/Сards/OfferCard/Image/Image';
import { OfferCard } from '../../components/Сards/OfferCard/OfferCardFolder/OfferCard';
import { Text } from '../../components/Сards/OfferCard/Text/Text';
import styles from './DepositsPage.module.sass';
import backgroundImage from '/libs/ui/img/depositBackground.png';
import savingsDepositBackgroundImage from '/libs/ui/img/savingsDeposit.png';
import startDepositBackgroundImage from '/libs/ui/img/startDeposit.png';
import universalDepositBackgroundImage from '/libs/ui/img/universalDeposit.png';
import cardBackground from '/libs/ui/img/universalDeposit.png';

interface DepositProps {
  id: string;
  cardImageWidth?: string | number;
  cardImageHeight?: string | number;
  cardImage: string;
  headerText?: string;
  leftColumnHeader: string;
  leftColumnTitle?: string;
  leftColumnSubtitle?: string;
  middleColumnHeader: string;
  middleColumnTitle?: string;
  rightColumnHeader: string;
  rightColumnTitle?: string;
  primaryButtonText?: string;
  secondaryButtonText?: string;
  needMoreInfo: boolean;
}

type DepositFounded = {
  id: string | number;
  percent: string | number;
  name: string;
  percentToCard: string;
  currency: string;
  sumMin: string;
  sumMax: string;
  depositTerm: string;
  earlyClosed: boolean;
  replenishingBalancePossibility: boolean;
  fullDescription: string;
};

export const DepositsPage = () => {
  const { t } = useTranslation();

  const [depositsListFromBack, setDepositsListFromBack] = useState([]);
  const [foundedDepositsArray, setFoundedDepositsArray] = useState<
    DepositFounded[]
  >([]);

  // useEffect(() => {
  //     fetch('http://10.10.15.227/api/v1/deposits/deposit-types/', {
  //         method: 'GET',
  //         headers: {
  //             accept: 'application/json',
  //         },
  //     })
  //         .then((response) => response.json())
  //         .then((data) => setDepositsListFromBack(data));
  // }, []);

  // useEffect(() => {
  //     fetch('http://10.10.15.227/api/v1/deposits/deposit-types/all/', {
  //         method: 'GET',
  //         headers: {
  //             accept: 'application/json',
  //         },
  //     })
  //         .then((response) => response.json())
  //         .then((data) =>
  //             data.filter((item: DepositFounded) => +item.id % 2 === 0)
  //         )
  //         .then((data) => data.splice(3, 9))
  //         .then((data) => setFoundedDepositsArray(data));
  // }, []);

  const headerText = t('deposits.header.0');
  const subHeaderText = t('deposits.header.1');
  const headerButtonText = t('deposits.header.2');
  const calculatorHeaderText = t('deposits.calculator.0');
  const calculatorButtonText = t('deposits.calculator.1');

  const firstDepositProps: DepositProps = {
    id: '1',
    cardImageWidth: +t('deposits.cardImageWidth.0'),
    cardImageHeight: +t('deposits.cardImageHeight.0'),
    cardImage: universalDepositBackgroundImage,
    headerText: t('deposits.title.0'),
    leftColumnHeader: t('deposits.leftColumnHeader.0'),
    leftColumnTitle: t('deposits.leftColumnTitle.0'),
    middleColumnHeader: t('deposits.middleColumnHeader.0'),
    middleColumnTitle: t('deposits.middleColumnTitle.0'),
    rightColumnHeader: t('deposits.rightColumnHeader.0'),
    rightColumnTitle: t('deposits.rightColumnTitle.0'),
    needMoreInfo: Boolean(t('deposits.needMoreInfo.0')),
    primaryButtonText: t('deposits.primaryButtonText.0'),
    secondaryButtonText: t('deposits.secondaryButtonText.0'),
  };
  const secondDepositProps: DepositProps = {
    id: '2',
    cardImageWidth: +t('deposits.cardImageWidth.1'),
    cardImageHeight: +t('deposits.cardImageHeight.1'),
    cardImage: savingsDepositBackgroundImage,
    headerText: t('deposits.title.1'),
    leftColumnHeader: t('deposits.leftColumnHeader.1'),
    leftColumnTitle: t('deposits.leftColumnTitle.1'),
    middleColumnHeader: t('deposits.middleColumnHeader.1'),
    middleColumnTitle: t('deposits.middleColumnTitle.1'),
    rightColumnHeader: t('deposits.rightColumnHeader.1'),
    rightColumnTitle: t('deposits.rightColumnTitle.1'),
    needMoreInfo: Boolean(t('deposits.needMoreInfo.1')),
    primaryButtonText: t('deposits.primaryButtonText.1'),
    secondaryButtonText: t('deposits.secondaryButtonText.1'),
  };
  const thirdDepositProps: DepositProps = {
    id: '3',
    cardImageWidth: +t('deposits.cardImageWidth.2'),
    cardImageHeight: +t('deposits.cardImageHeight.2'),
    cardImage: startDepositBackgroundImage,
    headerText: t('deposits.title.2'),
    leftColumnHeader: t('deposits.leftColumnHeader.2'),
    leftColumnTitle: t('deposits.leftColumnTitle.2'),
    middleColumnHeader: t('deposits.middleColumnHeader.2'),
    middleColumnTitle: t('deposits.middleColumnTitle.2'),
    rightColumnHeader: t('deposits.rightColumnHeader.2'),
    rightColumnTitle: t('deposits.rightColumnTitle.2'),
    needMoreInfo: Boolean(t('deposits.needMoreInfo.2')),
    primaryButtonText: t('deposits.primaryButtonText.2'),
    secondaryButtonText: t('deposits.secondaryButtonText.2'),
  };

  const depositsPropsArray = [
    firstDepositProps,
    secondDepositProps,
    thirdDepositProps,
  ];

  return (
    <div className={styles['container']}>
      <div>
        <Offer
          backgroundImage={backgroundImage}
          headerColor="grey"
          subheaderColor="grey"
          headerText={headerText}
          subheaderText={subHeaderText}
          buttonText={headerButtonText}
        />
      </div>
      <CalculatorForDeposit
        headerText={calculatorHeaderText}
        headerColor={'black'}
        buttonText={calculatorButtonText}
        depositsData={depositsListFromBack}
      />
      <div className={styles['wrap-card']}>
        {depositsPropsArray.map((item) => (
          <OfferCard
            header={<Header headerText={item.headerText} color="black" />}
            text={
              <Text
                leftColumnHeader={item.leftColumnHeader}
                leftColumnTitle={item.leftColumnTitle}
                leftColumnSubtitle={item.leftColumnSubtitle}
                middleColumnHeader={item.middleColumnHeader}
                middleColumnTitle={item.middleColumnTitle}
                rightColumnHeader={item.rightColumnHeader}
                rightColumnTitle={item.rightColumnTitle}
                headerColor="black"
                subheaderColor="grey"
              />
            }
            btn={
              <Buttons
                id={item.id}
                needMoreInfo={item.needMoreInfo}
                primaryButtonText={item.primaryButtonText}
                secondaryButtonText={item.secondaryButtonText}
                typeOf={'credits'}
              />
            }
            image={
              <CImage
                cardImageWidth={Number(item.cardImageWidth)}
                cardImageHeight={Number(item.cardImageHeight)}
                cardImage={item.cardImage}
              />
            }
          />
        ))}
        {/* {depositsPropsArray.map((item) => (
                    // <RequestCard {...item} key={item.id} typeOf={'deposits'} />
                    <OfferCard {...item} key={item.id} typeOf={'deposits'} />
                ))} */}
        {/* {foundedDepositsArray.map((item) => (
                    <OfferCard
                        key={item.id}
                        id={item.id.toString()}
                        leftColumnHeader={'Проценты'}
                        middleColumnHeader={'Срок'}
                        rightColumnHeader={'Выплата процентов'}
                        cardImage={cardBackground}
                        needMoreInfo={true}
                        headerText={`Вклад ${item.name}`}
                        typeOf={'deposits'}
                        leftColumnTitle={`до ${item.percent}% годовых`}
                        primaryButtonText={'Оформить'}
                        secondaryButtonText={'Подробнее о вкладе'}
                        cardImageWidth={353}
                        cardImageHeight={208}
                        middleColumnTitle={`${item.depositTerm} месяцев`}
                        rightColumnTitle={
                            item.percentToCard
                                ? 'Выплата процентов на карту'
                                : 'Выплата на карту невозможна'
                        }
                        depositCurrency={item.currency}
                        depositSumMin={item.sumMin}
                        depositSumMax={item.sumMax}
                        depositTerm={item.depositTerm}
                        depositEarlyClosed={item.earlyClosed}
                        depositReplenishingBalancePossibility={
                            item.replenishingBalancePossibility
                        }
                        depositFullDescription={item.fullDescription}
                    />
                ))} */}
        <div className={styles['wrap-button']}>
          <Button variant="tertiary">Показать еще вклады</Button>
        </div>
      </div>
      <GetCard
        headerText={'Как оформить вклад?'}
        steps={[
          {
            stepNumber: 1,
            stepTitle: t('deposits.stepsTitles.0'),
            stepSubtitle: t('deposits.stepsSubtitles.0'),
          },
          {
            stepNumber: 2,
            stepTitle: t('deposits.stepsTitles.1'),
            stepSubtitle: t('deposits.stepsSubtitles.1'),
          },
          {
            stepNumber: 3,
            stepTitle: t('deposits.stepsTitles.2'),
            stepSubtitle: t('deposits.stepsSubtitles.2'),
          },
          {
            stepNumber: 4,
            stepTitle: t('deposits.stepsTitles.3'),
            stepSubtitle: t('deposits.stepsSubtitles.3'),
          },
        ]}
      />
      <Accordion />
      <MainForm />
    </div>
  );
};
