// eslint-disable-next-line @typescript-eslint/no-unused-vars
import { Link } from 'react-router-dom';

import styles from './NotFoundPage.module.sass';

export const NotFoundPage = () => {
  return (
    <div>
      <div>Что-то пошло не так. Данной страницы не существует</div>
      <div>
        <Link to="/">На главную страницу</Link>
      </div>
    </div>
  );
};
