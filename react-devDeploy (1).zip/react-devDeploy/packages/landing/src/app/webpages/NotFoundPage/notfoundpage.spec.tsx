import { render } from '@testing-library/react';

import { BrowserRouter } from 'react-router-dom';

import { NotFoundPage } from './NotFoundPage';

describe('Notfoundpage', () => {
    it('should render successfully', () => {
        const { baseElement } = render(
            <BrowserRouter>
                <NotFoundPage />
            </BrowserRouter>
        );

        expect(baseElement).toBeTruthy();
    });
});
