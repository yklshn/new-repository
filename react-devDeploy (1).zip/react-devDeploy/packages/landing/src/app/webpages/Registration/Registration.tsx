import { CodeLogIn, SecurityRule, WindowForLogin } from '@./landing';
import { inputSelector } from '@.landing/toolkitRedux';
import { useSelector } from 'react-redux';

import styles from './Registration.module.sass';

export const Registration = (): JSX.Element => {
  const { showSMSWindow } = useSelector(inputSelector);

  return (
    <>
      <div className={styles['container-girl']}>
        <div className={styles['main']}>
          {showSMSWindow === 'LogIn' ? <WindowForLogin /> : <CodeLogIn />}
        </div>
      </div>
      <SecurityRule />
    </>
  );
};
