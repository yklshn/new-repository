export type PopUp = {
  title: string,
  subTitle: string,
  firstBtnText: string,
  secondBtnText: string,
  thirdButtonText: string,
}
export type RequestPropArray = {
  leftText: string,
  rightText: string,
  lastText: string,
}
