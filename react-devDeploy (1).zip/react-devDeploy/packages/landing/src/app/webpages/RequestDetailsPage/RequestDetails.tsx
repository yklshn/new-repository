import React from 'react';
import {useDispatch, useSelector} from "react-redux";
import {inputSelector} from "@.landing/toolkitRedux";
import {Button, Typography} from "@./ui";
import {RequestPopup} from "../../components/Сards/RequestCard/RequestCardPopup/RequestPopup";
import RequestDetail from "./RequestDetail";
import {setOpenModalAcceptedRequest, setOpenModalDeclineRequest} from "../../../toolkitRedux/toolkitSlice";
import {t} from "i18next";
import {RequestPropArray, PopUp} from "./RequestDetailsTypes";
import style from './RequestDetails.module.sass'

export const RequestDetails = () => {

  const PopUp: PopUp = {
    title: t('requestPopUp.title', {returnObjects: true}),
    subTitle: t('requestPopUp.subTitle', {returnObjects: true}),
    firstBtnText: t('requestPopUp.firstBtnText', {returnObjects: true}),
    secondBtnText: t('requestPopUp.secondBtnText.0'),
    thirdButtonText: t('requestPopUp.thirdButtonText.0')
  }


  // returnObjects из документации i18next  для возврата полного объекта
  const request: RequestPropArray = {
    leftText: t('requestDetails.leftText', {returnObjects: true}),
    rightText: t('requestDetails.rightText', {returnObjects: true}),
    lastText: t('requestDetails.lastText', {returnObjects: true}),
  };

  const dispatch = useDispatch()
  const {openModalAcceptedRequest, openModalDeclineRequest} = useSelector(inputSelector)

  return (
    <div className={style['container']}>

      <Typography style={{paddingLeft: '72px'}} tag='p' fontWeight='700' fontSize='32px'>
        Кредитные предложения
      </Typography>
      <Typography style={{paddingLeft: '72px'}} tag='p' fontSize='22px' marginTop='5px' fontWeight='400'>
        Предложение 1 по заявке 1
      </Typography>
      <Typography style={{paddingLeft: '72px'}} tag='p' fontWeight='700' fontSize='32px' mb='30px'>
        Предложение 1 по заявке 1
      </Typography>


      <div className={style['wrap-request-details']}>
        <RequestDetail
          leftText={request.leftText ? request.leftText : ''}
          rightText={request.rightText ? request.rightText : ''}
          lastText={request.lastText ? request.lastText : ''}/>
      </div>

      {
        openModalAcceptedRequest ? <RequestPopup dispatch={dispatch} title={PopUp.title[0]}
                                                 subTitle={PopUp.subTitle[0]}
                                                 firstBtnText={PopUp.firstBtnText[0]}
                                                 secondBtnText={PopUp.secondBtnText}
                                                 thirdButtonText={PopUp.thirdButtonText}
          />
          :
          null
      }
      {
        openModalDeclineRequest ?
          <RequestPopup dispatch={dispatch} title={PopUp.title[1]}
                        subTitle={PopUp.subTitle[1]}
                        firstBtnText={PopUp.firstBtnText[1]}
                        secondBtnText={PopUp.secondBtnText}
                        thirdButtonText={PopUp.thirdButtonText}
          />
          :
          null
      }

      <div className={style['btn-groups']}>
        <Button height={'50px'} width={'130px'}
                onClick={() => dispatch(setOpenModalAcceptedRequest(true))}>Принять</Button>
        <Button variant="secondary" onClick={() => dispatch(setOpenModalDeclineRequest(true))}>Отказаться от
          кредита</Button>
      </div>
    </div>
  );
};
