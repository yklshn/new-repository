import React from 'react';
import style from './RequestDetail.module.sass'

type TextProps = {
  leftText: string,
  rightText: string,
  lastText: string,
}

const RequestDetail = ({leftText, rightText, lastText}: TextProps) => {
  return (
    <>
      <div className={style['main']}>
        {leftText && <div className={style['left-text']}>{leftText[0]}</div>}
        {rightText && <div className={style['right-text']}>{rightText[0]}</div>}

        {leftText && <div className={style['left-text']}>{leftText[1]}</div>}
        {rightText && <div className={style['right-text']}>{rightText[1]}</div>}

        {leftText && <div className={style['left-text']}>{leftText[2]}</div>}
        {rightText && <div className={style['right-text']}>{rightText[2]}</div>}

        {leftText && <div className={style['left-text']}>{leftText[3]}</div>}
        {rightText && <div className={style['right-text']}>{rightText[3]}</div>}

        {leftText && <div className={style['left-text']}>{leftText[4]}</div>}
        {rightText && <div className={style['right-text']}>{rightText[4]}</div>}

        {lastText && <div className={style['last-text']}>{lastText}</div>}
      </div>
    </>
  );
};

export default RequestDetail;
