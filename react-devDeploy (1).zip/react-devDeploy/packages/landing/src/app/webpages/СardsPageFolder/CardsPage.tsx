import { Accordion } from '@./landing';
import { MainForm } from '@./landing';
import { Button, GetCard, Offer } from '@./ui';
import { useEffect } from 'react';
import { useTranslation } from 'react-i18next';

import { useAppDispatch, useAppSelector } from '../../../hooks/redux';
import { fetchCardList } from '../../../toolkitSlices/actionCreatorsCard';
import { TypeSwitcher } from '../../components/TypeSwitcher/TypeSwitcher';
import { Buttons } from '../../components/Сards/OfferCard/Buttons/Buttons';
import { Header } from '../../components/Сards/OfferCard/Header/Header';
import { CImage } from '../../components/Сards/OfferCard/Image/Image';
import { OfferCard } from '../../components/Сards/OfferCard/OfferCardFolder/OfferCard';
import { Text } from '../../components/Сards/OfferCard/Text/Text';
import styles from './CardsPage.module.sass';
import cardBackground from '/libs/ui/img/card.png';
import backgroundImage from '/libs/ui/img/cardBG.jpg';

interface CardProps {
  id: string;
  cardImageWidth?: string | number;
  cardImageHeight?: string | number;
  cardImage: string;
  leftColumnHeader: string;
  leftColumnTitle?: string;
  leftColumnSubtitle?: string;
  middleColumnHeader: string;
  middleColumnTitle?: string;
  middleColumnSubtitle?: string;
  rightColumnHeader: string;
  rightColumnTitle?: string;
  rightColumnSubtitle?: string;
  primaryButtonText?: string;
  secondaryButtonText?: string;
  headerText?: string;
  cardNumber?: string;
  needMoreInfo: boolean;
  background?: string;
}

export const CardsPage = () => {
  const { cardList } = useAppSelector((state) => state.cardListReducer);
  const dispatch = useAppDispatch();
  const { t } = useTranslation();

  useEffect(() => {
    dispatch(fetchCardList());
  }, []);

  const typeOfCard = (type: string): string => {
    if (type === 'DEBIT') {
      return String(t('cards.typeOfCard1'));
    } else if (type === 'CREDIT') {
      return String(t('cards.typeOfCard2'));
    } else {
      return '';
    }
  };

  const infoAdvantages = (data: string): string[] => {
    const adventArr = data.split('</p><p>');
    const adventArrRes = adventArr.map((item) =>
      item.replace(/[<p></p>]/g, '')
    );
    return adventArrRes;
  };

  const offerHeader = t('cardsPage.offer.0');
  const offerSubHeader = t('cardsPage.offer.1');
  const offerButtonText = t('cardsPage.offer.2');
  const showMoreCards = t('cardsPage.showMoreCards.0');
  const getCardText = t('cardsPage.getCard.0');

  const firstCardProps: CardProps = {
    id: '1',
    cardImageWidth: +t('cards.cardImageWidth.0'),
    cardImageHeight: +t('cards.cardImageHeight.0'),
    cardImage: cardBackground,
    leftColumnHeader: t('cards.leftColumnHeader.0'),
    leftColumnTitle: t('cards.leftColumnTitle.0'),
    leftColumnSubtitle: t('cards.leftColumnSubtitle.0'),
    middleColumnHeader: t('cards.middleColumnHeader.0'),
    middleColumnTitle: t('cards.middleColumnTitle.0'),
    middleColumnSubtitle: t('cards.middleColumnSubtitle.0'),
    rightColumnHeader: t('cards.rightColumnHeader.0'),
    rightColumnTitle: t('cards.rightColumnTitle.0'),
    headerText: t('cards.title.0'),
    cardNumber: t('cards.cardNumber.0'),
    needMoreInfo: Boolean(t('cards.needMoreInfo.0')),
    background: t('cards.background.0'),
    primaryButtonText: t('cards.primaryButtonText.0'),
    secondaryButtonText: t('cards.secondaryButtonText.0'),
  };
  const secondCardProps: CardProps = {
    id: '2',
    cardImageWidth: +t('cards.cardImageWidth.1'),
    cardImageHeight: +t('cards.cardImageHeight.1'),
    cardImage: cardBackground,
    leftColumnHeader: t('cards.leftColumnHeader.1'),
    leftColumnTitle: infoAdvantages(cardList[1].advantages)[1],
    leftColumnSubtitle: '',
    middleColumnHeader: t('cards.middleColumnHeader.1'),
    middleColumnTitle: infoAdvantages(cardList[1].advantages)[2],
    middleColumnSubtitle: '',
    rightColumnHeader: t('cards.rightColumnHeader.1'),
    rightColumnTitle: infoAdvantages(cardList[1].advantages)[0],
    headerText: typeOfCard(cardList[1].type) + ' ' + cardList[1].name,
    cardNumber: t('cards.cardNumber.1'),
    needMoreInfo: Boolean(t('cards.needMoreInfo.1')),
    background: t('cards.background.1'),
    primaryButtonText: t('cards.primaryButtonText.1'),
    secondaryButtonText: t('cards.secondaryButtonText.1'),
  };
  const thirdCardProps: CardProps = {
    id: '3',
    cardImageWidth: +t('cards.cardImageWidth.2'),
    cardImageHeight: +t('cards.cardImageHeight.2'),
    cardImage: cardBackground,
    leftColumnHeader: t('cards.leftColumnHeader.2'),
    leftColumnTitle: t('cards.leftColumnTitle.2'),
    leftColumnSubtitle: t('cards.leftColumnSubtitle.2'),
    middleColumnHeader: t('cards.middleColumnHeader.2'),
    middleColumnTitle: t('cards.middleColumnTitle.2'),
    middleColumnSubtitle: t('cards.middleColumnSubtitle.2'),
    rightColumnHeader: t('cards.rightColumnHeader.2'),
    rightColumnTitle: t('cards.rightColumnTitle.2'),
    headerText: t('cards.title.2'),
    cardNumber: t('cards.cardNumber.2'),
    needMoreInfo: Boolean(t('cards.needMoreInfo.2')),
    background: t('cards.background.2'),
    primaryButtonText: t('cards.primaryButtonText.2'),
    secondaryButtonText: t('cards.secondaryButtonText.2'),
  };

  const cardsProps = [firstCardProps, secondCardProps, thirdCardProps];

  return (
    <div className={styles['container']}>
      <Offer
        headerColor="white"
        subheaderColor="white"
        headerText="Банковские карты"
        subheaderText="Зарабатывайте и экономьте деньги с картой Smart от
                        Бетта-Банка"
        buttonText="Выбрать карту"
        backgroundImage={backgroundImage}
      />
      {/*<TypeSwitcher*/}
      {/*    items={['Все', 'Лучший выбор', 'Дебетовые', 'Кредитные']}*/}
      {/*    linkTo="/cards"*/}
      {/*    headerText={'Выберите карту'}*/}
      {/*/>*/}
      <div className={styles['wrap-card']}>
        {cardsProps.map((item) => (
          <OfferCard
            header={<Header headerText={item.headerText} color="black" />}
            text={
              <Text
                leftColumnHeader={item.leftColumnHeader}
                leftColumnTitle={item.leftColumnTitle}
                leftColumnSubtitle={item.leftColumnSubtitle}
                middleColumnHeader={item.middleColumnHeader}
                middleColumnTitle={item.middleColumnTitle}
                rightColumnHeader={item.rightColumnHeader}
                rightColumnTitle={item.rightColumnTitle}
                headerColor="black"
                subheaderColor="grey"
              />
            }
            btn={
              <Buttons
                id={item.id}
                needMoreInfo={item.needMoreInfo}
                primaryButtonText={item.primaryButtonText}
                secondaryButtonText={item.secondaryButtonText}
                typeOf={'cards'}
              />
            }
            image={
              <CImage
                cardImageWidth={Number(item.cardImageWidth)}
                cardImageHeight={Number(item.cardImageHeight)}
                cardImage={item.cardImage}
              />
            }
          />
        ))}
        <div className={styles['wrap-button']}>
          <Button variant="tertiary">Показать еще карты</Button>
        </div>
      </div>
      <GetCard
        headerText={'Как получить карту?'}
        steps={[
          {
            stepNumber: 1,
            stepTitle: t('deposits.stepsTitles.0'),
            stepSubtitle: t('deposits.stepsSubtitles.0'),
          },
          {
            stepNumber: 2,
            stepTitle: t('deposits.stepsTitles.1'),
            stepSubtitle: t('deposits.stepsSubtitles.1'),
          },
          {
            stepNumber: 3,
            stepTitle: t('deposits.stepsTitles.2'),
            stepSubtitle: t('deposits.stepsSubtitles.2'),
          },
        ]}
      />
      <Accordion />
      <MainForm />
    </div>
  );
};
