import { HomePage } from '@./landing';
import { NotFoundPage } from '@./landing';
import { CardsPage } from '@./landing';
import { CardPage } from '@./landing';
import { DepositsPage } from '@./landing';
import { CreditsPage } from '@./landing';
import { Footer, NavBar, Registration } from 'packages/landing/src';
import { Route, Routes } from 'react-router-dom';

export function App() {
  return (
    <>
      <header>
        <NavBar auth={false} />
      </header>
      <main>
        <Routes>
          <Route path="/" element={<HomePage />} />
          <Route path="cards" element={<CardsPage />} />
          <Route path="cards/:id" element={<CardPage needMoreInfo={false} />} />
          <Route path="deposits" element={<DepositsPage />} />
          <Route
            path="deposits/:id"
            element={<CardPage needMoreInfo={false} />}
          />
          <Route path={`credits/`} element={<CreditsPage />} />
          {/* <Route path={`credits/universal`} element={<CreditDetails />} /> */}

          <Route path="about" element={<div>О банке</div>} />
          {/* <Route path="authorization" element={<Registration />} /> */}
          <Route path="authorization" element={<Registration />} />
          <Route path="*" element={<NotFoundPage />} />
        </Routes>
      </main>
      <Footer />
    </>
  );
}

export default App;
