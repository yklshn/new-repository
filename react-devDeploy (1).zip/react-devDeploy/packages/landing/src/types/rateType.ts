export type fieldsType = {
    type: string;
    date: string;
    value: number;
    order: string;
};

export type keysType = 'usd' | 'eur' | 'chf' | 'gbp';

export type rateType = {
    usd: fieldsType[];
    eur: fieldsType[];
    chf?: fieldsType[];
    gbp?: fieldsType[];
};

const isString = (value: unknown): value is string => {
    return typeof value === 'string';
};

const isNumber = (value: unknown): value is number => {
    return typeof value === 'number';
};

const isDate = (value: unknown): value is Date => {
    return (
        value instanceof Date ||
        (typeof value === 'object' &&
            Object.prototype.toString.call(value) === '[object Date]')
    );
};

export const isRateType = (data: unknown): data is rateType => {
    const resultTypeArr = [];
    const resultDateArr = [];
    const resultValueArr = [];
    const resultOrderArr = [];

    for (const rateItem of Object.values(data as rateType)) {
        for (const item of rateItem) {
            const resultType = isString(item.type);
            resultTypeArr.push(resultType);

            const dateFromServer = new Date(item.date);
            const resultDate = isDate(dateFromServer);
            resultDateArr.push(resultDate);

            const resultValue = isNumber(item.value);
            resultValueArr.push(resultValue);

            const resultOrder = isString(item.order);
            resultOrderArr.push(resultOrder);
        }
    }

    const isAllFieldsTrue =
        resultTypeArr.every((item) => item === true) &&
        resultDateArr.every((item) => item === true) &&
        resultValueArr.every((item) => item === true) &&
        resultOrderArr.every((item) => item === true);
    return isAllFieldsTrue;
};
