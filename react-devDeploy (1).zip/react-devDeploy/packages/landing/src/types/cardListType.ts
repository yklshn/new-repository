export type cardFieldsType = {
  name: string
  type: string
  advantages: string
  description: string
}

export type cardListType = cardFieldsType[];
