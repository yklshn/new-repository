export type Graph = {
    firstYear: number;
    lastYear: number;
    graphValue: string;
};
