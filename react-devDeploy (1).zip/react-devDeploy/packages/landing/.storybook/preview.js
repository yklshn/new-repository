import i18n from '../src/i18n';
import { Suspense } from 'react';
import { I18nextProvider } from 'react-i18next';
import { Provider } from 'react-redux';
import { setupStore } from '../src/toolkitSlices/store';
import { BrowserRouter, Route, Routes } from 'react-router-dom';

const withI18next = (story) => {
  return (
    <Provider store={setupStore()}>
      {/* <BrowserRouter> */}
      <Suspense fallback={<div>loading translations...</div>}>
        <I18nextProvider i18n={i18n}>
          {/* <Routes>
              <Route path="*" element={story()} />
            </Routes> */}
          {story()}
        </I18nextProvider>
      </Suspense>
      {/* </BrowserRouter> */}
    </Provider>
  );
};

// export const decorators = [withI18next];

export const globalTypes = {
  locale: {
    name: 'Locale',
    desription: 'Internaz locale',
    toolbar: {
      icon: 'globe',
      items: [
        { value: 'en', title: 'English' },
        { value: 'ru', title: 'Russian' },
      ],
      showName: true
    }
  },
  title: 'TITLE'
}

export const colors = {
  control: 'select',
  options: [
    'black',
    'red-error',
    'grey-v1',
    'yellow',
    'grey',
    'light-grey',
    'numbers',
    'blue',
    'white',
  ],
  defaultValue: 'black',
}

export const columnDescription = {
  leftColumnHeader: {
    table: {
      category: 'Column text',
      subcategory: 'Left column',
    },
  },
  leftColumnTitle: {
    table: {
      category: 'Column text',
      subcategory: 'Left column',
    },
  },
  leftColumnSubtitle: {
    table: {
      category: 'Column text',
      subcategory: 'Left column',
    },
  },
  middleColumnHeader: {
    table: {
      category: 'Column text',
      subcategory: 'Middle column',
    },
  },
  middleColumnTitle: {
    table: {
      category: 'Column text',
      subcategory: 'Middle column',
    },
  },
  middleColumnSubtitle: {
    table: {
      category: 'Column text',
      subcategory: 'Middle column',
    },
  },
  rightColumnHeader: {
    table: {
      category: 'Column text',
      subcategory: 'Right column',
    },
  },
  rightColumnTitle: {
    table: {
      category: 'Column text',
      subcategory: 'Right column',
    },
  },
  rightColumnSubtitle: {
    table: {
      category: 'Column text',
      subcategory: 'Right column',
    },
  },
}


export const depositDescription = {
  depositCurrency: {
    table: {
      category: 'Deposit Information',
    },
  },
  depositSumMin: {
    table: {
      category: 'Deposit Information',
    },
  },
  depositSumMax: {
    table: {
      category: 'Deposit Information',
    },
  },
  depositTerm: {
    table: {
      category: 'Deposit Information',
    },
  },
  depositEarlyClosed: {
    table: {
      category: 'Deposit Information',
    },
  },
  depositReplenishingBalancePossibility: {
    table: {
      category: 'Deposit Information',
    },
  },
  depositFullDescription: {
    table: {
      category: 'Deposit Information',
    },
  },
};