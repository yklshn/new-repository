import { combineReducers, configureStore } from '@reduxjs/toolkit';

import requestSlice from '../store/slices/requestSlice';
import toolkitSlice from '../toolkitRedux/toolkitSlice';
import cardListReducer from './cardListSlice';
import cardsSlice from './cardsSlice';
import rateReducer from './rateSlice';

const rootReducer = combineReducers({
  inputReducer: toolkitSlice,
  card: cardsSlice,
  rateReducer,
  cardListReducer,
  requestReducer: requestSlice,
});

export const setupStore = () => {
  return configureStore({
    reducer: rootReducer,
  });
};

export type RootState = ReturnType<typeof rootReducer>;
export type AppStore = ReturnType<typeof setupStore>;
export type AppDispatch = AppStore['dispatch'];
