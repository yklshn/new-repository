import { combineReducers, configureStore } from '@reduxjs/toolkit';

import requestSlice from './slices/requestSlice';

const rootReducer = combineReducers({
    requestReducer: requestSlice,
});

const store = configureStore({
    reducer: rootReducer,
});

export default store;

export type RootState = ReturnType<typeof store.getState>;
export type AppDispatch = typeof store.dispatch;
