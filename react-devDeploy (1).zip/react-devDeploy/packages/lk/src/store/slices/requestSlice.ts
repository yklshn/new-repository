import { createSlice, PayloadAction } from '@reduxjs/toolkit';

type StateType = {
    requestReducer: requestState;
};

type requestState = {
    sum: string;
    currency: 'USD' | 'RUB' | 'EUR';
    term: string;
};

const initialState: requestState = {
    sum: '0',
    currency: 'RUB',
    term: '12',
};

const requestSlice = createSlice({
    name: 'requestSlice',
    initialState,
    reducers: {
        addRequest(state: requestState, action: PayloadAction<requestState>) {
            return (state = { ...state, ...action.payload });
        },
    },
});

export default requestSlice.reducer;
export const { addRequest } = requestSlice.actions;
