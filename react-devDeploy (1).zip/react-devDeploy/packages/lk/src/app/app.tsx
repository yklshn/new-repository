import { Footer, NavBar } from 'packages/landing/src';
import { Route, Routes } from 'react-router-dom';

import { CreditsPage } from './pages/CreditsPage/CreditsPage';
import { CreditsPageCalc } from './pages/CreditsPageCalc/CreditsPageCalc';
import { DepositsPage } from './pages/DepositsPage/DepositsPage';
import { HomePage } from './pages/Homepage/HomePage';
import { RequestPage } from './pages/RequestPage/RequestPage';
import { CardsPage } from './pages/СardsPage/CardsPage';

export function App() {
  return (
    <>
      <header>
        <NavBar auth={true} />
      </header>
      <main>
        <Routes>
          <Route path="/" element={<HomePage />} />
          <Route path="request" element={<RequestPage />} />
          <Route path="credits" element={<CreditsPage />} />
          <Route path="credits/calc" element={<CreditsPageCalc />} />
          <Route path="cards" element={<CardsPage />} />
          {/* <Route
                        path="cards/:id"
                        element={<CardPage needMoreInfo={false} />}
                    /> */}
          <Route path="deposits" element={<DepositsPage />} />
          {/* <Route
                        path="deposits/:id"
                        element={<CardPage needMoreInfo={false} />}
                    /> */}
          <Route path="credits" element={<CreditsPage />} />
          {/* <Route path="about" element={<div>О банке</div>} /> */}
          {/* <Route path="*" element={<Notfoundpage />} /> */}
          {/* <Route path="authorization" element={<Registration />} /> */}

          {/* надо перенести в app lk */}
          {/* <Route path="request" element={<RequestPage />} /> */}
        </Routes>
      </main>
      <Footer />
    </>
  );
}

export default App;
