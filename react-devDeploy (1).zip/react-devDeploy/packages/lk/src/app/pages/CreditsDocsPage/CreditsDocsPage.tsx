import { Button, Typography } from '@./ui';
import { NavLink } from 'react-router-dom';
import CreditDocs from '../../components/CreditDocs/CreditDocs';
import styles from './CreditsDocsPage.module.sass';

const docList = [
    'УКБО',
    'Согласие на обработку и хранение персональных данных',
    'Согласие на передачу данных 3-им лицам',
    'Тариф на потребительский кредит',
    'Заявление-анкета на открытие кредитного счета',
    'Договор об оформлении пакета кредитования',
];

const CreditsDocsPage = () => {
    return (
        <>
            <div className={styles['wrapper']}>
                <div className={styles['header']}>
                    <Typography fontSize={'32px'} fontWeight="700" tag="h2">
                        Документы
                    </Typography>
                </div>
                <div className={styles['docs']}>
                    {docList.map((doc) => (
                        <CreditDocs docName={doc} />
                    ))}
                </div>
            </div>

            <div className={styles['buttons']}>
                <NavLink className={styles['item']} to="/credits/send">
                    <Button>Продолжить</Button>
                </NavLink>
            </div>
        </>
    );
};

export default CreditsDocsPage;
