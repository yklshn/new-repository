import { ExchangeRate, ServicesMain, SliderWrapper } from '@./ui';

import { DepartmentsWrapper } from '../../../../../../libs/ui/src/lib/DepartmentsWrapper/DepartmentsWrapper';

export const HomePage = () => {
  return (
    <div>
      <SliderWrapper />
      <ServicesMain />
      <ExchangeRate />
      <DepartmentsWrapper />
    </div>
  );
};
