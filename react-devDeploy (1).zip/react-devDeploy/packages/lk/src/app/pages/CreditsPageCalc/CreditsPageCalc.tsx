import { Button } from '@./ui';
import { useAppDispatch } from 'packages/lk/src/store/hook';
import { ChangeEvent, useEffect, useState } from 'react';
import { NavLink } from 'react-router-dom';

import { addRequest } from '../../../store/slices/requestSlice';
import { CreditCalculator } from '../../components/calculators/CreditCalculator/CreditCalculator';
import { CalculatorCard } from '../../components/cards/CalculatorCard/CalculatorCard';
import styles from './CreditsPageCalc.module.sass';

type UserChoice = {
  sum: string;
  currency: 'USD' | 'RUB' | 'EUR';
  term: string;
};

export const CreditsPageCalc = () => {
  const [selectValue, setSelectValue] = useState('');
  const [sumValue, setSumValue] = useState('');
  const [currencyValue, setCurrencyValue] = useState<'USD' | 'RUB' | 'EUR'>(
    'RUB'
  );

  const userChoice: UserChoice = {
    sum: '0',
    currency: 'RUB',
    term: '12 месяцев',
  };

  const dispatch = useAppDispatch();

  const periodSelectHandler = (e: ChangeEvent<HTMLSelectElement>) => {
    setSelectValue(e.target.value);
  };

  const sumInputHandler = (e: ChangeEvent<HTMLInputElement>) => {
    setSumValue(e.target.value);
  };

  const currencyInputHandler = (e: ChangeEvent<HTMLSelectElement>) => {
    if (
      e.target.value === 'RUB' ||
      e.target.value === 'EUR' ||
      e.target.value === 'USD'
    ) {
      setCurrencyValue(e.target.value);
    }
  };

  useEffect(() => {
    userChoice.sum = sumValue;
    userChoice.currency = currencyValue;
    userChoice.term = selectValue;

    dispatch(addRequest(userChoice));
  }, [selectValue, sumValue, currencyValue]);

  return (
    <div className={styles['wrapper']}>
      <CreditCalculator
        sumInputHandler={sumInputHandler}
        currencyInputHandler={currencyInputHandler}
        sumValue={sumValue}
        currencyValue={currencyValue}
      />
      <div className={styles['card']}>
        <CalculatorCard
          title={'Срок кредитования'}
          type="select"
          data={{
            optionsArray: [
              '12 месяцев',
              '18 месяцев',
              '24 месяцев',
              '36 месяцев',
              '48 месяцев',
              '60 месяцев',
            ],
            disabledOption: false,
            name: 'period',
            value: selectValue,
            onChange: periodSelectHandler,
          }}
        />
      </div>
      <div className={styles['card']}>
        <CalculatorCard title={'Процентная ставка'} type="text" data="9.9%" />
      </div>
      <div className={styles['card']}>
        <CalculatorCard
          title={'Ежемесячный платеж'}
          type="button"
          data={{ children: 'Рассчитать', variant: 'secondary' }}
        />
      </div>
      <div className={styles['buttons']}>
        <NavLink className={styles['item']} to="/request">
          <Button>Продолжить</Button>
        </NavLink>

        <Button variant="tertiary">Отмена</Button>
      </div>
    </div>
  );
};
