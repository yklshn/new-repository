import { Button, Typography } from '@./ui';
import { NavLink } from 'react-router-dom';
import styles from './CreditsSendPage.module.sass';

const CreditsSendPage = () => {
    return (
        <div className={styles['send']}>
            <div className={styles['send-header']}>
                <Typography fontSize={'32px'} fontWeight="700" tag="h1">
                    Заявка успешно отправлена!
                </Typography>
            </div>
            <div className={styles['send-content']}>
                <Typography fontSize={'16px'} fontWeight="500" tag="h2">
                    Срок рассмотрения заявки на кредит от 1 до 5 рабочих дней
                    включительно.
                    <br /> Справка по телефону 66544651
                </Typography>
            </div>
            <div className={styles['send-buttons']}>
                <NavLink className={styles['item']} to="/">
                    <Button>На главную</Button>
                </NavLink>
            </div>
        </div>
    );
};

export default CreditsSendPage;
