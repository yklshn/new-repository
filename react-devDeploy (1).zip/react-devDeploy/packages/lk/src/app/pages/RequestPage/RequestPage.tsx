import { Button, Typography } from '@./ui';
import { NavLink } from 'react-router-dom';

import { AdditionalProfit } from '../../components/AdditionalProfit/AdditionalProfit';
import { ProfileCard } from '../../components/cards/ProfileCard/ProfileCard';
import { ProfitCard } from '../../components/cards/ProfitCard/ProfitCard';
import styles from './RequestPage.module.sass';
import addProfitIcon from '/libs/img/addProfitIcon.png';

export const RequestPage = () => {
  return (
    <div className={styles['wrapper']}>
      <div className={styles['header']}>
        <Typography fontSize={'24px'} fontWeight="700" tag="h2">
          Оформление заявки
        </Typography>
      </div>
      <ProfileCard
        header="Место работы"
        data={[
          {
            title: 'Название организаци',
            id: 'companyName',
            name: 'companyName',
            placeholder: '',
          },
          {
            title: 'Адрес организаци',
            id: 'companyAdress',
            name: 'companyAdress',
            placeholder: '',
          },
          {
            title: 'Телефон организаци',
            id: 'companyPhone',
            name: 'companyPhone',
            placeholder: '',
          },
          {
            title: 'Должность',
            id: 'position',
            name: 'position',
            placeholder: '',
          },
        ]}
        fields={{
          companyName: 'companyName',
          companyAdress: 'companyAdress',
          companyPhone: 'companyPhone',
          position: 'position',
        }}
      />
      <ProfileCard
        header="Стаж работы"
        data={[
          {
            title: 'Полных лет',
            id: 'years',
            name: 'years',
            placeholder: '',
          },
          {
            title: 'Полных месяцев',
            id: 'months',
            name: 'months',
            placeholder: '',
          },
        ]}
        fields={{
          years: 'years',
          months: 'months',
        }}
      />
      <ProfitCard />
      <AdditionalProfit
        header={'Дополнительный доход'}
        imageSrc={addProfitIcon}
        text={'Вы можете добавить несколько видов дополнительного дохода.'}
      />
      <div className={styles['buttons']}>
        <NavLink className={styles['item']} to="/credits/send">
          <Button>Отправить заявку</Button>
        </NavLink>
        <Button variant="tertiary">Отмена</Button>
      </div>
    </div>
  );
};
