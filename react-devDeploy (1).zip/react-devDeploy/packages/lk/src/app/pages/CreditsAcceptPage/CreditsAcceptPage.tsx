import { Button, Image, Typography } from '@./ui';
import { NavLink } from 'react-router-dom';
import styles from './CreditsAcceptPage.module.sass';
import warn from '../../../../../../libs/img/warning.svg';

const CreditsAcceptPage = () => {
    return (
        <div className={styles['accept']}>
            <Image src={warn} className={styles['accept-warn']} />
            <div className={styles['accept-header']}>
                <Typography fontSize={'24px'} fontWeight="500" tag="h1">
                    Ваша заявка одобрена.
                </Typography>
            </div>
            <div className={styles['accept-content']}>
                <Typography fontSize={'16px'} fontWeight="400" tag="h2">
                    Для оформления кредита необходимо принять кредитное
                    предложение до 01.02.2022. Хотите продолжить оформление
                    кредита?
                </Typography>
            </div>
            <div className={styles['accept-buttons']}>
                <NavLink className={styles['item']} to="/">
                    <Button variant="tertiary">Отложить</Button>
                </NavLink>
                <NavLink className={styles['item']} to="/">
                    <Button variant="tertiary">Продолжить</Button>
                </NavLink>
            </div>
        </div>
    );
};

export default CreditsAcceptPage;
