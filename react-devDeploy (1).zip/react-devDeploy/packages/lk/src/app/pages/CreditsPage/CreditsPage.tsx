import { Button, Offer, OfferCard } from '@./ui';
import { inputSelector } from '@.lk/toolkitRedux';
import { useTranslation } from 'react-i18next';
import { useSelector } from 'react-redux';

import { TypeSwitcher } from '../../components/TypeSwitcher/TypeSwitcher';
import styles from './CreditsPage.module.sass';
import backgroundImage from '/libs/ui/img/creditsBackground.png';
import savingsDepositBackgroundImage from '/libs/ui/img/savingsDeposit.png';
import startDepositBackgroundImage from '/libs/ui/img/startDeposit.png';
import universalDepositBackgroundImage from '/libs/ui/img/universalDeposit.png';

interface DepositProps {
  id: string;
  cardImageWidth?: string | number;
  cardImageHeight?: string | number;
  cardImage: string;
  headerText?: string;
  leftColumnHeader: string;
  leftColumnTitle?: string;
  leftColumnSubtitle?: string;
  middleColumnHeader: string;
  middleColumnTitle?: string;
  rightColumnHeader: string;
  rightColumnTitle?: string;
  primaryButtonText?: string;
  secondaryButtonText?: string;
  needMoreInfo: boolean;
}

export const CreditsPage = () => {
  const { t } = useTranslation();
  const { toggler } = useSelector(inputSelector);
  const firstCreditProps: DepositProps = {
    id: '1',
    cardImageWidth: +t('credits.cardImageWidth.0'),
    cardImageHeight: +t('credits.cardImageHeight.0'),
    cardImage: universalDepositBackgroundImage,
    headerText: t('credits.title.0'),
    leftColumnHeader: t('credits.leftColumnHeader.0'),
    leftColumnTitle: t('credits.leftColumnTitle.0'),
    middleColumnHeader: t('credits.middleColumnHeader.0'),
    middleColumnTitle: t('credits.middleColumnTitle.0'),
    rightColumnHeader: t('credits.rightColumnHeader.0'),
    rightColumnTitle: t('credits.rightColumnTitle.0'),
    needMoreInfo: Boolean(t('credits.needMoreInfo.0')),
    primaryButtonText: t('credits.primaryButtonText.0'),
    secondaryButtonText: t('credits.secondaryButtonText.0'),
  };
  const secondCreditProps: DepositProps = {
    id: '2',
    cardImageWidth: +t('credits.cardImageWidth.1'),
    cardImageHeight: +t('credits.cardImageHeight.1'),
    cardImage: savingsDepositBackgroundImage,
    headerText: t('credits.title.1'),
    leftColumnHeader: t('credits.leftColumnHeader.1'),
    leftColumnTitle: t('credits.leftColumnTitle.1'),
    middleColumnHeader: t('credits.middleColumnHeader.1'),
    middleColumnTitle: t('credits.middleColumnTitle.1'),
    rightColumnHeader: t('credits.rightColumnHeader.1'),
    rightColumnTitle: t('credits.rightColumnTitle.1'),
    needMoreInfo: Boolean(t('credits.needMoreInfo.1')),
    primaryButtonText: t('credits.primaryButtonText.1'),
    secondaryButtonText: t('credits.secondaryButtonText.1'),
  };
  const thirdCreditProps: DepositProps = {
    id: '3',
    cardImageWidth: +t('credits.cardImageWidth.2'),
    cardImageHeight: +t('credits.cardImageHeight.2'),
    cardImage: startDepositBackgroundImage,
    headerText: t('credits.title.2'),
    leftColumnHeader: t('credits.leftColumnHeader.2'),
    leftColumnTitle: t('credits.leftColumnTitle.2'),
    middleColumnHeader: t('credits.middleColumnHeader.2'),
    middleColumnTitle: t('credits.middleColumnTitle.2'),
    rightColumnHeader: t('credits.rightColumnHeader.2'),
    rightColumnTitle: t('credits.rightColumnTitle.2'),
    needMoreInfo: Boolean(t('credits.needMoreInfo.2')),
    primaryButtonText: t('credits.primaryButtonText.2'),
    secondaryButtonText: t('credits.secondaryButtonText.2'),
  };

  const creditsPropsArray = [
    firstCreditProps,
    // secondCreditProps,
    // thirdCreditProps,
  ];

  return (
    <div className={styles['container']}>
      <div>
        <Offer
          // headerColor="white"
          // subheaderColor="white"
          headerText="Кредитные продукты"
          subheaderText="Зарабатывайте и экономьте деньги с картой Smart от
                        Бетта-Банка"
          buttonText="Подобрать кредит"
          backgroundImage={backgroundImage}
        />
      </div>
      <div className={styles['container']}>
        <div className={styles['wrap-card']}>
          {creditsPropsArray.map((item) => (
            <OfferCard {...item} key={item.id} typeOf={'credits'} />
          ))}
          <div className={styles['wrap-button']}>
            <Button variant="tertiary">Показать еще кредиты</Button>
          </div>
        </div>
      </div>
      {/*//demo*/}
      <TypeSwitcher
        // @ts-ignore
        items={[
          'Действия',
          'Условия',
          'График погашения',
          'История платежей',
          'Документы',
        ]}
        headerText={'Кредит «Универсальный»'}
      />
      {toggler === 'Действия' ? (
        <div style={{ paddingLeft: '72px' }}>
          <div
            style={{
              alignItems: 'center',
              height: '91px',
              background: '#FBFBFB',
              padding: '30px 30px 15px 30px',
              marginBottom: '40px',
            }}
          >
            <a
              href={'#'}
              style={{
                fontSize: '22px',
                marginBottom: '40px',
                textDecoration: 'none',
              }}
            >
              Погасить досрочно
            </a>
          </div>

          <div
            style={{
              alignItems: 'center',
              height: '91px',
              background: '#FBFBFB',
              padding: '30px 30px 15px 30px',
              marginBottom: '40px',
            }}
          >
            <a
              href={'#'}
              style={{
                fontSize: '22px',
                marginBottom: '40px',
                textDecoration: 'none',
              }}
            >
              Пополнить
            </a>
          </div>

          <div
            style={{
              alignItems: 'center',
              height: '91px',
              background: '#FBFBFB',
              padding: '30px 30px 15px 30px',
              marginBottom: '40px',
            }}
          >
            <div style={{ fontSize: '22px' }}>Скрыть кредит</div>
          </div>
        </div>
      ) : null}

      {toggler === 'Условия' ? (
        <div style={{ paddingLeft: '72px' }}>
          <div
            style={{
              alignItems: 'center',
              height: '91px',
              background: '#FBFBFB',
              padding: '20px 30px 15px 30px',
              marginBottom: '40px',
              display: 'flex',
              alignContent: 'center',
            }}
          >
            <div style={{ fontSize: '22px', width: '50%' }}>Валюта кредита</div>
            <div style={{ fontSize: '22px', width: '50%' }}>RUB</div>
          </div>
          <div
            style={{
              alignItems: 'center',
              height: '91px',
              background: '#FBFBFB',
              padding: '20px 30px 15px 30px',
              marginBottom: '40px',
              display: 'flex',
              alignContent: 'center',
            }}
          >
            <div style={{ fontSize: '22px', width: '50%' }}>Сумма кредита</div>
            <div style={{ fontSize: '22px', width: '50%' }}>500 000 RUB</div>
          </div>
          <div
            style={{
              alignItems: 'center',
              height: '91px',
              background: '#FBFBFB',
              padding: '20px 30px 15px 30px',
              marginBottom: '40px',
              display: 'flex',
              alignContent: 'center',
            }}
          >
            <div style={{ fontSize: '22px', width: '50%' }}>
              Ежемесячный платеж
            </div>
            <div style={{ fontSize: '22px', width: '50%' }}>25 000 RUB</div>
          </div>
          <div
            style={{
              alignItems: 'center',
              height: '91px',
              background: '#FBFBFB',
              padding: '20px 30px 15px 30px',
              marginBottom: '40px',
              display: 'flex',
              alignContent: 'center',
            }}
          >
            <div style={{ fontSize: '22px', width: '50%' }}>
              Процентная ставка
            </div>
            <div style={{ fontSize: '22px', width: '50%' }}>12% годовых</div>
          </div>
          <div
            style={{
              alignItems: 'center',
              height: '91px',
              background: '#FBFBFB',
              padding: '20px 30px 15px 30px',
              marginBottom: '40px',
              display: 'flex',
              alignContent: 'center',
            }}
          >
            <div style={{ fontSize: '22px', width: '50%' }}>
              Дата открытия кредита
            </div>
            <div style={{ fontSize: '22px', width: '50%' }}>01.06.2022</div>
          </div>
          <div
            style={{
              alignItems: 'center',
              height: '91px',
              background: '#FBFBFB',
              padding: '20px 30px 15px 30px',
              marginBottom: '40px',
              display: 'flex',
              alignContent: 'center',
            }}
          >
            <div style={{ fontSize: '22px', width: '50%' }}>
              ДаZта окончания кредита
            </div>
            <div style={{ fontSize: '22px', width: '50%' }}>01.06.2024</div>
          </div>
          <div
            style={{
              alignItems: 'center',
              height: '91px',
              background: '#FBFBFB',
              padding: '20px 30px 15px 30px',
              marginBottom: '40px',
              display: 'flex',
              alignContent: 'center',
            }}
          >
            <div style={{ fontSize: '22px', width: '50%' }}>
              Счет погашения{' '}
            </div>
            <div style={{ fontSize: '22px', width: '50%' }}>
              56465165165498465156189498461
            </div>
          </div>
          <div
            style={{
              alignItems: 'center',
              height: '91px',
              background: '#FBFBFB',
              padding: '20px 30px 15px 30px',
              marginBottom: '40px',
              display: 'flex',
              alignContent: 'center',
            }}
          >
            <div style={{ fontSize: '22px', width: '50%' }}>
              Оставшаяся сумма к выплате
            </div>
            <div style={{ fontSize: '22px', width: '50%' }}>420 000 RUB</div>
          </div>
          <div
            style={{
              alignItems: 'center',
              height: '91px',
              background: '#FBFBFB',
              padding: '20px 30px 15px 30px',
              marginBottom: '40px',
              display: 'flex',
              alignContent: 'center',
            }}
          >
            <div style={{ fontSize: '22px', width: '50%' }}>
              Привязанные карты
            </div>
            <div style={{ fontSize: '22px', width: '50%' }}>
              5516 5455 1564 5410
            </div>
          </div>
        </div>
      ) : null}

      {toggler === 'Документы' ? (
        <div style={{ paddingLeft: '72px' }}>
          <div
            style={{
              alignItems: 'center',
              height: '91px',
              background: '#FBFBFB',
              padding: '30px 30px 15px 30px',
              marginBottom: '40px',
            }}
          >
            <a
              href={'#'}
              style={{
                fontSize: '22px',
                marginBottom: '40px',
                textDecoration: 'none',
              }}
            >
              Просмотреть договор
            </a>
          </div>

          <div
            style={{
              alignItems: 'center',
              height: '91px',
              background: '#FBFBFB',
              padding: '30px 30px 15px 30px',
              marginBottom: '40px',
            }}
          >
            <a
              href={'#'}
              style={{
                fontSize: '22px',
                marginBottom: '40px',
                textDecoration: 'none',
              }}
            >
              Скачать договор{' '}
            </a>
          </div>
          <div
            style={{
              alignItems: 'center',
              height: '91px',
              background: '#FBFBFB',
              padding: '30px 30px 15px 30px',
              marginBottom: '40px',
            }}
          >
            <a
              href={'#'}
              style={{
                fontSize: '22px',
                marginBottom: '40px',
                textDecoration: 'none',
              }}
            >
              Отправить на почту{' '}
            </a>
          </div>
        </div>
      ) : null}

      {/*//demo*/}
    </div>
  );
};
