import { Typography } from '@./ui';

import styles from './TypeSwitcher.module.sass';
import { useDispatch, useSelector } from 'react-redux';
import { setToggler } from '../../../toolkitRedux/toolkitSlice';
import { inputSelector } from '@.landing/toolkitRedux';

type MainNavigation = {
    items: any[];
    headerText?: string;
};

export const TypeSwitcher = ({ items, headerText }: MainNavigation) => {
    const dispatch = useDispatch();
    const { toggler } = useSelector(inputSelector);

    return (
        <>
            <div className={styles['wrapper']}>
                {headerText ? (
                    <div className="">
                        <Typography
                            tag={'h3'}
                            fontSize={'size44'}
                            fontWeight={'weight700'}
                        >
                            {headerText}
                        </Typography>
                    </div>
                ) : (
                    <></>
                )}
                <div
                    style={{ gridTemplateColumns: '1fr 200px 1fr 1fr 1fr' }}
                    className={styles['wrapper-options']}
                >
                    {items.map((item) => {
                        return (
                            // @ts-ignore
                            <div
                                style={
                                    toggler === item
                                        ? {
                                              fontWeight: 700,
                                              borderBottom:
                                                  '2px solid #FEDA00FF',
                                              paddingBottom: '5px',
                                              cursor: 'pointer',
                                          }
                                        : { cursor: 'pointer' }
                                }
                                onClick={() => dispatch(setToggler(item))}
                                className={styles['item']}
                                key={item}
                            >
                                <Typography tag={'span'}>{item}</Typography>
                            </div>
                        );
                    })}
                </div>
            </div>
        </>
    );
};
