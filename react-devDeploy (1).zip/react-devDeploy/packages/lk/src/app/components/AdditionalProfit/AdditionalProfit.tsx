import { Image, Typography } from '@./ui';

import styles from './AdditionalProfit.module.sass';

type AdditionalProfitProps = {
  header: string;
  imageSrc: string;
  text: string;
};

export const AdditionalProfit = ({
  header,
  imageSrc,
  text,
}: AdditionalProfitProps) => {
  return (
    <div className={styles['wrapper']}>
      <div className={styles['main']}>
        <div className="">
          <Typography fontSize={'20px'} fontWeight="700" tag="h3">
            {header}
          </Typography>
        </div>
        <div className={styles['image']}>
          <Image src={imageSrc} width={24} height={24} />
        </div>
      </div>
      <div className="">
        <Typography fontSize={'14px'} fontWeight="400" tag="h2">
          {text}
        </Typography>
      </div>
    </div>
  );
};
