import { CustomSelect, Typography } from '@./ui';
import { Formik } from 'formik';
import {
    CustomTextInput,
    CustomTextInputProps,
} from '../../../../../../../libs/ui/src/lib/Inputs/CustomTextInput';
import * as yup from 'yup';
import { ChangeEvent, useState } from 'react';

import styles from './ProfitCard.module.sass';

// type FieldsType = {
//     id: string;
//     name: string;
//     title?: string;
//     placeholder?: string;
// };

// type ProfileCardProps = {
//     header: string;
//     data: FieldsType[];
//     fields: object;
// };

export const ProfitCard = () => {
    const textProps = {
        title: 'Полных месяцев',
        id: 'months',
        name: 'months',
        placeholder: '',
    };

    const fields = {
        profit: 'profit',
    };

    const [sumValue, setSumValue] = useState('');
    const [currencyValue, setCurrencyValue] = useState<'USD' | 'RUB' | 'EUR'>(
        'RUB'
    );

    const sumInputHandler = (e: ChangeEvent<HTMLInputElement>) => {
        setSumValue(e.target.value);
    };

    const currencyInputHandler = (e: ChangeEvent<HTMLSelectElement>) => {
        if (
            e.target.value === 'RUB' ||
            e.target.value === 'EUR' ||
            e.target.value === 'USD'
        ) {
            setCurrencyValue(e.target.value);
        }
    };

    return (
        <>
            <div className={styles['wrapper']}>
                <div className={styles['header']}>
                    <Typography>{'Сумма'}</Typography>
                </div>
                <div className={styles['inputs']}>
                    <Formik
                        initialValues={fields}
                        validateOnBlur
                        onSubmit={(values) => {
                            console.log(values);
                        }}
                    >
                        {({ values, errors, touched, handleChange }) => (
                            <>
                                <div className={styles['input--field']}>
                                    <CustomTextInput
                                        id={'profit'}
                                        name={'profit'}
                                        value={sumValue}
                                        onChange={sumInputHandler}
                                    />
                                    <CustomSelect
                                        optionsArray={['RUB', 'USD', 'EUR']}
                                        disabledOption={false}
                                        name={'curr'}
                                        value={currencyValue}
                                        onChange={currencyInputHandler}
                                    />
                                </div>
                            </>
                        )}
                    </Formik>
                </div>
            </div>
        </>
    );
};
