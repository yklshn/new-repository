import {
    Button,
    CustomRangeInput,
    CustomSelect,
    CustomTextInput,
    Typography,
} from '@./ui';
import {
    ChangeEvent,
    ChangeEventHandler,
    EventHandler,
    useEffect,
    useState,
} from 'react';

import { CustomSelectProps } from '../../../../../../../libs/ui/src/lib/Inputs/CustomSelect';
import { ButtonProps } from '../../../../../../../libs/ui/src/index';

import styles from './CalculatorCard.module.sass';

type CalculatorCardPropsType = 'range' | 'text' | 'select' | 'button';

type CalculatorCardPropsData<T extends CalculatorCardPropsType> =
    T extends 'select'
        ? CustomSelectProps
        : T extends 'text'
        ? string
        : T extends 'button'
        ? ButtonProps
        : string;

type CalculatorCardProps = {
    title: string;
    type: CalculatorCardPropsType;
    data: CalculatorCardPropsData<CalculatorCardProps['type']>;
};

export const CalculatorCard = ({ title, type, data }: CalculatorCardProps) => {
    const [actionElement, setActionElement] = useState<JSX.Element>(<></>);

    useEffect(() => {
        switch (type) {
            case 'select':
                setActionElement(
                    // @ts-ignore
                    <CustomSelect {...data} />
                );
                break;
            case 'text':
                setActionElement(
                    // @ts-ignore
                    <Typography fontSize={'24px'}>{data}</Typography>
                );
                break;
            case 'button':
                // @ts-ignore
                setActionElement(<Button {...data}></Button>);
                break;

            default:
                break;
        }
    }, [data]);

    return (
        <>
            <div className={styles['card']}>
                <div className={styles['card--title']}>
                    <Typography fontSize={'24px'}>{title}</Typography>
                </div>
                <div className={styles['card--action']}>{actionElement}</div>
            </div>
        </>
    );
};
