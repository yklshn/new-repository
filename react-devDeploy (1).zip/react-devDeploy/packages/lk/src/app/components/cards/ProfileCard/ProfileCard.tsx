import { Typography } from '@./ui';
import { Formik } from 'formik';
import {
    CustomTextInput,
    CustomTextInputProps,
} from '../../../../../../../libs/ui/src/lib/Inputs/CustomTextInput';
import * as yup from 'yup';

import styles from './ProfileCard.module.sass';

type FieldsType = {
    id: string;
    name: string;
    title?: string;
    placeholder?: string;
};

type ProfileCardProps = {
    header: string;
    data: FieldsType[];
    fields: object;
};

export const ProfileCard = ({ header, data, fields }: ProfileCardProps) => {
    const validationSchema = yup.object().shape({
        // fields.
    });

    return (
        <>
            <div className={styles['wrapper']}>
                <div className={styles['header']}>
                    <Typography fontSize={'20px'} fontWeight="700" tag="h3">
                        {header}
                    </Typography>
                </div>

                <div className={styles['inputs']}>
                    <Formik
                        initialValues={fields}
                        validateOnBlur
                        onSubmit={(values) => {
                            console.log(values);
                        }}
                    >
                        {({ values, errors, touched, handleChange }) =>
                            data.map(({ id, name, title, placeholder }) => {
                                return (
                                    <div className={styles['input--field']}>
                                        <CustomTextInput
                                            id={id}
                                            name={name}
                                            onChange={handleChange}
                                            title={title}
                                            placeholder={placeholder}
                                            // @ts-ignore
                                            value={values.name}
                                        />
                                    </div>
                                );
                            })
                        }
                    </Formik>
                </div>
            </div>
        </>
    );
};

// [{title, type, handler, id, name, value, event, handler}]
