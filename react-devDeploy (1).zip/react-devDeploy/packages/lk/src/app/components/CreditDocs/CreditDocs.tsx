import { Image, Typography } from '@./ui';
import styles from './CreditDocs.module.sass';
import checkmark from '../../../../../../libs/img/Checkmark.svg';
import chevron from '../../../../../../libs/img/chevron.svg';

type CreditDoc = {
    docName: string;
};

const CreditDocs = ({ docName }: CreditDoc) => {
    return (
        <div className={styles['wrapper']}>
            <div className={styles['doc']}>
                <Image src={checkmark} className={styles['doc-status']} />
                <Typography fontSize={'14px'} fontWeight="400" tag="span">
                    {docName}
                </Typography>
                <Image src={chevron} className={styles['doc-chevron']} />
            </div>
        </div>
    );
};

export default CreditDocs;
