import {
  CustomRangeInput,
  CustomSelect,
  CustomTextInput,
  Typography,
} from '@./ui';
import { ChangeEvent, ChangeEventHandler, useState } from 'react';

import styles from './CreditCalculator.module.sass';

type CreditCalculatorProps = {
  sumInputHandler: ChangeEventHandler;
  currencyInputHandler: ChangeEventHandler;
  sumValue: string;
  currencyValue: string;
};

export const CreditCalculator = ({
  sumInputHandler,
  currencyInputHandler,
  sumValue,
  currencyValue,
}: CreditCalculatorProps) => {
  // const [sumValue, setSumValue] = useState('');
  // const [currencyValue, setCurrencyValue] = useState('');
  // const [currencyValue, setCurrencyValue] = useState('');

  // const sumInputHandler = (e: ChangeEvent<HTMLInputElement>) => {
  //     setSumValue(e.target.value);
  // };
  // const sumInputHandler = (e: ChangeEvent<HTMLInputElement>) => {
  //     setSumValue(e.target.value);
  // };

  // const currencyInputHandler = (e: ChangeEvent<HTMLSelectElement>) => {
  //     setCurrencyValue(e.target.value);
  // };

  // const sumRangeInputHandler = (e: ChangeEvent<HTMLSelectElement>) => {
  //     setCurrencyValue(e.target.value);
  // };

  return (
    <div className={styles['wrapper']}>
      <div className={styles['title']}>
        <Typography tag="h2" fontSize={'32px'} fontWeight="700">
          Кредитный калькулятор
        </Typography>
      </div>
      <div className={styles['inputs']}>
        <div className={styles['inputs--sumcurrency']}>
          <CustomTextInput
            upperLabel={'Сумма кредита'}
            id="sum"
            name="sum"
            onChange={sumInputHandler}
            value={sumValue}
          />
          <CustomSelect
            upperLabel="Валюта"
            disabledOption={true}
            disabledOptionText={'RUB'}
            optionsArray={['RUB', 'USD', 'EUR']}
            name="currency"
            value={currencyValue}
            onChange={currencyInputHandler}
          />
        </div>
        <CustomRangeInput
          name="sum"
          id="sum"
          min={50000}
          max={50000000}
          onChange={sumInputHandler}
          value={sumValue}
          minText={'50000'}
          maxText={'50000000'}
        />
      </div>
    </div>
  );
};
