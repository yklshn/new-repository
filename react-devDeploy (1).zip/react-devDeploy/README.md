# A-banking

## Web-version

Required tech
Node js: https://nodejs.org/en/
Nx: https://nx.dev/

## Installation

Clone the repo

```sh
https://git.astondevs.ru/aston/a-bank/react.git
```

A-banking requires [Node.js](https://nodejs.org/) v10+ to run.
Install the dependencies and devDependencies and start the server.

```sh
cd react
npm i
```

To start landing version.

```sh
npx nx serve landing
```

To start lk version.

```sh
npx nx serve lk
```
