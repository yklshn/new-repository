import { Image, Typography } from '@./ui';
import { inputSelector } from '@.landing/toolkitRedux';
import { setUserAuth } from 'packages/landing/src/toolkitRedux/toolkitSlice';
import { useTranslation } from 'react-i18next';
import { useDispatch, useSelector } from 'react-redux';
import { Link, NavLink } from 'react-router-dom';

// @ts-ignore
import { OffcanvasExample } from '../../../../../packages/landing/src/app/components/NavbarBootstrap/NavbarBootstrap';
import styles from './BarNav.module.sass';
import search from '/libs/img/search.svg';

export type AuthType = {
  auth: boolean;
};
export const NavBar = ({ auth }: AuthType) => {
  const { t } = useTranslation();

  const title = [t('navbar.title.0')];
  const nav = [
    t('navbar.nav.0'),
    t('navbar.nav.1'),
    t('navbar.nav.2'),
    t('navbar.nav.3'),
    t('navbar.nav.4'),
  ];
  const buttonTexts = [t('navbar.buttonText.0'), t('navbar.buttonText.1')];
  return (
    <>
      <div className={styles['hideOnMobile']}>
        <div className={styles['wrap']}>
          <NavLink className={styles['logo']} to="/">
            <Typography tag={'span'} fontSize={'24px'} fontWeight={'700'}>
              {title[0]}
            </Typography>
          </NavLink>

          <div className={styles['flexContainer']}>
            <NavLink className={styles['item']} to="/">
              <Typography tag={'span'}>{nav[0]}</Typography>
            </NavLink>

            <NavLink className={styles['item']} to="/cards">
              <Typography tag={'span'}>{nav[1]}</Typography>
            </NavLink>

            <NavLink className={styles['item']} to="/deposits">
              <Typography tag={'span'}>{nav[2]}</Typography>
            </NavLink>

            <NavLink className={styles['item']} to={`/credits`}>
              <Typography tag={'span'}>{nav[3]}</Typography>
            </NavLink>

            <NavLink className={styles['item']} to="/about">
              <Typography tag={'span'}>{nav[4]}</Typography>
            </NavLink>
          </div>

          {
            auth ? (
              <Link className={styles['enter']} to="//localhost:3000/">
                <Typography
                  style={{ cursor: 'pointer' }}
                  onClick={() => console.log('setAuthFalse')}
                  tag={'span'}
                  fontWeight={'weight600'}
                  color={'blue'}
                >
                  {buttonTexts[1]}
                </Typography>
              </Link>
            ) : (
              <Link className={styles['enter']} to="/authorization">
                <Typography
                  style={{ cursor: 'pointer' }}
                  onClick={() => console.log('setAuth')}
                  tag={'span'}
                  fontWeight={'weight600'}
                  color={'blue'}
                >
                  {buttonTexts[0]}
                </Typography>
              </Link>
            )
            // </NavLink>
          }
          <Image width={18} height={18} src={search} alt={'search'} />
        </div>
      </div>
      <div className={styles['showOnMovile']}>
        <OffcanvasExample />
      </div>
    </>
  );
};
