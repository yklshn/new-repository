import { Typography } from '@./ui';
import { inputSelector } from '@.landing/toolkitRedux';
import { setUserAuth } from 'packages/landing/src/toolkitRedux/toolkitSlice';
import * as process from 'process';
import { FC } from 'react';
import { useTranslation } from 'react-i18next';
import { useDispatch, useSelector } from 'react-redux';
import { Link } from 'react-router-dom';

import styles from './BarNav.module.sass';

type AuthLink = {
  to: string;
  isUserAuth: boolean;
  btnTextIndex: number;
};

export const AuthLink = ({ to, isUserAuth, btnTextIndex }: AuthLink) => {
  const dispatch = useDispatch();
  const { t } = useTranslation();
  const { auth } = useSelector(inputSelector);

  const buttonTexts = [t('navbar.buttonText.0'), t('navbar.buttonText.1')];

  return (
    <>
      {auth ? (
        <Link
          to={to}
          className={styles['enter']}
          onClick={() => dispatch(setUserAuth(isUserAuth))}
        >
          <Typography tag={'span'} fontWeight={'weight600'} color={'blue'}>
            {buttonTexts[btnTextIndex]}
          </Typography>
        </Link>
      ) : (
        <a
          href={`//localhost:3001/`}
          className={styles['enter']}
          target={'_blank'}
          onClick={() => dispatch(setUserAuth(isUserAuth))}
        >
          <Typography tag={'span'} fontWeight={'weight600'} color={'blue'}>
            {buttonTexts[btnTextIndex]}
          </Typography>
        </a>
      )}
    </>
  );
};
