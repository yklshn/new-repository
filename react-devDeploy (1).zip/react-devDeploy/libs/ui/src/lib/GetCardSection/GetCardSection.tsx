import { Step } from './Step/Step';

import styles from './GetCardSection.module.sass';
import { Typography } from '@./ui';

export type GetCardSection = {
    headerText?: string;
    steps: object[];
};

type Step = {
    stepNumber?: number;
    stepTitle?: string;
    stepSubtitle?: string;
};

export const GetCard = ({ headerText, steps }: GetCardSection) => {
    return (
        <div className={styles['wrap']}>
            <Typography
                fontSize={'size44'}
                fontWeight={'weight700'}
                lineHeight={'120'}
            >
                {headerText}
            </Typography>
            <div className={styles['steps']}>
                {steps &&
                    steps.map(
                        ({ stepNumber, stepTitle, stepSubtitle }: Step) => (
                            <Step
                                key={stepNumber}
                                stepNumber={stepNumber}
                                stepTitle={stepTitle}
                                stepSubtitle={stepSubtitle}
                            />
                        )
                    )}
            </div>
        </div>
    );
};
