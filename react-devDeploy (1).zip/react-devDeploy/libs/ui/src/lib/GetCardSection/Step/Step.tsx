import { Typography } from '@./ui';

import styles from './Step.module.sass';

type StepProps = {
  stepNumber?: number;
  stepTitle?: string;
  stepSubtitle?: string;
};

export const Step = ({
  stepNumber = 1,
  stepTitle = 'Заполните заявку',
  stepSubtitle = 'Заполните заявку на сайте или в офисе Банка',
}: StepProps) => {
  return (
    <div className={styles['wrap']}>
      <div className={styles['number']}>
        <Typography
          fontSize={'size48'}
          color={'numbers'}
          fontWeight={'weight500'}
          lineHeight={'120'}
        >
          {stepNumber}
        </Typography>
      </div>
      <div className={styles['title']}>
        <Typography
          fontSize={'size24'}
          fontWeight={'weight700'}
          lineHeight={'120'}
        >
          {stepTitle}
        </Typography>
      </div>
      <div className={styles['subtitle']}>
        <Typography fontSize={'size18'} lineHeight={'140'}>
          {stepSubtitle}
        </Typography>
      </div>
    </div>
  );
};
