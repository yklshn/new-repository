import { Image, Typography } from '@./ui';

import styles from './Image.module.sass';

type CardImageProps = {
  cardTitle?: string[];
  cardNumber?: string;
  background?: string;
  cardImageWidth?: number;
  cardImageHeight?: number;
  cardImage: string;
};

export const CImage = ({
  cardTitle,
  cardNumber,
  background,
  cardImageWidth,
  cardImageHeight,
  cardImage,
}: CardImageProps) => {
  return (
    <div className={styles['card-image']}>
      <Image
        src={cardImage}
        width={cardImageWidth}
        height={cardImageHeight}
        background={background}
      />
      {cardTitle && cardNumber && (
        <>
          <div className={styles['card-image-text']}>
            <Typography color="white">{cardTitle}</Typography>
          </div>
          <div className={styles['card-image-number']}>
            <Typography color="white" lineHeight={'140'}>
              {cardNumber}
            </Typography>
          </div>
        </>
      )}
    </div>
  );
};
