import { Button } from '@./ui';
import { addCard } from 'packages/landing/src/toolkitSlices/cardsSlice';
import { useDispatch } from 'react-redux';
import { Link } from 'react-router-dom';

import styles from './Buttons.module.sass';

type CardButtonsProps = {
  headerText?: string;
  cardNumber?: string;
  id?: string;
  needMoreInfo: boolean;
  background?: string;
  cardTitle?: string[];
  leftColumnHeader?: string;
  leftColumnTitle?: string;
  leftColumnSubtitle?: string;
  middleColumnHeader?: string;
  middleColumnTitle?: string;
  middleColumnSubtitle?: string;
  rightColumnHeader?: string;
  rightColumnTitle?: string;
  rightColumnSubtitle?: string;
  primaryButtonText?: string;
  secondaryButtonText?: string;
  typeOf?: string;
  depositCurrency?: string;
  depositSumMin?: string;
  depositSumMax?: string;
  depositTerm?: string;
  depositEarlyClosed?: boolean;
  depositReplenishingBalancePossibility?: boolean;
  depositFullDescription?: string;
};

export const Buttons = ({
  id,
  needMoreInfo,
  headerText,
  cardNumber,
  cardTitle,
  background,
  leftColumnHeader,
  leftColumnTitle,
  leftColumnSubtitle,
  middleColumnHeader,
  middleColumnTitle,
  middleColumnSubtitle,
  rightColumnHeader,
  rightColumnTitle,
  rightColumnSubtitle,
  primaryButtonText,
  secondaryButtonText,
  typeOf,
  depositCurrency,
  depositSumMin,
  depositSumMax,
  depositTerm,
  depositEarlyClosed,
  depositReplenishingBalancePossibility,
  depositFullDescription,
}: CardButtonsProps) => {
  const dispatch = useDispatch();

  const onCardOpen = () => {
    typeOf === 'cards'
      ? dispatch(
          addCard({
            id,
            needMoreInfo,
            headerText,
            leftColumnHeader,
            leftColumnTitle,
            leftColumnSubtitle,
            middleColumnHeader,
            middleColumnTitle,
            middleColumnSubtitle,
            rightColumnHeader,
            rightColumnTitle,
            rightColumnSubtitle,
            cardNumber,
            cardTitle,
            background,
          })
        )
      : dispatch(
          addCard({
            depositCurrency,
            depositSumMin,
            depositSumMax,
            depositTerm,
            depositEarlyClosed,
            depositReplenishingBalancePossibility,
            depositFullDescription,
            id,
            headerText,
            leftColumnHeader,
            leftColumnTitle,
            middleColumnHeader,
            middleColumnTitle,
            rightColumnHeader,
            rightColumnTitle,
            cardTitle,
          })
        );
  };

  return (
    <div className={styles['card-buttons']}>
      {primaryButtonText && (
        <Link to={`/authorization`}>
          <Button>{primaryButtonText}</Button>
        </Link>
      )}

      {needMoreInfo ? (
        <Link to={`/${typeOf}/${id}`}>
          <Button variant="secondary" onClick={onCardOpen}>
            {secondaryButtonText}
          </Button>
        </Link>
      ) : (
        <></>
      )}
    </div>
  );
};
