export const URL_CARD = "http://10.10.15.227"
