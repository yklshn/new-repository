import { Typography, Button, Image } from '@./ui';

import styles from './Departments.module.sass';

type propTypes = {
    title: string;
    placeholderText: string;
    buttonText: string;
    image: string;
};

export const Departments = ({
    title,
    placeholderText,
    buttonText,
    image,
}: propTypes) => {
    return (
        <div className={styles['container']}>
            <div>
                <Typography tag={'h2'} fontSize="44px" fontWeight="700">
                    {title}
                </Typography>
            </div>

            <div>
                <form>
                    <input
                        type="text"
                        placeholder={placeholderText}
                        className={styles['search']}
                    />
                    <span className={styles['button']}>
                        <Button variant={'primary'}>{buttonText}</Button>
                    </span>
                    <Image
                        src={image}
                        className={styles['image']}
                        width={22}
                        height={22}
                    ></Image>
                </form>
            </div>
        </div>
    );
};
