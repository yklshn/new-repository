import icon_loup from 'libs/img/loupe_gray.svg';
import { useTranslation } from 'react-i18next';

import { Departments } from './Departments/Departments';
import styles from './DepartmentsWrapper.module.sass';

export const DepartmentsWrapper = () => {
  const { t } = useTranslation();
  return (
    <div>
      <Departments
        title={t('departments.title')}
        placeholderText={t('departments.placeholderText')}
        buttonText={t('departments.buttonText')}
        image={icon_loup}
      />

      <div className={styles['maps']}>
        <iframe
          title="map"
          src="https://yandex.ru/map-widget/v1/?um=constructor%3Abf4c5684012f4ec32ddd3516a7d855e325feb2d4fd94621ee51ffffb46ded952&amp;source=constructor"
        ></iframe>
      </div>
    </div>
  );
};
