import { Link } from 'react-router-dom';
import s from './LinkReact.module.sass';
import { Typography } from '../Typography/Typography';

type LinkReact = {
    text: string;
    color: string;
    to: string;
};

export const LinkReact = ({ text, color, to }: LinkReact): JSX.Element => {
    return (
        <Link className={s['link']} to={to}>
            <Typography color={color}>{text}</Typography>
        </Link>
    );
};
