import { Button, Image, Typography } from '@./ui';

import styles from './ServicesItem.module.sass';

type propTypes = {
  title?: string;
  text?: string;
  buttonText?: string;
  image: string;
};

export const ServicesItem = ({ title, text, buttonText, image }: propTypes) => {
  return (
    <div className={styles['wrap']}>
      <span className={styles['img-block']}>
        <Image src={image} width={239} height={250} />
      </span>

      <div className={styles['text-block']}>
        <div className={styles['title']}>
          <Typography tag={'h2'} fontSize="24px" fontWeight="700">
            {title}
          </Typography>
        </div>

        <div className={styles['text']}>
          <Typography tag={'p'} fontSize="18px" fontWeight="400">
            {text}
          </Typography>
        </div>

        <div className={styles['button']}>
          <Button variant={'secondary'}>{buttonText}</Button>
        </div>
      </div>
    </div>
  );
};
