import { Typography } from '@./ui';
import { useTranslation } from 'react-i18next';
import { ServicesItem } from './ServicesItemFolder/ServicesItem';

import styles from './Services.module.sass';

export const ServicesMain = () => {
    const { t } = useTranslation();
    const titleItems = [
        t('services.title.0'),
        t('services.title.1'),
        t('services.title.2'),
        t('services.title.3'),
    ];
    const titleHeader = t('services.header.0')
    const images = [
        require('/libs/img/services_1.jpg'),
        require('/libs/img/services_2.jpg'),
        require('/libs/img/services_3.jpg'),
        require('/libs/img/services_4.jpg'),
    ];

    return (
        <div className={styles['container']}>
            <div className={styles['title']}>
                <Typography tag={'h2'} fontSize="44px" fontWeight="700">
                    {titleHeader}
                </Typography>
            </div>
            <div className={styles['wrap']}>
                {titleItems.map((item, index) => (
                    <div key={index} className={styles['item']}>
                        <ServicesItem
                            title={item}
                            text={t(`services.text.${index}`)}
                            buttonText={t(`services.buttonText.${index}`)}
                            image={images[index]}
                        />
                    </div>
                ))}
            </div>
        </div>
    );
};
