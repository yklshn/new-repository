import { Typography } from '@./ui';

import { Step } from './Step/Step';

import styles from './GetCard.module.sass';

type GetCardSection = {
    headerText?: string;
    steps: object[];
};

type Step = {
    stepNumber?: number;
    stepTitle?: string;
    stepSubtitle?: string;
};

export const GetCard = ({ headerText, steps }: GetCardSection) => {
    return (
        <div className={styles['wrap']}>
            <Typography
                tag="h3"
                fontSize={'size44'}
                fontWeight={'weight700'}
                lineHeight={'120'}
            >
                {headerText}
            </Typography>
            <div className={styles['steps']}>
                {steps &&
                    steps.map(
                        ({ stepNumber, stepTitle, stepSubtitle }: Step) => (
                            <Step
                                key={stepNumber}
                                stepNumber={stepNumber}
                                stepTitle={stepTitle}
                                stepSubtitle={stepSubtitle}
                            />
                        )
                    )}
            </div>
        </div>
    );
};
