import { Button, Image, Typography } from '@./ui';

import styles from './Offer.module.sass';

type MainOffer = {
  headerText?: string;
  headerColor?: string;
  subheaderText?: string;
  subheaderColor?: string;
  buttonText?: string;
  backgroundImage?: string;
};

export const Offer = ({
  headerText,
  headerColor,
  subheaderText,
  subheaderColor,
  buttonText,
  backgroundImage,
}: MainOffer) => {
  return (
    <div className={styles['container']}>
      <Image src={backgroundImage} className={styles['background']} />
      <div className={styles['wrap']}>
        <div className={styles['text']}>
          <Typography
            tag={'h2'}
            fontSize={'size60'}
            fontWeight={'weight700'}
            color={headerColor}
            width={'530px'}
          >
            {headerText}
          </Typography>
          <Typography
            tag={'span'}
            fontSize={'size22'}
            color={subheaderColor}
            width={'526px'}
          >
            {subheaderText}
          </Typography>
          <Button variant="primary">{buttonText}</Button>
        </div>
      </div>
    </div>
  );
};
