import { Image, Typography } from '@./ui';
import { useEffect } from 'react';

import {
  useAppDispatch,
  useAppSelector,
} from '../../../../../../packages/landing/src/hooks/redux';
import { fetchRates } from '../../../../../../packages/landing/src/toolkitSlices/actionCreators';
import {
  fieldsType,
  keysType,
  rateType,
} from '../../../../../../packages/landing/src/types/rateType';
import styles from './ExchangeRateData.module.sass';
import iconEUR from '/libs/img/eur.svg';
import iconUSD from '/libs/img/usd.svg';

type propTypes = {
  type: 'USD' | 'EUR';
};

export const ExchangeRateData = ({ type }: propTypes) => {
  const { rates } = useAppSelector((state) => state.rateReducer);
  const dispatch = useAppDispatch();

  useEffect(() => {
    dispatch(fetchRates());
  }, [dispatch]);

  const date = new Date().toLocaleDateString();
  let unitBuy = 0;
  let unitSell = 0;
  let valutaName: keysType;

  for (valutaName in rates as rateType) {
    if (valutaName === type.toLowerCase()) {
      for (const item of rates[valutaName] as fieldsType[]) {
        if (item.type === 'buy') {
          unitBuy = item.value;
        }
        if (item.type === 'sell') {
          unitSell = item.value;
        }
      }
    }
  }
  const exchangeData = [type, date, unitBuy, unitSell];

  let icon = '';

  switch (type) {
    case 'USD':
      icon = iconUSD;
      break;
    case 'EUR':
      icon = iconEUR;
      break;
    default:
      icon = '';
  }

  return (
    <>
      {exchangeData.map((item, index) => (
        <span key={index} className={styles['item']}>
          <span>
            {index === 0 ? (
              <span className={styles['icon']}>
                <Image src={icon} width={36} height={36}></Image>
              </span>
            ) : (
              ''
            )}
          </span>
          <Typography fontSize="22px" fontWeight="400" color="black-total">
            {item}
          </Typography>
        </span>
      ))}
    </>
  );
};
