import { Button, Typography } from '@./ui';
import { useTranslation } from 'react-i18next';
import { ExchangeRateData } from './ExchangeRateData/ExchangeRateData';

import styles from './ExchangeRate.module.sass';

export const ExchangeRate = () => {
    const { t } = useTranslation();
    const names = [
        t('exchangeRate.names.0'),
        t('exchangeRate.names.1'),
        t('exchangeRate.names.2'),
        t('exchangeRate.names.3'),
    ];

    return (
        <div className={styles['container']}>
            <div className={styles['title']}>
                <Typography tag={'h2'} fontSize="44px" fontWeight="700">
                    {t('exchangeRate.title')}
                </Typography>
            </div>

            <div className={styles['wrap']}>
                {names.map((name, index) => (
                    <Typography
                        key={index}
                        fontSize="inherit"
                        fontWeight="700"
                        color="numbers"
                    >
                        {name}
                    </Typography>
                ))}

                <ExchangeRateData type={'USD'} />

                <ExchangeRateData type={'EUR'} />
            </div>

            <div className={styles['button']}>
                <Button variant={'secondary'}>
                    {t('exchangeRate.buttonText')}
                </Button>
            </div>
        </div>
    );
};
