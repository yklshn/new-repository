import { useTranslation } from 'react-i18next';

import { Typography } from '@./ui';
import { useSelector } from 'react-redux';
// import { cardProp } from '../../pages/cardpage/CardPage';

import styles from './CardDetails.module.sass';

export type cardProp = {
    card: {
        id?: string;
        // cardImageWidth?: string | number;
        // cardImageHeight?: string | number;
        // cardImage?: string;
        leftColumnHeader?: string;
        leftColumnTitle?: string;
        // leftColumnSubtitle?: string;
        middleColumnHeader?: string;
        middleColumnTitle?: string;
        // middleColumnSubtitle?: string;
        rightColumnHeader?: string;
        rightColumnTitle?: string;
        // rightColumnSubtitle?: string;
        // primaryButtonText?: string;
        // secondaryButtonText?: string;
        headerText?: string;
        // cardNumber?: string;
        cardTitle: string[];
        // background?: string;
        depositCurrency?: string;
        depositSumMin?: string;
        depositSumMax?: string;
        depositTerm?: string;
        depositEarlyClosed?: boolean;
        depositReplenishingBalancePossibility?: boolean;
        depositFullDescription?: string;
    };
};

export const CardDetails = () => {
    const cardData = useSelector((state: cardProp) => state.card);

    const { t } = useTranslation();
    const currency = t('cardDetails.0');
    const sum = t('cardDetails.1');
    const from = t('cardDetails.2');
    const to = t('cardDetails.3');
    const duration = t('cardDetails.4');
    const months = t('cardDetails.5');
    const contribution = t('cardDetails.6');
    const provided = t('cardDetails.7');
    const notProvided = t('cardDetails.8');
    const withdrawal = t('cardDetails.9');
    const fullInfo = t('cardDetails.10');

    const depositInfoArray = [
        { header: currency, data: cardData.depositCurrency },
        {
            header: sum,
            data: `${from} ${cardData.depositSumMin} ${to} ${cardData.depositSumMax} `,
        },
        { header: duration, data: `${cardData.depositTerm} ${months}` },
        {
            header: contribution,
            data: cardData.depositReplenishingBalancePossibility
                ? provided
                : notProvided,
        },
        {
            header: withdrawal,
            data: cardData.depositEarlyClosed ? provided : notProvided,
        },
        {
            header: fullInfo,
            data: cardData.depositFullDescription,
        },
    ];

    return (
        <>
            {depositInfoArray.map((item) => (
                <div key={item.header} className={styles['details-block']}>
                    <Typography
                        tag={'span'}
                        fontSize={'size22'}
                        fontWeight={'weight400'}
                        lineHeight={'140'}
                    >
                        {item.header}
                    </Typography>
                    <Typography
                        tag={'span'}
                        fontSize={'size22'}
                        fontWeight={'weight400'}
                        lineHeight={'140'}
                    >
                        {item.data}
                    </Typography>
                </div>
            ))}
        </>
    );
};
