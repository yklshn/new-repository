import { Image, Typography } from '@./ui';
import appStore from 'libs/img/appStore.png';
import React from 'react';
import { useTranslation } from 'react-i18next';
import { Link } from 'react-router-dom';

import styles from './Footer.module.sass';
import coment from '/libs/img/coment.svg';
import facebook from '/libs/img/faceBook.svg';
import googlePlay from '/libs/img/googlePlay.png';
import telegram from '/libs/img/telegram.svg';
import vk from '/libs/img/vk.svg';

export const Footer: React.FC = (): JSX.Element => {
  const { t } = useTranslation();

  const bankName = t('footer.about.0');
  const about = t('footer.about.1');
  const news = t('footer.about.2');
  const help = t('footer.about.3');

  const phoneNumber = t('footer.support.phoneNumber.0');
  const forCallsRus = t('footer.support.phoneNumber.1');
  const twentyFourSupportRus = t('footer.support.phoneNumber.2');

  const emailWelcome = t('footer.support.email.0');
  const questions = t('footer.support.email.1');
  const emailSupport = t('footer.support.email.2');
  const twentyFourSupport = t('footer.support.email.3');

  const signature = t('footer.signature.0');

  return (
    <div className={styles['block']}>
      <footer>
        <div className={styles['flexContent']}>
          <div className={styles['flexFirstElem']}>
            <h2>{bankName}</h2>
            <div className={styles['aboutNews']}>
              <Link className={styles['link']} to={'#'}>
                {about}
              </Link>
              <Link className={styles['link']} to={'#'}>
                {news}
              </Link>
            </div>
            <button className={styles['help']}>
              <img src={coment} alt="" />
              {help}
            </button>
          </div>
          <div className={styles['flexSecondElem']}>
            <div className={styles['firstFooterInformation']}>
              <div className={styles['partInformation']}>
                {/*<div className={styles['title']}>8 800 000-00-00</div>*/}
                <Typography
                  tag={'p'}
                  fontSize={'20px'}
                  lineHeight={'19px'}
                  marginTop={'5px'}
                  fontWeight={'700'}
                  color={'white'}
                >
                  {phoneNumber}
                </Typography>
                <Typography
                  tag={'p'}
                  fontSize={'14px'}
                  marginTop={'5px'}
                  fontWeight={'400'}
                  color={'white'}
                >
                  {forCallsRus}
                </Typography>
              </div>
              <div className={styles['partInformation']}>
                <Typography
                  tag={'p'}
                  fontSize={'20px'}
                  marginTop={'5px'}
                  lineHeight={'19px'}
                  fontWeight={'700'}
                  color={'white'}
                >
                  {phoneNumber}
                </Typography>
                <Typography
                  tag={'p'}
                  fontSize={'14px'}
                  marginTop={'5px'}
                  fontWeight={'400'}
                  color={'white'}
                >
                  {twentyFourSupportRus}
                </Typography>
              </div>
            </div>
            <div className={styles['secondFooterInformation']}>
              <div className={styles['partInformation']}>
                <Typography
                  tag={'p'}
                  fontSize={'20px'}
                  lineHeight={'19px'}
                  marginTop={'5px'}
                  fontWeight={'700'}
                  color={'white'}
                >
                  {emailWelcome}
                </Typography>
                <Typography
                  tag={'p'}
                  fontSize={'14px'}
                  marginTop={'5px'}
                  fontWeight={'400'}
                  color={'white'}
                >
                  {questions}
                </Typography>
              </div>
              <div className={styles['partInformation']}>
                <Typography
                  tag={'p'}
                  fontSize={'20px'}
                  lineHeight={'19px'}
                  marginTop={'5px'}
                  fontWeight={'700'}
                  color={'white'}
                >
                  {emailSupport}
                </Typography>
                <Typography
                  tag={'p'}
                  fontSize={'14px'}
                  marginTop={'5px'}
                  fontWeight={'400'}
                  color={'white'}
                >
                  {twentyFourSupport}
                </Typography>
              </div>
            </div>
          </div>
        </div>
        <div className={styles['hr']}></div>
        <Typography
          tag={'p'}
          textAlign={'center'}
          fontSize={'12px'}
          marginTop={'20px'}
          color={'grey-v1'}
        >
          {signature}
        </Typography>

        <div className={styles['social']}>
          <Image width={13} height={13} src={facebook} alt="facebook" />
          <Image width={13} height={13} src={vk} alt="vk" />
          <Image width={13} height={13} src={telegram} alt="telegram" />
        </div>

        <div className={styles['app']}>
          <Image src={appStore} alt={'appStore'} />
          <Image src={googlePlay} alt={'playMarket'} />
        </div>
      </footer>
    </div>
  );
};
