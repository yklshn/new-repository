import { useState } from 'react';
import { useTranslation } from 'react-i18next';

import plus from '/libs/img/accordionPlus.svg';
import minus from '/libs/img/accordionMinus.svg';

import { Typography, Image } from '@./ui';

import styles from './Accordion.module.sass';

export const Accordion: React.FC = (): JSX.Element => {
  const [selected, setSelected] = useState('');

  const toggle = (i: string) => {
    if (selected === i) {
      return setSelected('');
    }

    setSelected(i);
  };

  const { t } = useTranslation();
  const questionCards: string = t('accordion.question.0');
  const questionRate: string = t('accordion.question.1');
  const questionLimit: string = t('accordion.question.2');
  const questionPeriod: string = t('accordion.question.3');
  const questionGetCredit: string = t('accordion.question.4');
  const answer: string = t('accordion.answer.0');
  const faq: string = t('accordion.freqQuestions.0');

  const data = [
    {
      question: questionCards,
      answer: answer,
    },
    {
      question: questionRate,
      answer: answer,
    },
    {
      question: questionLimit,
      answer: answer,
    },
    {
      question: questionPeriod,
      answer: answer,
    },
    {
      question: questionGetCredit,
      answer: answer,
    },
  ];

  return (
    <div className={styles['wrapper']}>
      <div className={styles['container']}>
        <Typography
          tag={'h2'}
          fontSize={'44px'}
          marginTop={'80px'}
          fontWeight={700}
        >
          {faq}
        </Typography>
        <br />
        <div className={styles['accordion']}>
          {data.map((item, i) => (
            <div key={i} className={styles['item']}>
              <div className={styles['title']} onClick={() => toggle(`${i}`)}>
                <Typography tag={'h2'} fontWeight={'700'} fontSize={'24px'}>
                  {item.question}
                </Typography>
                {selected === `${i}` ? (
                  <Image
                    className={styles['imgPointer']}
                    src={minus}
                    alt={'plus'}
                    width={30}
                    height={30}
                  />
                ) : (
                  <Image
                    className={styles['imgPointer']}
                    src={plus}
                    alt={'plus'}
                    width={30}
                    height={30}
                  />
                )}
              </div>
              <div
                className={
                  selected === `${i}`
                    ? styles['contentShow']
                    : styles['content']
                }
              >
                <Typography
                  tag={'h3'}
                  marginTop={'20px'}
                  lineHeight={'25px'}
                  fontSize={'18px'}
                >
                  {item.answer}
                </Typography>
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
};
