import { useTranslation } from 'react-i18next';

import { Slider } from './Slider/Slider';
import image1 from '/libs/img/slider_bg_1.jpg';
import image2 from '/libs/img/slider_bg_2.jpg';
import image3 from '/libs/img/slider_bg_3.jpg';

export const SliderWrapper = () => {
  const { t } = useTranslation();

  const images = [image1, image2, image3];
  const titles = [
    t('slider.title.0'),
    t('slider.title.1'),
    t('slider.title.2'),
  ];
  const texts = [t('slider.text.0'), t('slider.text.1'), t('slider.text.2')];
  const buttonTexts = [
    t('slider.buttonText.0'),
    t('slider.buttonText.1'),
    t('slider.buttonText.2'),
  ];

  return (
    <div>
      <Slider
        titleItems={titles}
        textItems={texts}
        buttonTextItems={buttonTexts}
        imageItems={images}
      />
    </div>
  );
};
