import { Button, Typography } from '@./ui';

import styles from './SliderItem.module.sass';

type propTypes = {
  title: string;
  text: string;
  buttonText: string;
  image?: string;
};

export const SliderItem = ({ title, text, buttonText, image }: propTypes) => {
  return (
    <div className={styles['wrap']}>
      <div
        className={styles['wrap__image']}
        style={{ backgroundImage: `url(${image})` }}
      ></div>
      <div className={styles['wrap-content']}>
        <div className={styles['title']}>
          <Typography tag={'h1'} fontSize="44px" fontWeight="700">
            {title}
          </Typography>
        </div>

        <div className={styles['text']}>
          <Typography tag={'p'} fontSize="22px" fontWeight="400">
            {text}
          </Typography>
        </div>

        <div className={styles['button']}>
          <Button variant={'primary'}>{buttonText}</Button>
        </div>
      </div>
    </div>
  );
};
