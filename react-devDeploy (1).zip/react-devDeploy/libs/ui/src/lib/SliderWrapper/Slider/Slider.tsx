import { Autoplay, Pagination } from 'swiper';
import { Swiper, SwiperSlide } from 'swiper/react';
import { SliderItem } from './SliderItemFolder/SliderItem';

import 'swiper/css';
import 'swiper/css/autoplay';
import 'swiper/css/pagination';

import styles from './Slider.module.sass';

type propTypes = {
    titleItems: string[];
    textItems: string[];
    buttonTextItems: string[];
    imageItems: string[];
};

export const Slider = ({
    titleItems,
    textItems,
    buttonTextItems,
    imageItems,
}: propTypes) => {
    return (
        <div className={styles['Slider']}>
            <Swiper
                modules={[Pagination, Autoplay]}
                slidesPerView={1}
                autoplay={{
                    delay: 15000,
                    disableOnInteraction: false,
                }}
                pagination={{ clickable: true }}
            >
                {titleItems.map((slide, index) => (
                    <SwiperSlide key={index}>
                        <SliderItem
                            title={slide}
                            text={textItems[index]}
                            buttonText={buttonTextItems[index]}
                            image={imageItems[index]}
                        />
                    </SwiperSlide>
                ))}
            </Swiper>
        </div>
    );
};
