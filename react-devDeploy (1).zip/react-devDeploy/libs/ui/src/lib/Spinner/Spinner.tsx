import { Typography } from '@./ui';

import styles from './Spinner.module.sass';
import spinnerImg from '/libs/ui/img/Spinner.svg';

type SpinnerProps = {
  loading: boolean;
  text?: string;
};

export const Spinner = ({ loading, text }: SpinnerProps) => {
  return (
    <div>
      {loading && (
        <div className={styles['loading']}>
          <Typography tag={'span'} fontSize={'size32'} fontWeight={'weight700'}>
            {text}
          </Typography>
          <div className="spinner">
            <img src={spinnerImg} alt="Spinner" />
          </div>
        </div>
      )}
    </div>
  );
};
