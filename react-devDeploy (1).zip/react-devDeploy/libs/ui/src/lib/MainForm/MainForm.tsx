import { Button, Image, Typography } from '@./ui';
import { FormikProps, useFormik } from 'formik';
import { t } from 'i18next';
import { useTranslation } from 'react-i18next';

import backgroundImage from '../../../../img/formCardsBg.png';
import styles from './MainForm.module.sass';

type FormValues = {
  fullName: string;
  phone: string;
  gmail: string;
  city: string;
  confirmed: string;
};

const initialValues: FormValues = {
  fullName: '',
  phone: '',
  gmail: '',
  city: '',
  confirmed: 'false',
};

const onSubmit = (values: FormValues) => {
  console.log('All our data ', values);
};

const validate = (values: FormValues) => {
  const required = t('mainForm.errors.0');
  const nameHasDigits = t('mainForm.errors.1');
  const cityHasDigits = t('mainForm.errors.2');
  const checkOperatorCode = t('mainForm.errors.3');
  const wrongEmail = t('mainForm.errors.4');

  const errors: FormValues = {} as FormValues;

  if (!values.fullName) {
    errors.fullName = required;
  } else if (
    !/^[a-zA-Zа-яА-Я]+/g.test(values.fullName) ||
    /\d/.test(values.fullName)
  ) {
    errors.fullName = nameHasDigits;
  }

  if (!values.confirmed) {
    errors.confirmed = required;
  }

  if (!values.city) {
    errors.city = required;
  } else if (!/^[a-zA-Zа-яА-Я]+/g.test(values.city) || /\d/.test(values.city)) {
    errors.city = cityHasDigits;
  }

  if (!values.phone) {
    errors.phone = required;
  } else if (
    !/^(\s*)?(\+)?([- _():=+]?\d[- _():=+]?){10,14}(\s*)?$/.test(values.phone)
  ) {
    errors.phone = checkOperatorCode;
  }

  if (!values.gmail) {
    errors.gmail = required;
  } else if (
    !/^([a-zA-Z0-9_\.\-])+\@(([a-zA-Z0-9\-])+\.)+([a-zA-Z0-9]{2,4})+$/.test(
      values.gmail
    )
  ) {
    errors.gmail = wrongEmail;
  }

  return errors;
};

export const MainForm = () => {
  const formik: FormikProps<FormValues> = useFormik<FormValues>({
    initialValues,
    onSubmit,
    validate,
  });

  const { t } = useTranslation();
  const title = t('mainForm.form.0');
  const name = t('mainForm.form.1');
  const namePlaceholder = t('mainForm.form.2');
  const phoneNumber = t('mainForm.form.3');
  const phoneNumberPlaceholder = t('mainForm.form.4');
  const email = t('mainForm.form.5');
  const emailPlaceholder = t('mainForm.form.6');
  const city = t('mainForm.form.7');
  const cityPlaceholder = t('mainForm.form.8');
  const iAgree = t('mainForm.form.9');
  const next = t('mainForm.form.10');

  return (
    <div className={styles['wrapper']}>
      <div className={styles['container']}>
        <Typography
          tag={'h2'}
          fontWeight={700}
          color={'black-v1'}
          fontSize={'44px'}
          className={styles['form-title']}
        >
          {title}
        </Typography>

        <form className={styles['form']} onSubmit={formik.handleSubmit}>
          <div className={styles['input-wrapper']}>
            <label htmlFor="fullName">{name}</label>
            <input
              onBlur={formik.handleBlur}
              placeholder={namePlaceholder}
              type="text"
              id={'fullName'}
              onChange={formik.handleChange}
              value={formik.values.fullName}
            />
            {formik.touched.fullName && formik.errors.fullName ? (
              <Typography tag={'h4'} marginTop={'5px'} color={'red-error'}>
                {formik.errors.fullName}
              </Typography>
            ) : null}
          </div>

          <div className={styles['flexInput']}>
            <div className={styles['input-wrapper']}>
              <label htmlFor="phone">{phoneNumber}</label>
              <input
                onBlur={formik.handleBlur}
                placeholder={phoneNumberPlaceholder}
                type="text"
                id={'phone'}
                onChange={formik.handleChange}
                value={formik.values.phone}
              />
              {formik.touched.phone && formik.errors.phone ? (
                <Typography tag={'h4'} marginTop={'5px'} color={'red-error'}>
                  {formik.errors.phone}
                </Typography>
              ) : null}
            </div>

            <div className={styles['input-wrapper']}>
              <label htmlFor="gmail">{email}</label>
              <input
                onBlur={formik.handleBlur}
                placeholder={emailPlaceholder}
                type="text"
                id={'gmail'}
                onChange={formik.handleChange}
                value={formik.values.gmail}
              />
              {formik.touched.gmail && formik.errors.gmail ? (
                <Typography tag={'h4'} marginTop={'5px'} color={'red-error'}>
                  {formik.errors.gmail}
                </Typography>
              ) : null}
            </div>
          </div>
          <div className={styles['input-wrapper']}>
            <label htmlFor="city">{city}</label>
            <input
              onBlur={formik.handleBlur}
              placeholder={cityPlaceholder}
              type="text"
              id={'city'}
              onChange={formik.handleChange}
              value={formik.values.city}
            />
            {formik.touched.city && formik.errors.city ? (
              <Typography tag={'h4'} marginTop={'5px'} color={'red-error'}>
                {formik.errors.city}
              </Typography>
            ) : null}
          </div>

          <div className={styles['confirm-wrapper']}>
            <div className={styles['confirm']}>
              <input
                onBlur={formik.handleBlur}
                required
                value={`${formik.values.confirmed}`}
                id={'confirmed'}
                onChange={formik.handleChange}
                type="checkbox"
              />{' '}
              <Typography tag={'h3'}>{iAgree}</Typography>
            </div>
          </div>
          <Button type={'submit'}>{next}</Button>
        </form>
      </div>
      <div className={styles['image']}>
        <Image src={backgroundImage} alt="alt image" width={550} height={426} />
      </div>
    </div>
  );
};
