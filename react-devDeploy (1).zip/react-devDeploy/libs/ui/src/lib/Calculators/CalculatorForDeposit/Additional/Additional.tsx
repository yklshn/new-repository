import { Typography } from '@./ui';
import { ChangeEventHandler } from 'react';

import styles from './Additional.module.sass';

type AdditionalProps = {
  title: string;
  handleAdditionalValue: ChangeEventHandler;
};

export const Additional = ({
  title,
  handleAdditionalValue,
}: AdditionalProps) => {
  return (
    <div className={styles['additional-wrapper']}>
      <div className={styles['additional-label']}>
        <label htmlFor="additional">
          <Typography
            tag={'span'}
            fontSize={'size14'}
            fontWeight={'weight400'}
            lineHeight={'120'}
          >
            {title}
          </Typography>
        </label>
      </div>
      <div className={styles['additional-select']}>
        <select
          size={1}
          name="additional"
          defaultValue={'0'}
          onChange={handleAdditionalValue}
        >
          <option value="0" disabled>
            Выберите дополнительные условия
          </option>
          <option value="1">Фиксированная процентная ставка</option>
          <option value="2">Досрочное закрытие вклада</option>
          <option value="3">Возможность пополнения вклада</option>
          <option value="4">Возможность снятия средств с баланса</option>
        </select>
        <div className={styles['select-arrow']}></div>
        <div className={styles['select-arrow']}></div>
      </div>
    </div>
  );
};
