import { CustomRangeInput, Typography } from '@./ui';
import { t } from 'i18next';
import { ChangeEventHandler, FormEventHandler } from 'react';

import { DepositObject } from '../CalculatorForDeposit';
import styles from './Sum.module.sass';

type SumProps = {
  title: string;
  selectedDeposit: DepositObject[];
  sumValue: number | string;
  handleSumValue: ChangeEventHandler | FormEventHandler;
};

export const Sum = ({
  title,
  selectedDeposit,
  sumValue,
  handleSumValue,
}: SumProps) => {
  const sum = t('calculators.sum.0');

  return (
    <div className={styles['sum-wrapper']}>
      <div className={styles['sum-label']}>
        <label htmlFor="sum">
          <Typography
            tag={'span'}
            fontSize={'size14'}
            fontWeight={'weight400'}
            lineHeight={'120'}
          >
            {title}
          </Typography>
        </label>
      </div>
      <div className={styles['sum-input']}>
        <input
          type="text"
          id="sumText"
          name="sumText"
          min={selectedDeposit[0].sumMin}
          // min="5000  ₽"
          max={selectedDeposit[0].sumMax}
          // max="50 000 000 ₽"
          placeholder={sum}
          value={sumValue}
          onChange={handleSumValue}
        />
      </div>
      <div>
        <CustomRangeInput
          id="sum"
          name="sum"
          min={selectedDeposit[0].sumMin}
          max={selectedDeposit[0].sumMax}
          step={100}
          value={sumValue}
          minText={`${selectedDeposit[0].sumMin}`}
          maxText={`${selectedDeposit[0].sumMax}`}
          onChange={handleSumValue}
        />
      </div>
      {/* <div className={styles['sum-input--span']}>
        <span>{selectedDeposit[0].sumMin}</span>
        <span>{selectedDeposit[0].sumMax}</span>
      </div> */}
    </div>
  );
};
