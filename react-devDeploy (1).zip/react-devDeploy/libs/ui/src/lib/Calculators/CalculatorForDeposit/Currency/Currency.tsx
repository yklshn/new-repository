import { ChangeEventHandler } from 'react';

import { Typography } from '@./ui';

import { DepositObject } from '../CalculatorForDeposit';

import styles from './Currency.module.sass';

type CurrencyProps = {
    title: string;
    depositsData: DepositObject[];
    handleChangeDeposit: ChangeEventHandler;
};

export const Currency = ({
    title,
    depositsData,
    handleChangeDeposit,
}: CurrencyProps) => {
    return (
        <div className={styles['currency']}>
            <Typography
                tag={'span'}
                fontSize={'size14'}
                fontWeight={'weight400'}
                lineHeight={'120'}
            >
                {title}
            </Typography>
            <div className={styles['select-wrapper']}>
                <select
                    size={1}
                    name="currency"
                    defaultValue={'RUB'}
                    onChange={handleChangeDeposit}
                >
                    {depositsData?.map((item) => (
                        <option
                            value={item.currencyName}
                            key={item.currencyName}
                        >
                            {item.currencyName}
                        </option>
                    ))}
                </select>
                <div className={styles['select-arrow']}></div>
                <div className={styles['select-arrow']}></div>
            </div>
        </div>
    );
};
