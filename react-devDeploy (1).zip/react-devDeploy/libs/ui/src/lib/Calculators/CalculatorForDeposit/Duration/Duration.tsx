import { CustomRangeInput, Typography } from '@./ui';
import { t } from 'i18next';
import { ChangeEventHandler, FormEventHandler } from 'react';

import { DepositObject } from '../CalculatorForDeposit';
import styles from './Duration.module.sass';

type DurationProps = {
  title: string;
  selectedDeposit: DepositObject[];
  durationValue: number | string;
  handleDurationValue: ChangeEventHandler | FormEventHandler;
};

export const Duration = ({
  title,
  durationValue,
  handleDurationValue,
  selectedDeposit,
}: DurationProps) => {
  const option = t('calculators.duration.option.0');
  const month = t('calculators.duration.month.0');

  return (
    <div className={styles['duration-wrapper']}>
      <div className={styles['duration-label']}>
        <label htmlFor="duration">
          <Typography
            tag={'span'}
            fontSize={'size14'}
            fontWeight={'weight400'}
            lineHeight={'120'}
          >
            {title}
          </Typography>
        </label>
      </div>
      <div className={styles['duration-select']}>
        <select
          size={1}
          name="duration"
          defaultValue={'0'}
          value={durationValue}
          onChange={handleDurationValue}
        >
          <option value="0" disabled>
            {option}
          </option>
          {selectedDeposit[0].depositTermList.map((item) => (
            <option value={item} key={item}>
              {item}
            </option>
          ))}
        </select>
        <div className={styles['select-arrow']}></div>
        <div className={styles['select-arrow']}></div>
      </div>
      <div className={styles['duration-range']}>
        <CustomRangeInput
          id="duration"
          name="duration"
          min={0}
          max={120}
          step={6}
          minText={`0 ${month}`}
          maxText={`120 ${month}`}
          value={durationValue}
          onChange={handleDurationValue}
        />
      </div>
      {/* <div className={styles['duration-input--span']}>
        <span>{selectedDeposit[0].depositTermList[0] + `  ${month}`}</span>
        <span>{selectedDeposit[0].depositTermList[5] + `  ${month}`}</span>
      </div> */}
    </div>
  );
};
