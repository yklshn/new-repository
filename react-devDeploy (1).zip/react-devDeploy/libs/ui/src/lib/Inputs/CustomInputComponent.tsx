import { Image, Typography } from '@./ui';
import { FieldProps } from 'formik';
import { FC } from 'react';

import s from './inputLog.module.sass';

export type CustomInputProps = {
  label?: string;
  type?: string;
  placeholder?: string;
  handleClick?: () => void;
  img?: string;
  className?: string;
};

export const CustomInputComponent: FC<CustomInputProps & FieldProps> = ({
  field,
  form: { touched, errors },
  type = 'text',
  meta,
  label,
  placeholder,
  handleClick,
  img,
  className,
}) => {
  return (
    <div>
      {' '}
      <span className={s['wrapper']}>
        <input
          type={type}
          id={field.name}
          value={field.value}
          name={field.name}
          onBlur={field.onBlur}
          onChange={field.onChange}
          className={s['input-log']}
          placeholder={placeholder}
        />
        <label htmlFor={field.name} className={s['input-absolute']}>
          {label}
        </label>

        {img && (
          <Image
            className={className}
            onClick={() => handleClick!()}
            width={22}
            height={22}
            src={img}
            alt="eye"
          />
        )}
      </span>
      {touched[field.name] && meta.error && (
        <Typography
          marginTop={'5px'}
          tag={'p'}
          fontSize={'12px'}
          color={'red-error'}
        >
          {meta.error}
        </Typography>
      )}
    </div>
  );
};
