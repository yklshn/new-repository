import { FC, useState } from 'react';
import { CustomInputComponent } from '@./ui';
import { FieldProps } from 'formik';
import { CustomInputProps } from './CustomInputComponent';
import eyeOpen from 'libs/img/eyeShow.svg';
import closedEye from 'libs/img/eyeHide.svg';
import s from './inputLog.module.sass';

export const InputPassword: FC<CustomInputProps & FieldProps> = ({
    ...props
}) => {
    const [showPassword, setShowPassword] = useState(true);
    return (
        <CustomInputComponent
            {...props}
            type={showPassword ? 'password' : 'text'}
            handleClick={() => setShowPassword(!showPassword)}
            className={s['eye']}
            img={showPassword ? closedEye : eyeOpen}
        />
    );
};
