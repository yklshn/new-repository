import { InputHTMLAttributes, useCallback, useMemo } from 'react';

import styles from './CustomRangeInput.module.sass';

type InputForExtend = {
  minText?: string;
  maxText?: string;
};

type CustomRangeInputProps = InputHTMLAttributes<HTMLInputElement> &
  InputForExtend;

export const CustomRangeInput = ({
  id,
  name,
  min,
  max = 6000000,
  value,
  step = 100,
  onChange,
  minText,
  maxText,
}: CustomRangeInputProps) => {
  const getBackgroundSize = useMemo(() => {
    return value
      ? { backgroundSize: `${((value as number) * 100) / +max}% 100%` }
      : { backgroundSize: 0 };
  }, [value, max]);
  return (
    <>
      <div className={styles['wrapper']}>
        <div className={styles['range']}>
          <input
            type="range"
            id={id}
            name={name}
            min={min}
            max={max}
            step={step}
            value={value}
            onChange={onChange}
            style={getBackgroundSize}
          />
        </div>
        {minText && maxText ? (
          <>
            <div className={styles['range--span']}>
              <span>{minText}</span>
              <span>{maxText}</span>
            </div>
          </>
        ) : (
          <></>
        )}
      </div>
    </>
  );
};
