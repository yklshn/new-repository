import { Typography } from '@./ui';
import { ChangeEventHandler, InputHTMLAttributes } from 'react';

import styles from './CustomTextInput.module.sass';

export type CustomTextInputProps = InputHTMLAttributes<HTMLInputElement>;

export type CustomSumInputProps = {
  upperLabel?: string;
};

export const CustomTextInput = ({
  value,
  onChange,
  id,
  name,
  title,
  placeholder = 'Введите сумму',
  upperLabel,
}: CustomTextInputProps & CustomSumInputProps) => {
  return (
    <>
      {title ? (
        <>
          <div className={styles['sum-label']}>
            <label htmlFor={name} className={styles['sub-label--item']}>
              <Typography
                tag={'span'}
                fontSize={'size14'}
                fontWeight={'weight400'}
                lineHeight={'120'}
              >
                {title}
              </Typography>
            </label>
          </div>
        </>
      ) : (
        <></>
      )}

      <div className={styles['sum-input']}>
        <p className={styles['sum-upperLabel']}>{upperLabel}</p>
        <input
          type="text"
          id={id}
          name={name}
          placeholder={placeholder}
          value={value}
          onChange={onChange}
        />
      </div>
    </>
  );
};
