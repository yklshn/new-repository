import { SelectHTMLAttributes } from 'react';

import styles from './CustomSelect.module.sass';

type SelectForExtend = {
  arrowed?: boolean;
  optionsArray: number[] | string[];
  disabledOption: boolean;
  disabledOptionText?: string;
};

export type CustomSelectProps = SelectHTMLAttributes<HTMLSelectElement> &
  SelectForExtend;

export type CustomSumInputProps = {
  upperLabel?: string;
};

export const CustomSelect = ({
  size = 1,
  arrowed = true,
  optionsArray,
  name,
  value,
  onChange,
  disabledOption,
  disabledOptionText,
  upperLabel,
}: CustomSelectProps & CustomSumInputProps) => {
  return (
    <div className={styles['select']}>
      <p className={styles['select-upperLabel']}>{upperLabel}</p>
      <select
        size={size}
        name={name}
        defaultValue={'0'}
        value={value}
        onChange={onChange}
      >
        {disabledOption ?? (
          <option value="0" disabled>
            {disabledOptionText}
          </option>
        )}

        {optionsArray.map((item) => (
          <option value={item} key={item}>
            {item}
          </option>
        ))}
      </select>
      {arrowed ? (
        <>
          <div className={styles['select-arrow']}></div>
          <div className={styles['select-arrow']}></div>
        </>
      ) : (
        <></>
      )}
    </div>
  );
};
